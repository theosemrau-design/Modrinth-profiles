#version 120

#include "lib/HDR.glsl"

varying vec2 texcoord;

uniform sampler2D depthtex1;
uniform sampler2D colortex4;
uniform sampler2D colortex3;

uniform vec3 sunPosition;

uniform mat4 gbufferProjection;

uniform float near;
uniform float far;
uniform float frameTime;


void main() {

	vec3 color = texture2D(colortex4, texcoord).rgb;

	vec4 tpos = vec4(sunPosition, 1.0) * gbufferProjection;
	tpos = vec4(tpos.xyz / tpos.w, 1.0);
	vec2 pos = tpos.xy / tpos.z;
	vec2 lightPos = pos * 0.5 + 0.5;

	float comp = 1.0 - near / far / far;


	float brightness = dot(texture2D(colortex3, texcoord).rgb * MAX_COLOR_RANGE, vec3(0.333));
	brightness = clamp(1.0 - brightness, 0.0, 1.0);

	const float minExposure = 0.3;
	const float maxExposure = 2.0;
	const float equilibrium = 0.3;

	float denominator = -4.0 * (brightness - 0.5);
	float exposure = minExposure + ((maxExposure - minExposure) / (equilibrium + pow(2.0, denominator))) * equilibrium; 

	color *= exposure;
	//color = texture2D(colortex3, texcoord).rgb;

/* DRAWBUFFERS:4 */

	gl_FragData[0] = vec4(color, float(texture2D(depthtex1, lightPos).x > comp));


}
