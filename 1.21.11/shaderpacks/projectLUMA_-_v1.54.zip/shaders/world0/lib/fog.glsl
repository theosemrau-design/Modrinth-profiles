#define FOG_DENSITY 1.0 // [0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0 1.1. 1.2 1.3 1.4 1.5 1.6 1.7 1.8 1.9 2.0 2.1 2.2 2.3 2.4 2.5 2.6 2.7 2.8 2.9 3.0 3.1 3.2 3.3 3.4 3.5 3.6 3.7 3.8 3.9 4.0]

const bool colortex6MipmapEnabled = true;

vec3 renderFog(vec3 fragpos, vec3 color, vec3 ambientColor, float skyLightmap, vec3 caveFogColor) {

  vec4 worldPos = gbufferModelViewInverse * vec4(fragpos, 1.0);

  float height = pow(max(1.0 - ((worldPos.y + cameraPosition.y) * 2.0 - 240), 0.0), 2.0) * 0.00004;

  float fogDensity = 0.002;
        fogDensity += fogDensity * rainStrength;
        fogDensity += height * fogDensity;

	float fogFactor = exp(-pow(length(fragpos.xyz) * fogDensity * FOG_DENSITY, 1.5) * 0.3);

	vec3 fogcolor = mix(ambientColor * (1.0 - rainStrength * time[5]), texture2D(colortex6, texcoord, 6.0).rgb * MAX_COLOR_RANGE, 1.0 - fogFactor * 0.5);
  fogcolor = mix(fogcolor, caveFogColor * 0.2, mix(1.0 - skyLightmap, 0.0, eyeBrightness.y / 240.0));

  color = pow(color, vec3(2.2));
  color = mix(color, pow(fogcolor, vec3(2.2)), 1.0 - fogFactor);
  color = pow(color, vec3(0.4545));

  return color;

}
