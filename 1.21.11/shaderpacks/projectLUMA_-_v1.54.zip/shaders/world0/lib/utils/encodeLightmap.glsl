float encodeLightmap(vec2 a) {
    ivec2 bf = ivec2(a * 255.0);
    return float(bf.x | (bf.y << 8)) / 65535.0;
}