#define TEMPERATURE 1.0 // [0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0 1.1 1.2 1.3 1.4 1.5 1.6 1.7 1.8 1.9 2.0]
#define TORCHLIGHT_TEMPERATURE 1.0 // [0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0 1.1 1.2 1.3 1.4 1.5 1.6 1.7 1.8 1.9 2.0]

//#define OVERRIDE_COLORS
  #define AMBIENT_R 1.0 // [0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0 1.1 1.2 1.3 1.4 1.5 1.6 1.7 1.8 1.9 2.0]
  #define AMBIENT_G 1.0 // [0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0 1.1 1.2 1.3 1.4 1.5 1.6 1.7 1.8 1.9 2.0]
  #define AMBIENT_B 1.0 // [0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0 1.1 1.2 1.3 1.4 1.5 1.6 1.7 1.8 1.9 2.0]
  #define SUNLIGHT_R 1.0 // [0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0 1.1 1.2 1.3 1.4 1.5 1.6 1.7 1.8 1.9 2.0]
  #define SUNLIGHT_G 1.0 // [0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0 1.1 1.2 1.3 1.4 1.5 1.6 1.7 1.8 1.9 2.0]
  #define SUNLIGHT_B 1.0 // [0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0 1.1 1.2 1.3 1.4 1.5 1.6 1.7 1.8 1.9 2.0]
  #define TORCH_R 1.0 // [0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0 1.1 1.2 1.3 1.4 1.5 1.6 1.7 1.8 1.9 2.0]
  #define TORCH_G 1.0 // [0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0 1.1 1.2 1.3 1.4 1.5 1.6 1.7 1.8 1.9 2.0]
  #define TORCH_B 1.0 // [0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0 1.1 1.2 1.3 1.4 1.5 1.6 1.7 1.8 1.9 2.0]

float sunFactor = clamp(1.0 - pow(abs(-0.25 + sunAngle) * 4.0, 2.0 / (abs(-0.25 + sunAngle) * 4.0)), 0.0, 1.0);

vec3 ambientColor = mix(vec3(0.8, 0.88, 1.0) * 0.5, vec3(0.65, 0.8, 1.0), sunFactor) * (1.0 - time[5]);
     ambientColor += vec3(0.6, 0.73, 1.0) * 0.3 * time[5];
     ambientColor *= 1.0 - rainStrength;

     ambientColor += vec3(0.9, 0.95, 1.0) * 0.9 * rainStrength * (1.0 - time[5]);
     ambientColor += vec3(0.6, 0.73, 1.0) * 0.3 * rainStrength * time[5];
     ambientColor = mix(ambientColor, normalize(ambientColor), nightVision * time[5]);
     ambientColor = mix(ambientColor, vec3(0.0, 0.5, 1.0), (1.0 - TEMPERATURE) * 0.25);

vec3 sunColor = mix(vec3(1.0, 0.5, 0.3) * 0.6, vec3(1.0, 0.9, 0.8), sunFactor) * (1.0 - time[6]);
     sunColor += vec3(0.6, 0.6, 1.0) * 0.1 * time[5];
     sunColor *= 1.0 - rainStrength;

vec3 torchColor = pow(vec3(1.0, 0.6, 0.4), vec3(TORCHLIGHT_TEMPERATURE));

vec3 waterColor = vec3(0.0, 0.7, 1.0);

vec3 lavaColor = vec3(1.0, 0.4, 0.0);

vec3 caveFogColor = vec3(0.65, 0.8, 1.0);

#ifdef OVERRIDE_COLORS
  ambientColor *= vec3(AMBIENT_R, AMBIENT_G, AMBIENT_B);
  sunColor *= vec3(SUNLIGHT_R, SUNLIGHT_G, SUNLIGHT_B);
  torchColor *= vec3(TORCH_R, TORCH_G, TORCH_B);
#endif
