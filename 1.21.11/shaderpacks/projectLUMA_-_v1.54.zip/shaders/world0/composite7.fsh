#version 120

varying vec2 texcoord;

uniform sampler2D colortex4;

uniform float aspectRatio;
uniform float viewWidth;
uniform float viewHeight;

float pw = 1.0 / viewWidth;
float ph = 1.0 / viewHeight;


const bool colortex4MipmapEnabled = true;

vec3 makeBloom(float lod, vec2 offset) {

	vec3 bloomSample = vec3(0.0);

	vec3 temp = vec3(0.0);

	float scale = pow(2.0, lod);
	vec2 coord = (texcoord.xy - offset) * scale;

	if (coord.x > -0.1 && coord.y > -0.1 && coord.x < 1.1 && coord.y < 1.1) {

		for (int i = -3; i < 4; i++) {

				for (int j = -3; j < 4; j++) {

						float wg = pow((1.0 - length(vec2(i, j)) / 4.0), 2.0) * pow(0.5, 0.5) * 20.0;
						vec2 bcoord = (texcoord.xy - offset + vec2(i, j) * pw * vec2(1.0, aspectRatio)) * scale;

				if (wg > 0){

					temp = pow(texture2D(colortex4, bcoord).rgb, vec3(2.2)) * wg;
					bloomSample += temp;

				}

			}

		}

		bloomSample /= 49;

	}

	return bloomSample;

}


void main() {

	vec3 blur = vec3(0.0);
	blur += makeBloom(2.0, vec2(0.0, 0.0));
	blur += makeBloom(3.0, vec2(0.3, 0.0));
	blur += makeBloom(4.0, vec2(0.0, 0.3));
	blur += makeBloom(5.0, vec2(0.1, 0.3));
	blur += makeBloom(6.0, vec2(0.2, 0.3));
	blur += makeBloom(7.0, vec2(0.3, 0.3));

	blur = clamp(pow(blur, vec3(0.454545)), 0.0, 1.0);

/* DRAWBUFFERS:0 */

	gl_FragData[0] = vec4(blur, 0.0);


}
