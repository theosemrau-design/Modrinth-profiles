#version 130

varying vec2 texcoord;

uniform sampler2D colortex4;
uniform sampler2D colortex3;
uniform float viewWidth;
uniform float viewHeight;
uniform float frameTime;
uniform float aspectRatio;

#define GA 2.4
#define rot mat2(cos(GA),sin(GA),-sin(GA),cos(GA))


void main() {

    const float adaptSpeed = 2.0;
    const int averageRadius = 128;   // The radius to scan for the average brightness.

	vec3 albedoCurrent = vec3(0.0);

    float radius = 1.0;
    vec2 angle = vec2(0.0, radius);
    ivec2 aspectcorrect = ivec2(1.0, aspectRatio);

    for (int i = 0; i < 12; i++) {

        radius += 1.0 / radius;
        angle *= rot;

        albedoCurrent += texelFetch(colortex4, ivec2(viewWidth * 0.5, viewHeight * 0.5) + ivec2((radius - 1.0) * angle) * aspectcorrect * averageRadius, 0).rgb;

    }

    vec3 albedoPrev = texture2D(colortex3, texcoord).rgb;

    vec3 color = mix(albedoCurrent / 12.0, albedoPrev, 1.0 - (frameTime * adaptSpeed));

/* DRAWBUFFERS:53 */

	gl_FragData[0] = vec4(color, 0.0);


}
