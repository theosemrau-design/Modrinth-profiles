#version 120

#include "lib/HDR.glsl"

#define LIGHT_SCATTERING 1 // [0 1 2]
	#define VL_QUALITY 1 // [0 1 2]
	#define LIGHT_SCATTERING_AMOUNT 1.0 // [0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0 1.1 1.2 1.3 1.4 1.5 1.6 1.7 1.8 1.9 2.0]

varying vec2 texcoord;

uniform sampler2D colortex1;
uniform sampler2D colortex7;
uniform sampler2D colortex4;
uniform sampler2D depthtex0;
uniform sampler2D depthtex1;

uniform vec3 sunPosition;

uniform mat4 gbufferProjection;
uniform mat4 gbufferProjectionInverse;

uniform int worldTime;
uniform int isEyeInWater;

uniform ivec2 eyeBrightness;

uniform float near;
uniform float far;
uniform float sunAngle;
uniform float rainStrength;
uniform float nightVision;
uniform float blindness;

#include "lib/timeArray.glsl"

#ifdef DIRTY_LENS
	uniform sampler2D noisetex;
#endif

#if (LIGHT_SCATTERING > 0)

	#if (LIGHT_SCATTERING == 2)

		uniform sampler2DShadow shadow;
		uniform mat4 shadowProjection;
		uniform mat4 shadowModelView;
		uniform mat4 gbufferModelViewInverse;

		float linearDepth(float depth){
			return 2.0 * (near * far) / (far + near - (depth) * (far - near));
		}

		float depthX(float x){
			return ((far * (x - near)) / (x * (far - near)));
		}

	#endif

	#include "lib/utils/ditherGradNoise.glsl"

	float rand(vec2 n) {
		return fract(sin(dot(n, vec2(12.9898, 4.1414))) * 43758.5453);
	}

	vec3 lightScattering(vec3 fragpos, vec2 lightPos, vec3 sunColor) {

		bool hand = texture2D(depthtex1, texcoord).x < 0.56;

		float sunVector = max(dot(normalize(fragpos), normalize(sunPosition)), 0.0);
		float sun	= pow(sunVector, 12.0) * (1.0 - time[6]);

		float moonVector = max(dot(normalize(fragpos), normalize(-sunPosition)), 0.0);
		float moon	= pow(moonVector, 12.0) * time[5];

		float sample = 0.0;

		// Godrays
		#if (LIGHT_SCATTERING == 1)

			#if (VL_QUALITY == 0)
				const int	godraysSamples = 8;
				const float noiseAmount = 1.0;
			#elif (VL_QUALITY == 1)
				const int	godraysSamples = 14;
				const float noiseAmount = 0.5;
			#elif (VL_QUALITY == 2)
				const int	godraysSamples = 20;
				const float noiseAmount = 0.25;
			#endif

			vec2 grCoord = texcoord.st;
			vec2 deltaTextCoord	 = texcoord.st - lightPos.xy;
					 deltaTextCoord	/= float(godraysSamples);

			for (int i = 0; i < godraysSamples; i++) {

				grCoord	-= deltaTextCoord * (1.0 - noiseAmount + rand(grCoord) * noiseAmount);
				sample += texture2D(colortex4, grCoord).a;

			}

			sample /= float(godraysSamples);

		// Volumetric Light
		#elif (LIGHT_SCATTERING == 2)

			#define VL_RENDERDISTANCE 40.0 // [20.0 30.0 40.0 50.0 60.0]

			float vlRenderQuality = 0.0;

			#if (VL_QUALITY == 0)
				vlRenderQuality = 2.0;
			#elif (VL_QUALITY == 1)
				vlRenderQuality = 1.0;
			#elif (VL_QUALITY == 2)
				vlRenderQuality = 0.5;
			#endif

			float i = ditherGradNoise() * vlRenderQuality - 0.01;

			while (i < distance(texcoord.x, VL_RENDERDISTANCE) && !hand) {

				if (linearDepth(texture2D(depthtex1, texcoord).x * 2.0 - 1.0) < i) break;

				vec4 vlFragpos = gbufferProjectionInverse * vec4(vec3(texcoord.st * 2.0 - 1.0, depthX(i) * 2.0 - 1.0), 1.0);
						 vlFragpos /= vlFragpos.w;

				vec4 worldPos = gbufferModelViewInverse * vec4(vlFragpos.xyz, 1.0);

				worldPos = shadowModelView * worldPos;
				worldPos = shadowProjection * worldPos;
				worldPos /= worldPos.w;

				float distortion = ((1.0 - 0.8) + length(worldPos.xy * 1.165) * 0.8) * 0.97;
				worldPos.xy /= distortion;

				float bias = distortion * distortion * (0.0015 * tan(acos(pow(1.0, 1.1))));
				worldPos.xyz = worldPos.xyz * vec3(0.5, 0.5, 0.2) + vec3(0.5, 0.5, 0.5 - bias);

				sample += shadow2D(shadow, vec3(worldPos.st, worldPos.z)).x * pow(0.9, i);

				i += vlRenderQuality;

			}

			sample /= VL_RENDERDISTANCE / vlRenderQuality;
			sample *= 4.0;

		#endif

		return sample * (sun + moon) * pow(sunColor, vec3(2.2));

	}

#endif


void main() {

  	// x = 0; y = 1
	vec2 depth = vec2(texture2D(depthtex0, texcoord).x, texture2D(depthtex1, texcoord).x);


	vec4 fragposition0  = gbufferProjectionInverse * (vec4(texcoord.st, depth.x, 1.0) * 2.0 - 1.0);
	fragposition0 /= fragposition0.w;

	vec4 fragposition1  = gbufferProjectionInverse * (vec4(texcoord.st, depth.y, 1.0) * 2.0 - 1.0);
	fragposition1 /= fragposition1.w;


	vec4 tpos = vec4(sunPosition, 1.0) * gbufferProjection;
	tpos = vec4(tpos.xyz / tpos.w, 1.0);
	vec2 pos = tpos.xy / tpos.z;
	vec2 lightPos = pos * 0.5 + 0.5;

	#include "lib/colors.glsl"

/* DRAWBUFFERS:5 */

  gl_FragData[0] = vec4(lightScattering(fragposition1.xyz, lightPos, sunColor), 0.0);

}
