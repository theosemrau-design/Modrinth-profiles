#version 120

varying vec2 texcoord;

uniform sampler2D colortex5;
uniform float frameTime;


void main() {

	vec3 color = texture2D(colortex5, texcoord).rgb;

/* DRAWBUFFERS:3 */

	gl_FragData[0] = vec4(color, 0.0);


}
