#version 120

#include "lib/HDR.glsl"

//#define DISTANCE_BLUR
#define LIGHT_SCATTERING 1 // [0 1 2]
	#define VL_QUALITY 1 // [0 1 2]
	#define LIGHT_SCATTERING_AMOUNT 1.0 // [0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0 1.1 1.2 1.3 1.4 1.5 1.6 1.7 1.8 1.9 2.0]
//#define DIRTY_LENS
//#define RAINDROP_REFRACTION

varying vec2 texcoord;

uniform sampler2D colortex1;
uniform sampler2D colortex5;
uniform sampler2D colortex7;
uniform sampler2D colortex4;
uniform sampler2D depthtex0;
uniform sampler2D depthtex1;

uniform vec3 sunPosition;

uniform mat4 gbufferProjectionInverse;

uniform int worldTime;
uniform int isEyeInWater;

uniform ivec2 eyeBrightness;

uniform float near;
uniform float far;
uniform float sunAngle;
uniform float rainStrength;
uniform float nightVision;
uniform float blindness;

#include "lib/timeArray.glsl"
#include "lib/common/underwaterFog.glsl"

#ifdef DIRTY_LENS
	uniform sampler2D noisetex;
#endif

vec3 blindnessFog(vec3 fragpos, vec3 color) {
	float fogFactor = 1.0 - exp(-pow(length(fragpos) * 0.4, 1.0));
	return color * (1.0 - blindness * fogFactor);
}

#ifdef DISTANCE_BLUR

	vec3 distanceBlur(vec2 coord, vec3 fragpos) {
		const bool colortex4MipmapEnabled = true;
		float depth = 1.0 - exp(-pow(length(fragpos.xyz) * 0.005, 2.0));

		return texture2DLod(colortex4, coord, depth).rgb * MAX_COLOR_RANGE;
	}

#endif


void main() {

	// x = 0; y = 1
	vec2 depth = vec2(texture2D(depthtex0, texcoord).x, texture2D(depthtex1, texcoord).x);

	float mat = texture2D(colortex1, texcoord).a;


	vec4 fragposition0  = gbufferProjectionInverse * (vec4(texcoord.st, depth.x, 1.0) * 2.0 - 1.0);
	fragposition0 /= fragposition0.w;

	vec4 fragposition1  = gbufferProjectionInverse * (vec4(texcoord.st, depth.y, 1.0) * 2.0 - 1.0);
	fragposition1 /= fragposition1.w;

	float comp = 1.0 - near / far / far;

	bool sky = depth.y > comp;
	bool land = depth.y < comp;

	bool hand = depth.x < 0.56;

	bool water = mat > 0.09 && mat < 0.11;
	bool gbuffers_water = mat > 0.09 && mat < 0.2;

	vec4 raindrops = texture2D(colortex7, texcoord);
	vec2 refraction = vec2(0.0);

	#ifdef RAINDROP_REFRACTION
		refraction = vec2(0.0, 0.015 * raindrops.a);
	#endif

	vec3 color = texture2D(colortex4, texcoord + refraction).rgb * MAX_COLOR_RANGE;

	#ifdef DISTANCE_BLUR
		color = distanceBlur(texcoord + refraction, fragposition1.xyz);
	#endif

  	#include "lib/colors.glsl"

	// Render fog on top of gbuffers_water
	color = underwaterFog(fragposition0.xyz, color, waterColor * ambientColor * vec3(0.6, 1.0, 0.8) * 0.2, lavaColor);

	#if (LIGHT_SCATTERING > 0)
		color = pow(color, vec3(2.2));
		color += texture2D(colortex5, texcoord * 0.5).rgb * 0.5;
		color = pow(color, vec3(1.0 / 2.2));
	#endif

	if (!hand) color += raindrops.rgb * 0.2;

	color = blindnessFog(fragposition1.xyz, color);

/* DRAWBUFFERS:4 */

  gl_FragData[0] = vec4(color / MAX_COLOR_RANGE, 0.0);

}
