#version 330 compatibility


#include "lib/Uniforms.inc"
#include "lib/Common.inc"



attribute vec4 mc_Entity;
attribute vec4 at_tangent;
attribute vec4 mc_midTexCoord;

out vec4 vTexcoord;
out vec4 vColor;
// out vec4 lmcoord;

// out vec3 normal;
out vec4 vViewPos;
out float vMaterialIDs;

out float vMCEntity;
// out float isWater;
// out float isStainedGlass;

out float uJkrQHnPMQ;		
out float CLkhESLRPa;			
out float OSdgfZDpvW;			
out vec2 ZfZgcmXvXI;			

out vec4 uNkKekmbQG;		
out vec4 cBXAVBFelQ;		
out vec3 dYtQRwLdfr;        

out vec2 UqThFbItbV; 


 const float x=1./float(8192);
 ivec2 v=ivec2(viewWidth,viewHeight),y=ivec2(6144,6144);
 int s=v.x*v.y,z=37748736;
 int f(int v)
 {
   return v-FloorToInt(mod(float(v),2.))-0;
 }
 int t(int v)
 {
   return v-FloorToInt(mod(float(v),2.))-1;
 }
 int f()
 {
   return f(FloorToInt(floor(pow(float(s),.333333))));
 }
 int t()
 {
   return t(FloorToInt(floor(pow(float(z),.333333))));
 }
 int i=f();
 float m=1./i;
 int n=t();
 float c=1./n;
 vec3 d(vec2 y)
 {
   ivec2 x=ivec2(y.x*v.x,y.y*v.y);
   float s=float(x.y/i),z=float(int(x.x+mod(v.x*s,i))/i);
   z+=floor(v.x*s/i);
   vec3 f=vec3(0.,0.,z);
   f.x=mod(x.x+mod(v.x*s,i),i);
   f.y=mod(x.y,i);
   f.xyz=floor(f.xyz);
   f/=i;
   f.xyz=f.xzy;
   return f;
 }
 vec2 r(vec3 y)
 {
   vec3 x=y.xzy*i;
   x=floor(x+1e-05);
   float s=x.z;
   vec2 f;
   f.x=mod(x.x+s*i,v.x);
   float m=x.x+s*i;
   f.y=x.y+floor(m/v.x)*i;
   f+=.5;
   f/=v;
   return f;
 }
 vec3 p(vec2 v)
 {
   vec2 i=v;
   i.xy/=.75;
   int x=y.x*y.y;
   ivec2 s=ivec2(i.x*y.x,i.y*y.y);
   float f=float(s.y/n),z=float(int(s.x+mod(y.x*f,n))/n);
   z+=floor(y.x*f/n);
   vec3 m=vec3(0.,0.,z);
   m.x=mod(s.x+mod(y.x*f,n),n);
   m.y=mod(s.y,n);
   m.xyz=floor(m.xyz);
   m/=n;
   m.xyz=m.xzy;
   return m;
 }
 vec2 e(vec3 v)
 {
   v=clamp(v,vec3(0.),vec3(1.));
   vec3 x=v.xzy*n;
   x=floor(x+1e-05);
   float s=x.z;
   vec2 i;
   i.x=mod(x.x+s*n,y.x);
   float f=x.x+s*n;
   i.y=x.y+floor(f/y.x)*n;
   i+=.5;
   i/=y;
   i.xy*=.75;
   return i;
 }
 const int g=384,K=g/2-64;
 int G=(g-n)/2;
 float F=floor(cameraPosition.y+.5),u=clamp(F,K-G,K-G),a=F-u;
 vec3 w(vec3 v)
 {
   return v.y+=a,v*=c,v=v+vec3(.5),v;
 }
 vec3 h(vec3 v)
 {
   return v=w(v),v=clamp(v,vec3(0.),vec3(1.)),v;
 }
 vec3 T(vec3 v)
 {
   return v=v-vec3(.5),v*=n,v.y-=a,v;
 }
 vec3 P(vec3 v)
 {
   return v*=m,v=v+vec3(.5),v=clamp(v,vec3(0.),vec3(1.)),v;
 }
 vec3 R(vec3 v)
 {
   return v=v-vec3(.5),v*=i,v;
 }
 vec3 P()
 {
   vec3 x=cameraPosition.xyz+.5,v=previousCameraPosition.xyz+.5,i=floor(x-.0001),z=floor(v-.0001);
   return i-z;
 }
 vec3 P(vec3 v,vec3 y,vec2 f,vec2 x,vec4 m,vec4 i,inout float s,out vec2 n)
 {
   bool z=fract(v.x*2.)>.01&&fract(v.x*2.)<.99||fract(v.y*2.)>.01&&fract(v.y*2.)<.99||fract(v.z*2.)>.01&&fract(v.z*2.)<.99;
   z=!z;
   if(i.x==8||i.x==9||i.x==79||i.x<1.||!z||i.x==20.||i.x==171.||min(abs(y.x),abs(y.z))>.2)
     s=1.;
   if(i.x==50.||i.x==48.||i.x>=44&&i.x<48||i.x==49.||i.x==52.||i.x==76.)
     {
       s=0.;
       if(y.y<.5)
         s=1.;
     }
   if(i.x==54)
     s=0.;
   if(i.x==51||i.x==53||i.x==55)
     s=0.;
   if(i.x>255)
     s=0.;
   vec3 r,c;
   if(y.x>.5)
     r=vec3(0.,0.,-1.),c=vec3(0.,-1.,0.);
   else
      if(y.x<-.5)
       r=vec3(0.,0.,1.),c=vec3(0.,-1.,0.);
     else
        if(y.y>.5)
         r=vec3(1.,0.,0.),c=vec3(0.,0.,1.);
       else
          if(y.y<-.5)
           r=vec3(1.,0.,0.),c=vec3(0.,0.,-1.);
         else
            if(y.z>.5)
             r=vec3(1.,0.,0.),c=vec3(0.,-1.,0.);
           else
              if(y.z<-.5)
               r=vec3(-1.,0.,0.),c=vec3(0.,-1.,0.);
   n=clamp((f.xy-x.xy)*100000.,vec2(0.),vec2(1.));
   float g=.15,K=.15;
   if(i.x==10.||i.x==11.)
     g=.1,K=.1,s=0.;
   if(i.x==51||i.x==55||i.x==53)
     g=.5,K=.1;
   if(i.x==76)
     g=.2,K=.2;
   if(i.x-255.+39.>=103.&&i.x-255.+39.<=113.)
     K=.025,g=.025;
   r=normalize(m.xyz);
   c=normalize(cross(r,y.xyz)*sign(m.w));
   vec3 G=v.xyz+mix(r*g,-r*g,vec3(n.x));
   G.xyz+=mix(c*g,-c*g,vec3(n.y));
   G.xyz-=y.xyz*K;
   return G;
 }struct TOuWFelenO{vec3 FjeDDzWIWi;vec3 FjeDDzWIWiOrigin;vec3 gjulCSuvVu;vec3 ihCMMEIfgL;vec3 HHiebGwFJJ;vec3 GTJIHvOSbK;};
 TOuWFelenO W(Ray v)
 {
   TOuWFelenO i;
   i.FjeDDzWIWi=floor(v.origin);
   i.FjeDDzWIWiOrigin=i.FjeDDzWIWi;
   i.gjulCSuvVu=abs(vec3(length(v.direction))/(v.direction+1e-07));
   i.ihCMMEIfgL=sign(v.direction);
   i.HHiebGwFJJ=(sign(v.direction)*(i.FjeDDzWIWi-v.origin)+sign(v.direction)*.5+.5)*i.gjulCSuvVu;
   i.GTJIHvOSbK=vec3(0.);
   return i;
 }
 void b(inout TOuWFelenO v)
 {
   v.GTJIHvOSbK=step(v.HHiebGwFJJ.xyz,v.HHiebGwFJJ.yzx)*step(v.HHiebGwFJJ.xyz,v.HHiebGwFJJ.zxy),v.HHiebGwFJJ+=v.GTJIHvOSbK*v.gjulCSuvVu,v.FjeDDzWIWi+=v.GTJIHvOSbK*v.ihCMMEIfgL;
 }
 vec3 P(const vec3 v,const vec3 x,vec3 f)
 {
   vec3 s=(x+v)*.5,i=(x-v)*.5,y=f-s,m=abs(y);
   m/=i;
   vec3 z=step(m.yzx,m.xyz)*step(m.zxy,m.xyz);
   return z*sign(y);
 }
 bool P(const vec3 v,const vec3 i,Ray y,inout float x,inout vec3 s)
 {
   vec3 z=y.inv_direction*(v-1e-05-y.origin),m=y.inv_direction*(i+1e-05-y.origin),n=min(m,z),c=max(m,z);
   vec2 f=max(n.xx,n.yz);
   float g=max(f.x,f.y);
   f=min(c.xx,c.yz);
   float r=min(f.x,f.y);
   bool K=r>max(g,0.)&&max(g,0.)<x;
   if(K)
     s=P(v,i,y.origin+y.direction*g),x=g;
   return K;
 }
 float U(vec3 v)
 {
   return 1.;
 }struct eAMCZAKEcI{float nrlJXyapkV;float vPMmNoxUfq;float QQevGhUGeB;float VSCbvpIaKi;vec3 vyHfppOAPK;};
 vec4 D(eAMCZAKEcI v)
 {
   vec4 i;
   v.vyHfppOAPK=max(vec3(0.),v.vyHfppOAPK);
   i.x=v.nrlJXyapkV;
   v.vyHfppOAPK=pow(v.vyHfppOAPK,vec3(.125));
   i.y=PackTwo16BitTo32Bit(v.vyHfppOAPK.x,v.QQevGhUGeB);
   i.z=PackTwo16BitTo32Bit(v.vyHfppOAPK.y,v.VSCbvpIaKi);
   i.w=PackTwo16BitTo32Bit(v.vyHfppOAPK.z,v.vPMmNoxUfq/255.);
   return i;
 }
 eAMCZAKEcI o(vec4 v)
 {
   eAMCZAKEcI i;
   vec2 x=UnpackTwo16BitFrom32Bit(v.y),y=UnpackTwo16BitFrom32Bit(v.z),s=UnpackTwo16BitFrom32Bit(v.w);
   i.nrlJXyapkV=v.x;
   i.QQevGhUGeB=x.y;
   i.VSCbvpIaKi=y.y;
   i.vPMmNoxUfq=s.y*255.;
   i.vyHfppOAPK=pow(vec3(x.x,y.x,s.x),vec3(8.));
   return i;
 }
 eAMCZAKEcI M(vec2 v)
 {
   return v=(floor(v*ScreenSize)+.5)*ScreenTexel,o(texture2DLod(colortex5,v,0));
 }
 vec3 D(vec3 v,vec3 z)
 {
   vec3 x=P(T(v)+z+1.+P());
   float s=U(x);
   vec2 i=r(x);
   vec3 y=M(i).vyHfppOAPK;
   return y*s;
 }
 vec3 M(vec3 v,vec3 z)
 {
   vec3 x=P(T(v)+z+1.);
   float s=U(x);
   vec2 i=r(x);
   vec3 y=M(i).vyHfppOAPK;
   return y*s;
 }
 float P(float v,float z)
 {
   float x=1.;
   #ifdef FULL_RT_REFLECTIONS
   x=clamp(pow(v,.125)+z,0.,1.);
   #else
   x=clamp(v*10.-7.,0.,1.);
   #endif
   return x;
 }
 bool D(vec3 v,float x,Ray i,bool y,inout float f,inout vec3 z)
 {
   bool s=false,m=false;
   #if RAYTRACE_GEOMETRY_QUALITY==0
   if(y)
     return false;
   if(x>=67.)
     return false;
   m=P(v,v+vec3(1.,1.,1.),i,f,z);
   s=m;
   #else
   if(x<40.)
     return m=P(v,v+vec3(1.,1.,1.),i,f,z),m;
   if(x==40.||x==41.||x>=43.&&x<=54.)
     {
       float r=.5;
       if(x==41.)
         r=.9375;
       m=P(v+vec3(0.,0.,0.),v+vec3(1.,r,1.),i,f,z);
       s=s||m;
     }
   if(x==42.||x>=55.&&x<=66.)
     m=P(v+vec3(0.,.5,0.),v+vec3(1.,1.,1.),i,f,z),s=s||m;
   if(x==43.||x==46.||x==47.||x==52.||x==53.||x==54.||x==55.||x==58.||x==59.||x==64.||x==65.||x==66.)
     {
       float r=.5;
       if(x==55.||x==58.||x==59.||x==64.||x==65.||x==66.)
         r=0.;
       m=P(v+vec3(0.,r,0.),v+vec3(.5,.5+r,.5),i,f,z);
       s=s||m;
     }
   if(x==43.||x==45.||x==48.||x==51.||x==53.||x==54.||x==55.||x==57.||x==60.||x==63.||x==65.||x==66.)
     {
       float r=.5;
       if(x==55.||x==57.||x==60.||x==63.||x==65.||x==66.)
         r=0.;
       m=P(v+vec3(.5,r,0.),v+vec3(1.,.5+r,.5),i,f,z);
       s=s||m;
     }
   if(x==44.||x==45.||x==49.||x==51.||x==52.||x==54.||x==56.||x==57.||x==61.||x==63.||x==64.||x==66.)
     {
       float r=.5;
       if(x==56.||x==57.||x==61.||x==63.||x==64.||x==66.)
         r=0.;
       m=P(v+vec3(.5,r,.5),v+vec3(1.,.5+r,1.),i,f,z);
       s=s||m;
     }
   if(x==44.||x==46.||x==50.||x==51.||x==52.||x==53.||x==56.||x==58.||x==62.||x==63.||x==64.||x==65.)
     {
       float r=.5;
       if(x==56.||x==58.||x==62.||x==63.||x==64.||x==65.)
         r=0.;
       m=P(v+vec3(0.,r,.5),v+vec3(.5,.5+r,1.),i,f,z);
       s=s||m;
     }
   if(x>=67.&&x<=82.)
     m=P(v+vec3(6.,0.,6.)/16.,v+vec3(10.,16.,10.)/16.,i,f,z),s=s||m;
   if(x==68.||x==69.||x==70.||x==72.||x==73.||x==74.||x==76.||x==77.||x==78.||x==80.||x==81.||x==82.)
     {
       float r=8.,c=8.;
       if(x==68.||x==70.||x==72.||x==74.||x==76.||x==78.||x==80.||x==82.)
         r=0.;
       if(x==69.||x==70.||x==73.||x==74.||x==77.||x==78.||x==81.||x==82.)
         c=16.;
       m=P(v+vec3(r,6.,7.)/16.,v+vec3(c,9.,9.)/16.,i,f,z);
       s=s||m;
       m=P(v+vec3(r,12.,7.)/16.,v+vec3(c,15.,9.)/16.,i,f,z);
       s=s||m;
     }
   if(x>=71.&&x<=82.)
     {
       float r=8.,n=8.;
       if(x>=71.&&x<=74.||x>=79.&&x<=82.)
         n=16.;
       if(x>=75.&&x<=82.)
         r=0.;
       m=P(v+vec3(7.,6.,r)/16.,v+vec3(9.,9.,n)/16.,i,f,z);
       s=s||m;
       m=P(v+vec3(7.,12.,r)/16.,v+vec3(9.,15.,n)/16.,i,f,z);
       s=s||m;
     }
   #if RAYTRACE_GEOMETRY_QUALITY==2
   if(x>=83.&&x<=86.)
     {
       vec3 r=vec3(0),c=vec3(0);
       if(x==83.)
         r=vec3(0,0,0),c=vec3(16,16,3);
       if(x==84.)
         r=vec3(0,0,13),c=vec3(16,16,16);
       if(x==86.)
         r=vec3(0,0,0),c=vec3(3,16,16);
       if(x==85.)
         r=vec3(13,0,0),c=vec3(16,16,16);
       m=P(v+r/16.,v+c/16.,i,f,z);
       s=s||m;
     }
   if(x>=87.&&x<=102.)
     {
       vec3 r=vec3(0.),c=vec3(1.);
       if(x>=87.&&x<=94.)
         {
           float n=0.;
           if(x>=91.&&x<=94.)
             n=13.;
           r=vec3(0.,n,0.)/16.;
           c=vec3(16.,n+3.,16.)/16.;
         }
       if(x>=95.&&x<=98.)
         {
           float n=13.;
           if(x==97.||x==98.)
             n=0.;
           r=vec3(0.,0.,n)/16.;
           c=vec3(16.,16.,n+3.)/16.;
         }
       if(x>=99.&&x<=102.)
         {
           float n=13.;
           if(x==99.||x==100.)
             n=0.;
           r=vec3(n,0.,0.)/16.;
           c=vec3(n+3.,16.,16.)/16.;
         }
       m=P(v+r,v+c,i,f,z);
       s=s||m;
     }
   if(x>=103.&&x<=113.)
     {
       vec3 r=vec3(0.),n=vec3(1.);
       if(x>=103.&&x<=110.)
         {
           float c=float(x)-float(103.)+1.;
           n.y=c*2./16.;
         }
       if(x==111.)
         n.y=.0625;
       if(x==112.)
         r=vec3(1.,0.,1.)/16.,n=vec3(15.,1.,15.)/16.;
       if(x==113.)
         r=vec3(1.,0.,1.)/16.,n=vec3(15.,.5,15.)/16.;
       m=P(v+r,v+n,i,f,z);
       s=s||m;
     }
   #endif
   #endif
   return s;
 }
 float D(vec3 v,vec3 i,int f,const int x)
 {
   Ray z=MakeRay(v,i);
   TOuWFelenO y=W(z);
   float r=1.,s=100000.;
   vec3 n=vec3(0.);
   for(int m=0;m<x;m++)
     {
       vec3 g=y.FjeDDzWIWi*c;
       vec2 K=e(g);
       vec4 G=texture2DLod(shadowcolor,K,0);
       float F=G.w*255.;
       if(abs(F-36.)<.1||abs(F-38.)<.1)
         {
           continue;
         }
       if(F<240.)
         {
           if(D(y.FjeDDzWIWi,F,z,m==0,s,n))
             {
               r=0.;
               break;
             }
         }
       b(y);
     }
   const float m=x*.33;
   r=mix(r,1.,saturate(s-m));
   return r;
 }
 vec3 H(vec3 v)
 {
   vec4 x=vec4(v,1.);
   x=shadowModelView*x;
   x=shadowProjection*x;
   x/=x.w;
   float s=sqrt(x.x*x.x+x.y*x.y),i=1.f-SHADOW_MAP_BIAS+s*SHADOW_MAP_BIAS;
   x.xy*=.95f/i;
   x.z=mix(x.z,.5,.8);
   x=x*.5f+.5f;
   x.xyz=FinalShadowProjectionTransformation(x.xyz);
   return x.xyz;
 }
 vec3 H(vec3 v,vec3 x,vec3 i,vec3 z,vec3 f,int y)
 {
   if(rainStrength>.99)
     return vec3(0.);
   v-=Fract01(cameraPosition+.5);
   float r,n;
   vec3 s=WorldPosToShadowProjPosBias(v,z,.004,r,n),m=vec3(1.)*shadow2DLod(shadowtex0,vec3(s.xy,s.z),1).x;
   m*=saturate(dot(i,z));
   m*=D(x+z*.01,i,y,3);
   {
     vec4 c=texture2DLod(shadowcolor1,s.xy-vec2(0.,.5),3);
     float K=abs(c.x*256.-(v.y+cameraPosition.y)),g=GetCausticsComposite(v,i,K),G=shadow2DLod(shadowtex0,vec3(s.xy-vec2(0.,.5),s.z+1e-06),3).x;
     m=mix(m,m*g,1.-G);
   }
   m=TintUnderwaterDepth(m);
   return m*(1.-rainStrength);
 }
 vec3 M(vec3 v,vec3 x,vec3 i,vec3 z,vec3 f,int y)
 {
   if(rainStrength>.99)
     return vec3(0.);
   vec3 s=T(v);
   s+=1.;
   s-=Fract01(cameraPosition+.5);
   float r,n;
   vec3 m=WorldPosToShadowProjPosBias(s+z*.99,z,.004,r,n),c=vec3(1.)*shadow2DLod(shadowtex0,vec3(m.xy,m.z),1).x;
   c*=saturate(dot(i,z));
   c*=D(x+z*.99,i,y,3);
   c=TintUnderwaterDepth(c);
   #ifdef GI_SUNLIGHT_STAINED_GLASS_TINT
   float K=shadow2DLod(shadowtex0,vec3(m.xy-vec2(.5,0.),m.z),3).x;
   vec3 g=texture2DLod(shadowcolor,vec2(m.xy-vec2(.5,0.)),3).xyz;
   g*=g;
   c=mix(c,c*g,vec3(1.-K));
   #endif
   return c*(1.-rainStrength);
 }
 vec3 P(vec3 v,vec3 x,vec3 i,vec3 z,vec3 f,int y)
 {
   if(rainStrength>.99)
     return vec3(0.);
   v+=1.;
   v-=Fract01(cameraPosition+.5);
   float r,n;
   vec3 s=WorldPosToShadowProjPosBias(v,z,.004,r,n);
   float m=.5;
   vec3 c=vec3(1.)*shadow2DLod(shadowtex0,vec3(s.xy,s.z-.0006*m),2).x;
   c*=saturate(dot(i,z));
   c*=D(x+z*.01,i,y,3);
   c=TintUnderwaterDepth(c);
   #ifdef GI_SUNLIGHT_STAINED_GLASS_TINT
   float K=shadow2DLod(shadowtex0,vec3(s.xy-vec2(.5,0.),s.z-.0006*m),3).x;
   vec3 g=texture2DLod(shadowcolor,vec2(s.xy-vec2(.5,0.)),3).xyz;
   g*=g;
   c=mix(c,c*g,vec3(1.-K));
   #endif
   return c*(1.-rainStrength);
 }
 vec3 Q(vec2 v)
 {
   vec2 x=vec2(v.xy*vec2(viewWidth,viewHeight));
   x*=1./64.;
   const vec2 s[16]=vec2[16](vec2(-1,-1),vec2(0,-.333333),vec2(-.5,.333333),vec2(.5,-.777778),vec2(-.75,-.111111),vec2(.25,.555556),vec2(-.25,-.555556),vec2(.75,.111111),vec2(-.875,.777778),vec2(.125,-.925926),vec2(-.375,-.259259),vec2(.625,.407407),vec2(-.625,-.703704),vec2(.375,-.037037),vec2(-.125,.62963),vec2(.875,-.481482));
   if(v.x<2./viewWidth||v.x>1.-2./viewWidth||v.y<2./viewHeight||v.y>1.-2./viewHeight)
     ;
   else
      x+=s[frameCounter/2%16]*.5;
   x=(floor(x*64.)+.5)/64.;
   vec3 i=texture2D(noisetex,x).xyz,z=vec3(sqrt(.2),sqrt(2.),1.61803);
   i=mod(i+float(frameCounter%2)*.5,vec3(1.));
   return i;
 }
 vec4 H(vec3 v,vec2 y,out float i,inout float r)
 {
   vec3 z=v;
   v=clamp(v,vec3(c),vec3(1.-c));
   if(distance(v,z)>.005*c)
     r=1.;
   float s=dot(abs(v-z),vec3(1.));
   #ifdef MC_GL_VENDOR_ATI
   #endif
   vec2 m=e(v);
   m+=y.xy*x;
   m=m*2.-1.;
   i=s;
   return vec4(m,i,1.);
 }
 void main()
 {
   gl_Position=ftransform();
   vec4 x=gl_TextureMatrix[1]*gl_MultiTexCoord1;
   vec2 v;
   v.x=clamp(x.x*33.05f/32.f-.0328125f,0.f,1.f);
   v.y=clamp(x.y*33.75f/32.f-.0328125f,0.f,1.f);
   UqThFbItbV=v;
   vTexcoord=gl_MultiTexCoord0;
   vMCEntity=mc_Entity.x;
   vViewPos=gl_ModelViewMatrix*gl_Vertex;
   vec4 i=gl_Position;
   i=shadowProjectionInverse*i;
   i=shadowModelViewInverse*i;
   i.xyz+=cameraPosition.xyz;
   vec3 s=i.xyz;
   vMaterialIDs=30.;
   float r=0.,z=0.f,m=0.f;
   if(mc_Entity.x==8||mc_Entity.x==9)
     r=1.f;
   if(mc_Entity.x==95||mc_Entity.x==160||mc_Entity.x==90||mc_Entity.x==165||mc_Entity.x==79)
     m=1.f;
   if(mc_Entity.x==79)
     z=1.f;
   if(mc_Entity.x==18.||mc_Entity.x==161.f)
     vMaterialIDs=36.;
   if(mc_Entity.x==79.f||mc_Entity.x==174.f)
     vMaterialIDs=37.;
   if(mc_Entity.x==50||mc_Entity.x==48||mc_Entity.x==54||mc_Entity.x==52||mc_Entity.x>=44&&mc_Entity.x<48||mc_Entity.x==49||mc_Entity.x==76)
     vMaterialIDs=241.;
   if(mc_Entity.x==10||mc_Entity.x==11)
     vMaterialIDs=38.;
   if(mc_Entity.x==89||mc_Entity.x==124||mc_Entity.x==169||mc_Entity.x==91)
     vMaterialIDs=31.;
   if(mc_Entity.x==51||mc_Entity.x==53||mc_Entity.x==55)
     vMaterialIDs=241.;
   #ifdef GLOWING_LAPIS_LAZULI_BLOCK
   if(mc_Entity.x==22)
     vMaterialIDs=31.;
   #endif
   #ifdef GLOWING_REDSTONE_BLOCK
   if(mc_Entity.x==152)
     vMaterialIDs=31.;
   #endif
   #ifdef GLOWING_EMERALD_BLOCK
   if(mc_Entity.x==133)
     vMaterialIDs=31.;
   #endif
   if(mc_Entity.x==95||mc_Entity.x==160)
     vMaterialIDs=240.;
   if(mc_Entity.x==188)
     vMaterialIDs=32.;
   if(mc_Entity.x==189)
     vMaterialIDs=33.;
   if(mc_Entity.x==190)
     vMaterialIDs=34.;
   if(mc_Entity.x==191)
     vMaterialIDs=35.;
   vec3 n=gl_Normal,c=normalize(gl_NormalMatrix*n);
   if(abs(vMaterialIDs-2.)<.1)
     n=vec3(0.,1.,0.);
   ZfZgcmXvXI=mc_midTexCoord.xy;
   vColor=gl_Color;
   uJkrQHnPMQ=0.;
   {
     vec2 f;
     vec3 y=P(i.xyz,gl_Normal.xyz,vTexcoord.xy,mc_midTexCoord.xy,at_tangent,mc_Entity,uJkrQHnPMQ,f);
     if(mc_Entity.x>255)
       vMaterialIDs=mc_Entity.x-255.+39.;
     y=floor(y);
     dYtQRwLdfr=y;
     y-=cameraPosition.xyz;
     int K=t();
     y=w(y);
     uNkKekmbQG=H(y,f,OSdgfZDpvW,uJkrQHnPMQ);
     if(mc_Entity.x==51||mc_Entity.x==55||mc_Entity.x==53||mc_Entity.x==10||mc_Entity.x==11||mc_Entity.x==50||mc_Entity.x==48||mc_Entity.x>=44&&mc_Entity.x<48||mc_Entity.x==49||mc_Entity.x==52||mc_Entity.x==76)
       uNkKekmbQG.z+=.4;
     if(mc_Entity.x==54)
       uNkKekmbQG.z+=.4;
     uNkKekmbQG.z=mix(uNkKekmbQG.z,1.,saturate(1.-UqThFbItbV.y)*.9);
   }
   {
     i.xyz-=cameraPosition.xyz;
     i=shadowModelView*i;
     i=shadowProjection*i;
     gl_Position=i;
     float y=sqrt(gl_Position.x*gl_Position.x+gl_Position.y*gl_Position.y),f=1.f-SHADOW_MAP_BIAS+y*SHADOW_MAP_BIAS;
     gl_Position.xy*=.95f/f;
     gl_Position.xyz=FinalShadowProjectionTransformation(gl_Position.xyz);
     if(r>.5)
       gl_Position.y-=1.;
     if(m>.5)
       gl_Position.x-=1.;
     gl_Position.z=mix(gl_Position.z,.5,.8);
     cBXAVBFelQ=gl_Position;
     gl_FrontColor=gl_Color;
   }
 };



