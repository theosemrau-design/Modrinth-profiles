#version 330 compatibility




/*
 _______ _________ _______  _______  _ 
(  ____ \\__   __/(  ___  )(  ____ )( )
| (    \/   ) (   | (   ) || (    )|| |
| (_____    | |   | |   | || (____)|| |
(_____  )   | |   | |   | ||  _____)| |
      ) |   | |   | |   | || (      (_)
/\____) |   | |   | (___) || )       _ 
\_______)   )_(   (_______)|/       (_)

Do not modify this code until you have read the LICENSE.txt contained in the root directory of this shaderpack!

*/


#include "lib/Uniforms.inc"
#include "lib/Common.inc"


const bool colortex6MipmapEnabled = false;


in vec4 texcoord;

in vec3 lightVector;
in vec3 worldLightVector;
in vec3 worldSunVector;

in float timeMidnight;

in vec3 colorSunlight;
in vec3 colorSkylight;
in vec3 colorSkyUp;
in vec3 colorTorchlight;

in vec4 skySHR;
in vec4 skySHG;
in vec4 skySHB;

#include "lib/GBufferData.inc"


// vec4 GetViewPosition(in vec2 coord, in float depth) 
// {	
// 	vec4 tcoord = vec4(coord.xy, 0.0, 0.0);

// 	vec4 fragposition = gbufferProjectionInverse * vec4(tcoord.s * 2.0f - 1.0f, tcoord.t * 2.0f - 1.0f, 2.0f * depth - 1.0f, 1.0f);
// 		 fragposition /= fragposition.w;

	
// 	return fragposition;
// }





#include "lib/Materials.inc"


 const float x=1./float(8192);
 ivec2 v=ivec2(viewWidth,viewHeight),s=ivec2(6144,6144);
 int z=v.x*v.y,f=37748736;
 int t(int v)
 {
   return v-FloorToInt(mod(float(v),2.))-0;
 }
 int d(int v)
 {
   return v-FloorToInt(mod(float(v),2.))-1;
 }
 int d()
 {
   return t(FloorToInt(floor(pow(float(z),.333333))));
 }
 int t()
 {
   return d(FloorToInt(floor(pow(float(f),.333333))));
 }
 int y=d();
 float m=1./y;
 int i=t();
 float n=1./i;
 vec3 e(vec2 i)
 {
   ivec2 s=ivec2(i.x*v.x,i.y*v.y);
   float x=float(s.y/y),f=float(int(s.x+mod(v.x*x,y))/y);
   f+=floor(v.x*x/y);
   vec3 m=vec3(0.,0.,f);
   m.x=mod(s.x+mod(v.x*x,y),y);
   m.y=mod(s.y,y);
   m.xyz=floor(m.xyz);
   m/=y;
   m.xyz=m.xzy;
   return m;
 }
 vec2 p(vec3 m)
 {
   vec3 i=m.xzy*y;
   i=floor(i+1e-05);
   float x=i.z;
   vec2 f;
   f.x=mod(i.x+x*y,v.x);
   float s=i.x+x*y;
   f.y=i.y+floor(s/v.x)*y;
   f+=.5;
   f/=v;
   return f;
 }
 vec3 r(vec2 v)
 {
   vec2 f=v;
   f.xy/=.75;
   int x=s.x*s.y;
   ivec2 d=ivec2(f.x*s.x,f.y*s.y);
   float y=float(d.y/i),z=float(int(d.x+mod(s.x*y,i))/i);
   z+=floor(s.x*y/i);
   vec3 m=vec3(0.,0.,z);
   m.x=mod(d.x+mod(s.x*y,i),i);
   m.y=mod(d.y,i);
   m.xyz=floor(m.xyz);
   m/=i;
   m.xyz=m.xzy;
   return m;
 }
 vec2 w(vec3 v)
 {
   v=clamp(v,vec3(0.),vec3(1.));
   vec3 f=v.xzy*i;
   f=floor(f+1e-05);
   float x=f.z;
   vec2 m;
   m.x=mod(f.x+x*i,s.x);
   float c=f.x+x*i;
   m.y=f.y+floor(c/s.x)*i;
   m+=.5;
   m/=s;
   m.xy*=.75;
   return m;
 }
 const int c=384,K=c/2-64;
 int l=(c-i)/2;
 float G=floor(cameraPosition.y+.5),h=clamp(G,K-l,K-l),a=G-h;
 vec3 g(vec3 v)
 {
   return v.y+=a,v*=n,v=v+vec3(.5),v;
 }
 vec3 F(vec3 v)
 {
   return v=g(v),v=clamp(v,vec3(0.),vec3(1.)),v;
 }
 vec3 T(vec3 v)
 {
   return v=v-vec3(.5),v*=i,v.y-=a,v;
 }
 vec3 P(vec3 v)
 {
   return v*=m,v=v+vec3(.5),v=clamp(v,vec3(0.),vec3(1.)),v;
 }
 vec3 D(vec3 v)
 {
   return v=v-vec3(.5),v*=y,v;
 }
 vec3 D()
 {
   vec3 v=cameraPosition.xyz+.5,f=previousCameraPosition.xyz+.5,x=floor(v-.0001),i=floor(f-.0001);
   return x-i;
 }
 vec3 D(vec3 v,vec3 f,vec2 s,vec2 x,vec4 i,vec4 d,inout float y,out vec2 m)
 {
   bool r=fract(v.x*2.)>.01&&fract(v.x*2.)<.99||fract(v.y*2.)>.01&&fract(v.y*2.)<.99||fract(v.z*2.)>.01&&fract(v.z*2.)<.99;
   r=!r;
   if(d.x==8||d.x==9||d.x==79||d.x<1.||!r||d.x==20.||d.x==171.||min(abs(f.x),abs(f.z))>.2)
     y=1.;
   if(d.x==50.||d.x==48.||d.x>=44&&d.x<48||d.x==49.||d.x==52.||d.x==76.)
     {
       y=0.;
       if(f.y<.5)
         y=1.;
     }
   if(d.x==54)
     y=0.;
   if(d.x==51||d.x==53||d.x==55)
     y=0.;
   if(d.x>255)
     y=0.;
   vec3 z,c;
   if(f.x>.5)
     z=vec3(0.,0.,-1.),c=vec3(0.,-1.,0.);
   else
      if(f.x<-.5)
       z=vec3(0.,0.,1.),c=vec3(0.,-1.,0.);
     else
        if(f.y>.5)
         z=vec3(1.,0.,0.),c=vec3(0.,0.,1.);
       else
          if(f.y<-.5)
           z=vec3(1.,0.,0.),c=vec3(0.,0.,-1.);
         else
            if(f.z>.5)
             z=vec3(1.,0.,0.),c=vec3(0.,-1.,0.);
           else
              if(f.z<-.5)
               z=vec3(-1.,0.,0.),c=vec3(0.,-1.,0.);
   m=clamp((s.xy-x.xy)*100000.,vec2(0.),vec2(1.));
   float n=.15,K=.15;
   if(d.x==10.||d.x==11.)
     n=.1,K=.1,y=0.;
   if(d.x==51||d.x==55||d.x==53)
     n=.5,K=.1;
   if(d.x==76)
     n=.2,K=.2;
   if(d.x-255.+39.>=103.&&d.x-255.+39.<=113.)
     K=.025,n=.025;
   z=normalize(i.xyz);
   c=normalize(cross(z,f.xyz)*sign(i.w));
   vec3 e=v.xyz+mix(z*n,-z*n,vec3(m.x));
   e.xyz+=mix(c*n,-c*n,vec3(m.y));
   e.xyz-=f.xyz*K;
   return e;
 }struct TOuWFelenO{vec3 FjeDDzWIWi;vec3 FjeDDzWIWiOrigin;vec3 gjulCSuvVu;vec3 ihCMMEIfgL;vec3 HHiebGwFJJ;vec3 GTJIHvOSbK;};
 TOuWFelenO W(Ray v)
 {
   TOuWFelenO f;
   f.FjeDDzWIWi=floor(v.origin);
   f.FjeDDzWIWiOrigin=f.FjeDDzWIWi;
   f.gjulCSuvVu=abs(vec3(length(v.direction))/(v.direction+1e-07));
   f.ihCMMEIfgL=sign(v.direction);
   f.HHiebGwFJJ=(sign(v.direction)*(f.FjeDDzWIWi-v.origin)+sign(v.direction)*.5+.5)*f.gjulCSuvVu;
   f.GTJIHvOSbK=vec3(0.);
   return f;
 }
 void b(inout TOuWFelenO v)
 {
   v.GTJIHvOSbK=step(v.HHiebGwFJJ.xyz,v.HHiebGwFJJ.yzx)*step(v.HHiebGwFJJ.xyz,v.HHiebGwFJJ.zxy),v.HHiebGwFJJ+=v.GTJIHvOSbK*v.gjulCSuvVu,v.FjeDDzWIWi+=v.GTJIHvOSbK*v.ihCMMEIfgL;
 }
 vec3 D(const vec3 v,const vec3 f,vec3 y)
 {
   vec3 x=(f+v)*.5,m=(f-v)*.5,i=y-x,d=abs(i);
   d/=m;
   vec3 z=step(d.yzx,d.xyz)*step(d.zxy,d.xyz);
   return z*sign(i);
 }
 bool D(const vec3 v,const vec3 f,Ray m,inout float x,inout vec3 y)
 {
   vec3 z=m.inv_direction*(v-1e-05-m.origin),s=m.inv_direction*(f+1e-05-m.origin),d=min(s,z),i=max(s,z);
   vec2 c=max(d.xx,d.yz);
   float n=max(c.x,c.y);
   c=min(i.xx,i.yz);
   float G=min(c.x,c.y);
   bool t=G>max(n,0.)&&max(n,0.)<x;
   if(t)
     y=D(v,f,m.origin+m.direction*n),x=n;
   return t;
 }
 float B(vec3 v)
 {
   return 1.;
 }struct eAMCZAKEcI{float nrlJXyapkV;float vPMmNoxUfq;float QQevGhUGeB;float VSCbvpIaKi;vec3 vyHfppOAPK;};
 vec4 R(eAMCZAKEcI v)
 {
   vec4 f;
   v.vyHfppOAPK=max(vec3(0.),v.vyHfppOAPK);
   f.x=v.nrlJXyapkV;
   v.vyHfppOAPK=pow(v.vyHfppOAPK,vec3(.125));
   f.y=PackTwo16BitTo32Bit(v.vyHfppOAPK.x,v.QQevGhUGeB);
   f.z=PackTwo16BitTo32Bit(v.vyHfppOAPK.y,v.VSCbvpIaKi);
   f.w=PackTwo16BitTo32Bit(v.vyHfppOAPK.z,v.vPMmNoxUfq/255.);
   return f;
 }
 eAMCZAKEcI o(vec4 v)
 {
   eAMCZAKEcI f;
   vec2 m=UnpackTwo16BitFrom32Bit(v.y),d=UnpackTwo16BitFrom32Bit(v.z),s=UnpackTwo16BitFrom32Bit(v.w);
   f.nrlJXyapkV=v.x;
   f.QQevGhUGeB=m.y;
   f.VSCbvpIaKi=d.y;
   f.vPMmNoxUfq=s.y*255.;
   f.vyHfppOAPK=pow(vec3(m.x,d.x,s.x),vec3(8.));
   return f;
 }
 eAMCZAKEcI U(vec2 v)
 {
   return v=(floor(v*ScreenSize)+.5)*ScreenTexel,o(texture2DLod(colortex5,v,0));
 }
 vec3 B(vec3 v,vec3 y)
 {
   vec3 f=P(T(v)+y+1.+D());
   float x=B(f);
   vec2 z=p(f);
   vec3 i=U(z).vyHfppOAPK;
   return i*x;
 }
 vec3 D(vec3 v,vec3 y)
 {
   vec3 f=P(T(v)+y+1.);
   float x=B(f);
   vec2 z=p(f);
   vec3 t=U(z).vyHfppOAPK;
   return t*x;
 }
 float F(float v,float y)
 {
   float x=1.;
   #ifdef FULL_RT_REFLECTIONS
   x=clamp(pow(v,.125)+y,0.,1.);
   #else
   x=clamp(v*10.-7.,0.,1.);
   #endif
   return x;
 }
 bool B(vec3 v,float y,Ray f,bool z,inout float i,inout vec3 x)
 {
   bool m=false,s=false;
   #if RAYTRACE_GEOMETRY_QUALITY==0
   if(z)
     return false;
   if(y>=67.)
     return false;
   s=D(v,v+vec3(1.,1.,1.),f,i,x);
   m=s;
   #else
   if(y<40.)
     return s=D(v,v+vec3(1.,1.,1.),f,i,x),s;
   if(y==40.||y==41.||y>=43.&&y<=54.)
     {
       float c=.5;
       if(y==41.)
         c=.9375;
       s=D(v+vec3(0.,0.,0.),v+vec3(1.,c,1.),f,i,x);
       m=m||s;
     }
   if(y==42.||y>=55.&&y<=66.)
     s=D(v+vec3(0.,.5,0.),v+vec3(1.,1.,1.),f,i,x),m=m||s;
   if(y==43.||y==46.||y==47.||y==52.||y==53.||y==54.||y==55.||y==58.||y==59.||y==64.||y==65.||y==66.)
     {
       float c=.5;
       if(y==55.||y==58.||y==59.||y==64.||y==65.||y==66.)
         c=0.;
       s=D(v+vec3(0.,c,0.),v+vec3(.5,.5+c,.5),f,i,x);
       m=m||s;
     }
   if(y==43.||y==45.||y==48.||y==51.||y==53.||y==54.||y==55.||y==57.||y==60.||y==63.||y==65.||y==66.)
     {
       float c=.5;
       if(y==55.||y==57.||y==60.||y==63.||y==65.||y==66.)
         c=0.;
       s=D(v+vec3(.5,c,0.),v+vec3(1.,.5+c,.5),f,i,x);
       m=m||s;
     }
   if(y==44.||y==45.||y==49.||y==51.||y==52.||y==54.||y==56.||y==57.||y==61.||y==63.||y==64.||y==66.)
     {
       float c=.5;
       if(y==56.||y==57.||y==61.||y==63.||y==64.||y==66.)
         c=0.;
       s=D(v+vec3(.5,c,.5),v+vec3(1.,.5+c,1.),f,i,x);
       m=m||s;
     }
   if(y==44.||y==46.||y==50.||y==51.||y==52.||y==53.||y==56.||y==58.||y==62.||y==63.||y==64.||y==65.)
     {
       float c=.5;
       if(y==56.||y==58.||y==62.||y==63.||y==64.||y==65.)
         c=0.;
       s=D(v+vec3(0.,c,.5),v+vec3(.5,.5+c,1.),f,i,x);
       m=m||s;
     }
   if(y>=67.&&y<=82.)
     s=D(v+vec3(6.,0.,6.)/16.,v+vec3(10.,16.,10.)/16.,f,i,x),m=m||s;
   if(y==68.||y==69.||y==70.||y==72.||y==73.||y==74.||y==76.||y==77.||y==78.||y==80.||y==81.||y==82.)
     {
       float c=8.,d=8.;
       if(y==68.||y==70.||y==72.||y==74.||y==76.||y==78.||y==80.||y==82.)
         c=0.;
       if(y==69.||y==70.||y==73.||y==74.||y==77.||y==78.||y==81.||y==82.)
         d=16.;
       s=D(v+vec3(c,6.,7.)/16.,v+vec3(d,9.,9.)/16.,f,i,x);
       m=m||s;
       s=D(v+vec3(c,12.,7.)/16.,v+vec3(d,15.,9.)/16.,f,i,x);
       m=m||s;
     }
   if(y>=71.&&y<=82.)
     {
       float c=8.,n=8.;
       if(y>=71.&&y<=74.||y>=79.&&y<=82.)
         n=16.;
       if(y>=75.&&y<=82.)
         c=0.;
       s=D(v+vec3(7.,6.,c)/16.,v+vec3(9.,9.,n)/16.,f,i,x);
       m=m||s;
       s=D(v+vec3(7.,12.,c)/16.,v+vec3(9.,15.,n)/16.,f,i,x);
       m=m||s;
     }
   #if RAYTRACE_GEOMETRY_QUALITY==2
   if(y>=83.&&y<=86.)
     {
       vec3 c=vec3(0),K=vec3(0);
       if(y==83.)
         c=vec3(0,0,0),K=vec3(16,16,3);
       if(y==84.)
         c=vec3(0,0,13),K=vec3(16,16,16);
       if(y==86.)
         c=vec3(0,0,0),K=vec3(3,16,16);
       if(y==85.)
         c=vec3(13,0,0),K=vec3(16,16,16);
       s=D(v+c/16.,v+K/16.,f,i,x);
       m=m||s;
     }
   if(y>=87.&&y<=102.)
     {
       vec3 c=vec3(0.),r=vec3(1.);
       if(y>=87.&&y<=94.)
         {
           float n=0.;
           if(y>=91.&&y<=94.)
             n=13.;
           c=vec3(0.,n,0.)/16.;
           r=vec3(16.,n+3.,16.)/16.;
         }
       if(y>=95.&&y<=98.)
         {
           float n=13.;
           if(y==97.||y==98.)
             n=0.;
           c=vec3(0.,0.,n)/16.;
           r=vec3(16.,16.,n+3.)/16.;
         }
       if(y>=99.&&y<=102.)
         {
           float n=13.;
           if(y==99.||y==100.)
             n=0.;
           c=vec3(n,0.,0.)/16.;
           r=vec3(n+3.,16.,16.)/16.;
         }
       s=D(v+c,v+r,f,i,x);
       m=m||s;
     }
   if(y>=103.&&y<=113.)
     {
       vec3 c=vec3(0.),d=vec3(1.);
       if(y>=103.&&y<=110.)
         {
           float n=float(y)-float(103.)+1.;
           d.y=n*2./16.;
         }
       if(y==111.)
         d.y=.0625;
       if(y==112.)
         c=vec3(1.,0.,1.)/16.,d=vec3(15.,1.,15.)/16.;
       if(y==113.)
         c=vec3(1.,0.,1.)/16.,d=vec3(15.,.5,15.)/16.;
       s=D(v+c,v+d,f,i,x);
       m=m||s;
     }
   #endif
   #endif
   return m;
 }
 float B(vec3 v,vec3 f,int x,const int m)
 {
   Ray y=MakeRay(v,f);
   TOuWFelenO s=W(y);
   float i=1.,c=100000.;
   vec3 z=vec3(0.);
   for(int r=0;r<m;r++)
     {
       vec3 d=s.FjeDDzWIWi*n;
       vec2 K=w(d);
       vec4 G=texture2DLod(shadowcolor,K,0);
       float t=G.w*255.;
       if(abs(t-36.)<.1||abs(t-38.)<.1)
         {
           continue;
         }
       if(t<240.)
         {
           if(B(s.FjeDDzWIWi,t,y,r==0,c,z))
             {
               i=0.;
               break;
             }
         }
       b(s);
     }
   const float d=m*.33;
   i=mix(i,1.,saturate(c-d));
   return i;
 }
 vec3 H(vec3 v)
 {
   vec4 y=vec4(v,1.);
   y=shadowModelView*y;
   y=shadowProjection*y;
   y/=y.w;
   float x=sqrt(y.x*y.x+y.y*y.y),i=1.f-SHADOW_MAP_BIAS+x*SHADOW_MAP_BIAS;
   y.xy*=.95f/i;
   y.z=mix(y.z,.5,.8);
   y=y*.5f+.5f;
   y.xyz=FinalShadowProjectionTransformation(y.xyz);
   return y.xyz;
 }
 vec3 D(vec3 v,vec3 f,vec3 i,vec3 x,vec3 y,int z)
 {
   if(rainStrength>.99)
     return vec3(0.);
   v-=Fract01(cameraPosition+.5);
   float c,s;
   vec3 d=WorldPosToShadowProjPosBias(v,x,.004,c,s),m=vec3(1.)*shadow2DLod(shadowtex0,vec3(d.xy,d.z),1).x;
   m*=saturate(dot(i,x));
   m*=B(f+x*.01,i,z,3);
   {
     vec4 n=texture2DLod(shadowcolor1,d.xy-vec2(0.,.5),3);
     float K=abs(n.x*256.-(v.y+cameraPosition.y)),r=GetCausticsComposite(v,i,K),t=shadow2DLod(shadowtex0,vec3(d.xy-vec2(0.,.5),d.z+1e-06),3).x;
     m=mix(m,m*r,1.-t);
   }
   m=TintUnderwaterDepth(m);
   return m*(1.-rainStrength);
 }
 vec3 F(vec3 v,vec3 f,vec3 i,vec3 x,vec3 y,int z)
 {
   if(rainStrength>.99)
     return vec3(0.);
   vec3 m=T(v);
   m+=1.;
   m-=Fract01(cameraPosition+.5);
   float c,s;
   vec3 d=WorldPosToShadowProjPosBias(m+x*.99,x,.004,c,s),n=vec3(1.)*shadow2DLod(shadowtex0,vec3(d.xy,d.z),1).x;
   n*=saturate(dot(i,x));
   n*=B(f+x*.99,i,z,3);
   n=TintUnderwaterDepth(n);
   #ifdef GI_SUNLIGHT_STAINED_GLASS_TINT
   float K=shadow2DLod(shadowtex0,vec3(d.xy-vec2(.5,0.),d.z),3).x;
   vec3 r=texture2DLod(shadowcolor,vec2(d.xy-vec2(.5,0.)),3).xyz;
   r*=r;
   n=mix(n,n*r,vec3(1.-K));
   #endif
   return n*(1.-rainStrength);
 }
 vec3 H(vec3 v,vec3 f,vec3 i,vec3 x,vec3 y,int z)
 {
   if(rainStrength>.99)
     return vec3(0.);
   v+=1.;
   v-=Fract01(cameraPosition+.5);
   float c,s;
   vec3 d=WorldPosToShadowProjPosBias(v,x,.004,c,s);
   float n=.5;
   vec3 m=vec3(1.)*shadow2DLod(shadowtex0,vec3(d.xy,d.z-.0006*n),2).x;
   m*=saturate(dot(i,x));
   m*=B(f+x*.01,i,z,3);
   m=TintUnderwaterDepth(m);
   #ifdef GI_SUNLIGHT_STAINED_GLASS_TINT
   float K=shadow2DLod(shadowtex0,vec3(d.xy-vec2(.5,0.),d.z-.0006*n),3).x;
   vec3 r=texture2DLod(shadowcolor,vec2(d.xy-vec2(.5,0.)),3).xyz;
   r*=r;
   m=mix(m,m*r,vec3(1.-K));
   #endif
   return m*(1.-rainStrength);
 }
 vec3 V(vec2 v)
 {
   vec2 y=vec2(v.xy*vec2(viewWidth,viewHeight));
   y*=1./64.;
   const vec2 m[16]=vec2[16](vec2(-1,-1),vec2(0,-.333333),vec2(-.5,.333333),vec2(.5,-.777778),vec2(-.75,-.111111),vec2(.25,.555556),vec2(-.25,-.555556),vec2(.75,.111111),vec2(-.875,.777778),vec2(.125,-.925926),vec2(-.375,-.259259),vec2(.625,.407407),vec2(-.625,-.703704),vec2(.375,-.037037),vec2(-.125,.62963),vec2(.875,-.481482));
   if(v.x<2./viewWidth||v.x>1.-2./viewWidth||v.y<2./viewHeight||v.y>1.-2./viewHeight)
     ;
   else
      y+=m[frameCounter/2%16]*.5;
   y=(floor(y*64.)+.5)/64.;
   vec3 f=texture2D(noisetex,y).xyz,c=vec3(sqrt(.2),sqrt(2.),1.61803);
   f=mod(f+float(frameCounter%2)*.5,vec3(1.));
   return f;
 }
 float H(float v,float y)
 {
   return 1./(v*(1.-y)+y);
 }
 void B(inout vec3 v,in vec3 y,in vec3 f,vec3 i,float z)
 {
   float m=length(y);
   m*=pow(eyeBrightnessSmooth.y/240.f,6.f);
   m*=rainStrength;
   float x=pow(exp(-m*3e-06),4.);
   vec3 c=vec3(dot(colorSkyUp,vec3(1.)));
   v=mix(c,v,vec3(x));
 }
 vec4 C(vec2 v)
 {
   vec2 y=vec2(v.x,(v.y-floor(mod(FRAME_TIME*60.f,60.f)))/60.f);
   return texture2DLod(colortex4,y.xy,0);
 }
 float C(vec3 v,float y)
 {
   vec3 f=v.xyz+cameraPosition.xyz,m=refract(worldLightVector,vec3(0.,1.,0.),.750188);
   f+=m*((v.y+cameraPosition.y)/m.y);
   vec4 d=C(mod(f.xz/4.,vec2(1.)))*13.;
   float x=pow(y/2.,.5),i=pow(d.x,saturate(x*.5+.5));
   i=mix(i,d.y,saturate(x-1.));
   i=mix(i,d.z,saturate(x-2.));
   i=mix(i,d.w,saturate(x-3.));
   return i;
 }
 float P(float v,float y)
 {
   return exp(-pow(v/(.9*y),2.));
 }
 float R(vec3 v,vec3 y)
 {
   return dot(abs(v-y),vec3(.3333));
 }
 vec3 Q(vec2 v)
 {
   vec2 y=vec2(v.xy*ScreenSize)/64.;
   const vec2 f[16]=vec2[16](vec2(-1,-1),vec2(0,-.333333),vec2(-.5,.333333),vec2(.5,-.777778),vec2(-.75,-.111111),vec2(.25,.555556),vec2(-.25,-.555556),vec2(.75,.111111),vec2(-.875,.777778),vec2(.125,-.925926),vec2(-.375,-.259259),vec2(.625,.407407),vec2(-.625,-.703704),vec2(.375,-.037037),vec2(-.125,.62963),vec2(.875,-.481482));
   if(v.x<2./viewWidth||v.x>1.-2./viewWidth||v.y<2./viewHeight||v.y>1.-2./viewHeight)
     ;
   y=(floor(y*64.)+.5)/64.;
   vec3 i=texture2D(noisetex,y).xyz,x=vec3(sqrt(.2),sqrt(2.),1.61803);
   i=mod(i+vec3(x)*mod(frameCounter,64.f),vec3(1.));
   return i;
 }
 vec3 C(float v,float f,float m,vec3 y)
 {
   vec3 i;
   i.x=m*cos(v);
   i.y=m*sin(v);
   i.z=f;
   vec3 x=abs(y.y)<.999?vec3(0,0,1):vec3(1,0,0),c=normalize(cross(y,vec3(0.,1.,1.))),s=cross(c,y);
   return c*i.x+s*i.y+y*i.z;
 }
 vec3 B(vec2 v,float y,vec3 f)
 {
   float i=2*3.14159*v.x,x=sqrt((1-v.y)/(1+(y*y-1)*v.y)),c=sqrt(1-x*x);
   return C(i,x,c,f);
 }
 float L(float v)
 {
   return 2./(v*v+1e-07)-2.;
 }
 vec3 C(in vec2 v,in float y,in vec3 f)
 {
   float c=L(y),i=2*3.14159*v.x,x=pow(v.y,1.f/(c+1.f)),s=sqrt(1-x*x);
   return C(i,x,s,f);
 }
 float u(vec2 v)
 {
   return texture2DLod(colortex1,v+HalfScreen,0).w;
 }
 float L(float v,float y)
 {
   return v/(y*20.01+1.);
 }
 vec2 Q(vec2 v,float y)
 {
   vec2 x=v;
   mat2 m=mat2(cos(y),-sin(y),sin(y),cos(y));
   v=m*v;
   return v;
 }
 vec4 B(sampler2D v,float m,bool y,float f,float i,float x,float z)
 {
   GBufferData d=GetGBufferData(texcoord.xy);
   GBufferDataTransparent s=GetGBufferDataTransparent(texcoord.xy);
   bool c=s.depth<d.depth;
   if(c)
     d.normal=s.normal,d.smoothness=s.smoothness,d.metalness=0.,d.mcLightmap=s.mcLightmap,d.depth=s.depth;
   vec4 n=GetViewPosition(texcoord.xy,d.depth),K=gbufferModelViewInverse*vec4(n.xyz,1.),t=gbufferModelViewInverse*vec4(n.xyz,0.);
   vec3 r=normalize(n.xyz),l=normalize(t.xyz),h=normalize((gbufferModelViewInverse*vec4(d.normal,0.)).xyz);
   float G=GetDepthLinear(texcoord.xy),w=dot(-r,d.normal.xyz),p=1.-d.smoothness,e=p*p,a=F(d.smoothness,d.metalness);
   vec4 o=texture2DLod(v,texcoord.xy+HalfScreen,0);
   float T=Luminance(o.xyz);
   if(a<.001)
     return o;
   float g=m*.9;
   g*=min(e*20.,1.1);
   g*=mix(o.w,1.,.2);
   vec2 H=vec2(0.);
   if(y)
     {
       vec2 P=BlueNoiseTemporal(texcoord.xy).xy*.99+.005;
       H=P-.5;
     }
   float P=BlueNoiseTemporal(texcoord.xy).x,S=1.1,b=L(f,d.totalTexGrad)/(e+.0001),R=L(i*.5,d.totalTexGrad);
   vec4 B=vec4(0.),J=vec4(0.);
   float W=0.;
   vec4 V=vec4(vec3(x),1.);
   V.xyz=vec3(1.);
   V.xyz*=o.w*.95+.05;
   float u=d.smoothness;
   vec2 D=normalize(cross(d.normal,r).xy),k=Q(D,1.5708);
   float Y=1.-pow(1.-saturate(w),1.);
   D*=mix(.1075,.5,Y);
   k*=mix(mix(.7,.7,e),.5,Y);
   g*=1.8;
   vec3 U=reflect(-r,d.normal);
   int C=0;
   for(int M=-1;M<=1;M++)
     {
       for(int q=-1;q<=1;q++)
         {
           vec2 E=vec2(M,q)+H;
           E=E.x*D+E.y*k;
           E*=g*ScreenTexel;
           vec2 I=texcoord.xy+E.xy;
           float A=length(E*ScreenSize);
           I=clamp(I,4.*ScreenTexel,1.-4.*ScreenTexel);
           vec4 O=texture2DLod(v,I+HalfScreen,0);
           vec3 j=GetNormals(I);
           float N=GetDepthLinear(I),Z=pow(saturate(dot(U,reflect(-r,j))),115./e),X=exp(-(abs(N-G)*S)),ab=Z*X;
           B+=vec4(pow(length(O.xyz),V.x)*normalize(O.xyz+1e-10),O.w)*ab;
           W+=ab;
           J+=O;
           C++;
         }
     }
   B/=W+1e-07;
   B.xyz=pow(length(B.xyz),1./V.x)*normalize(B.xyz+1e-08);
   vec4 q=B;
   if(W<.001)
     q=o;
   return q;
 }
 void main()
 {
   GBufferData v=GetGBufferData(texcoord.xy);
   GBufferDataTransparent y=GetGBufferDataTransparent(texcoord.xy);
   MaterialMask x=CalculateMasks(v.materialID,texcoord.xy),d=CalculateMasks(y.materialID,texcoord.xy);
   bool f=y.depth<v.depth;
   if(f)
     v.normal=y.normal,v.smoothness=y.smoothness,v.metalness=0.,v.mcLightmap=y.mcLightmap,v.depth=y.depth,d.sky=0.;
   vec4 i=GetViewPosition(texcoord.xy,v.depth),c=gbufferModelViewInverse*vec4(i.xyz,1.),s=gbufferModelViewInverse*vec4(i.xyz,0.);
   vec3 m=normalize(i.xyz),n=normalize(s.xyz),z=normalize((gbufferModelViewInverse*vec4(v.normal,0.)).xyz);
   float K=ExpToLinearDepth(v.depth),r=1.-v.smoothness,t=r*r,a=F(v.smoothness,v.metalness);
   int e=0;
   vec4 G=texture2DLod(colortex7,texcoord.xy+HalfScreen,e),V=G;
   float p=1.-v.smoothness,h=p*p;
   vec3 l=z,w=-n,I=normalize(reflect(-w,l)+l*h),Y=normalize(w+I);
   float g=saturate(dot(l,I)),q=saturate(dot(l,w)),b=saturate(dot(l,Y)),D=saturate(dot(I,Y)),B=v.metalness*.98+.02,S=pow(1.-D,5.),E=B+(1.-B)*S,R=h/2.,k=H(g,R)*H(q+.8,R),T=g*E*k;
   V.xyz*=mix(vec3(1.),v.albedo.xyz,vec3(v.metalness));
   T=mix(T,1.,v.metalness);
   if(v.depth>.99999)
     T=0.;
   if(d.water>.5&&isEyeInWater>0)
     {
       if(length(refract(w,l,1.3333))<.5)
         T=1.;
       else
          T=0.;
     }
   T*=F(v.smoothness,v.metalness);
   vec4 o=texture2DLod(colortex1,texcoord.xy+HalfScreen,0);
   vec3 P=pow(o.xyz,vec3(2.2)),W=P;
   W*=120.;
   if(isEyeInWater>0)
     UnderwaterFog(W,length(s.xyz),n,colorSkyUp,colorSunlight);
   vec3 U=W;
   W=mix(W,V.xyz*12.,vec3(saturate(T)));
   if(d.sky<.5)
     W+=U*v.metalness;
   float C=GetEyeBrightnessBasedCaveLeakFix();
   {
     #ifdef GODRAYS
     #else
     if(isEyeInWater>0)
       #endif
     {
       float u=BlueNoiseTemporal(texcoord.xy).x,O=220.;
       if(isEyeInWater>0)
         O=40.;
       vec3 M=vec3(0.),L=(gbufferModelViewInverse*vec4(0.,0.,0.,1.)).xyz;
       for(int J=0;J<10;J++)
         {
           float j=float(J+u)/float(10);
           vec3 N=n.xyz*O*j+L;
           if(length(s.xyz)<length(N-L))
             {
               break;
             }
           float Q,X;
           vec3 A=WorldPosToShadowProjPos(N.xyz,Q,X),Z=shadow2DLod(shadowtex0,vec3(A.xy,A.z+.0005),3).xxx;
           #ifdef GODRAYS_STAINED_GLASS_TINT
           float ac=shadow2DLod(shadowtex0,vec3(A.xy-vec2(.5,0.),A.z-1e-06),3).x;
           vec3 ad=texture2DLod(shadowcolor,vec2(A.xy-vec2(.5,0.)),3).xyz;
           ad*=ad;
           Z=mix(Z,Z*ad,vec3(1.-ac));
           #endif
           if(isEyeInWater>0)
             {
               float ae=abs(texture2DLod(shadowcolor1,A.xy-vec2(0.,.5),4).x*256.-(N.y+cameraPosition.y)),af=GetCausticsComposite(N,worldLightVector,ae),ag=shadow2DLod(shadowtex0,vec3(A.xy-vec2(0.,.5),A.z+1e-06),4).x;
               Z=mix(Z,Z*af,vec3(1.-ag));
               M+=Z*exp(-GetWaterAbsorption()*(O*j))*exp(-GetWaterAbsorption()*ae);
             }
           else
              M+=Z*colorSunlight*.1;
         }
       float Z=dot(worldLightVector,n.xyz),A=1.;
       if(isEyeInWater>0)
         Z=dot(refract(worldLightVector,vec3(0.,-1.,0.),.750019),n.xyz);
       else
          A=.5/(max(0.,pow(worldLightVector.y,2.)*2.)+.4),A*=C;
       float j=Z*Z,X=PhaseMie(.7,Z,j);
       W+=TintUnderwaterDepth(M*colorSunlight*GetWaterFogColor()*.115*X*A*(1.-wetness));
     }
   }
   if(d.sky<.5&&isEyeInWater<1)
     LandAtmosphericScattering(W,i.xyz,m.xyz,n.xyz,worldSunVector.xyz,1.);
   W/=120.;
   W*=exp(-K*blindness);
   W=pow(W.xyz,vec3(.454545));
   gl_FragData[0]=vec4(W,Luminance(W));
 };





/* DRAWBUFFERS:1 */
