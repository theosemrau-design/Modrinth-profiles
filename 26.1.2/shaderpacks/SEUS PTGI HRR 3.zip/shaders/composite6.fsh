#version 330 compatibility

/*
 _______ _________ _______  _______  _
(  ____ \\__   __/(  ___  )(  ____ )( )
| (    \/   ) (   | (   ) || (    )|| |
| (_____    | |   | |   | || (____)|| |
(_____  )   | |   | |   | ||  _____)| |
      ) |   | |   | |   | || (      (_)
/\____) |   | |   | (___) || )       _
\_______)   )_(   (_______)|/       (_)

Do not modify this code until you have read the LICENSE.txt contained in the root directory of this shaderpack!

*/


#include "lib/Uniforms.inc"
#include "lib/Common.inc"
#include "lib/Materials.inc"


/////////////////////////CONFIGURABLE VARIABLES////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////CONFIGURABLE VARIABLES////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

//fgdhghdf

/////////////////////////END OF CONFIGURABLE VARIABLES/////////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////END OF CONFIGURABLE VARIABLES/////////////////////////////////////////////////////////////////////////////////////////////////////////////


const bool colortex2MipmapEnabled = true;
const bool colortex4MipmapEnabled = true;


in vec4 texcoord;
in vec3 lightVector;


in float timeSunriseSunset;
in float timeNoon;
in float timeMidnight;

in vec3 colorSunlight;
in vec3 colorSkylight;

in mat4 gbufferPreviousModelViewInverse;






#define CURR_COLOR_TEX colortex1
#define PREV_COLOR_TEX colortex3
#define TEMPORAL_DATA_TEX colortex2
#define DEPTHTEX depthtex0


 const float x=1./float(8192);
 ivec2 v=ivec2(viewWidth,viewHeight),f=ivec2(6144,6144);
 int y=v.x*v.y,z=37748736;
 int d(int v)
 {
   return v-FloorToInt(mod(float(v),2.))-0;
 }
 int t(int v)
 {
   return v-FloorToInt(mod(float(v),2.))-1;
 }
 int d()
 {
   return d(FloorToInt(floor(pow(float(y),.333333))));
 }
 int t()
 {
   return t(FloorToInt(floor(pow(float(z),.333333))));
 }
 int m=d();
 float i=1./m;
 int s=t();
 float S=1./s;
 vec3 r(vec2 f)
 {
   ivec2 x=ivec2(f.x*v.x,f.y*v.y);
   float z=float(x.y/m),i=float(int(x.x+mod(v.x*z,m))/m);
   i+=floor(v.x*z/m);
   vec3 c=vec3(0.,0.,i);
   c.x=mod(x.x+mod(v.x*z,m),m);
   c.y=mod(x.y,m);
   c.xyz=floor(c.xyz);
   c/=m;
   c.xyz=c.xzy;
   return c;
 }
 vec2 p(vec3 f)
 {
   vec3 i=f.xzy*m;
   i=floor(i+1e-05);
   float x=i.z;
   vec2 r;
   r.x=mod(i.x+x*m,v.x);
   float c=i.x+x*m;
   r.y=i.y+floor(c/v.x)*m;
   r+=.5;
   r/=v;
   return r;
 }
 vec3 n(vec2 v)
 {
   vec2 i=v;
   i.xy/=.75;
   int x=f.x*f.y;
   ivec2 c=ivec2(i.x*f.x,i.y*f.y);
   float z=float(c.y/s),y=float(int(c.x+mod(f.x*z,s))/s);
   y+=floor(f.x*z/s);
   vec3 m=vec3(0.,0.,y);
   m.x=mod(c.x+mod(f.x*z,s),s);
   m.y=mod(c.y,s);
   m.xyz=floor(m.xyz);
   m/=s;
   m.xyz=m.xzy;
   return m;
 }
 vec2 h(vec3 v)
 {
   v=clamp(v,vec3(0.),vec3(1.));
   vec3 i=v.xzy*s;
   i=floor(i+1e-05);
   float x=i.z;
   vec2 r;
   r.x=mod(i.x+x*s,f.x);
   float c=i.x+x*s;
   r.y=i.y+floor(c/f.x)*s;
   r+=.5;
   r/=f;
   r.xy*=.75;
   return r;
 }
 const int c=384,D=c/2-64;
 int K=(c-s)/2;
 float e=floor(cameraPosition.y+.5),w=clamp(e,D-K,D-K),a=e-w;
 vec3 F(vec3 v)
 {
   return v.y+=a,v*=S,v=v+vec3(.5),v;
 }
 vec3 G(vec3 v)
 {
   return v=F(v),v=clamp(v,vec3(0.),vec3(1.)),v;
 }
 vec3 l(vec3 v)
 {
   return v=v-vec3(.5),v*=s,v.y-=a,v;
 }
 vec3 T(vec3 v)
 {
   return v*=i,v=v+vec3(.5),v=clamp(v,vec3(0.),vec3(1.)),v;
 }
 vec3 R(vec3 v)
 {
   return v=v-vec3(.5),v*=m,v;
 }
 vec3 F()
 {
   vec3 v=cameraPosition.xyz+.5,i=previousCameraPosition.xyz+.5,x=floor(v-.0001),z=floor(i-.0001);
   return x-z;
 }
 vec3 F(vec3 v,vec3 f,vec2 i,vec2 x,vec4 c,vec4 z,inout float r,out vec2 y)
 {
   bool m=fract(v.x*2.)>.01&&fract(v.x*2.)<.99||fract(v.y*2.)>.01&&fract(v.y*2.)<.99||fract(v.z*2.)>.01&&fract(v.z*2.)<.99;
   m=!m;
   if(z.x==8||z.x==9||z.x==79||z.x<1.||!m||z.x==20.||z.x==171.||min(abs(f.x),abs(f.z))>.2)
     r=1.;
   if(z.x==50.||z.x==48.||z.x>=44&&z.x<48||z.x==49.||z.x==52.||z.x==76.)
     {
       r=0.;
       if(f.y<.5)
         r=1.;
     }
   if(z.x==54)
     r=0.;
   if(z.x==51||z.x==53||z.x==55)
     r=0.;
   if(z.x>255)
     r=0.;
   vec3 e,s;
   if(f.x>.5)
     e=vec3(0.,0.,-1.),s=vec3(0.,-1.,0.);
   else
      if(f.x<-.5)
       e=vec3(0.,0.,1.),s=vec3(0.,-1.,0.);
     else
        if(f.y>.5)
         e=vec3(1.,0.,0.),s=vec3(0.,0.,1.);
       else
          if(f.y<-.5)
           e=vec3(1.,0.,0.),s=vec3(0.,0.,-1.);
         else
            if(f.z>.5)
             e=vec3(1.,0.,0.),s=vec3(0.,-1.,0.);
           else
              if(f.z<-.5)
               e=vec3(-1.,0.,0.),s=vec3(0.,-1.,0.);
   y=clamp((i.xy-x.xy)*100000.,vec2(0.),vec2(1.));
   float S=.15,D=.15;
   if(z.x==10.||z.x==11.)
     S=.1,D=.1,r=0.;
   if(z.x==51||z.x==55||z.x==53)
     S=.5,D=.1;
   if(z.x==76)
     S=.2,D=.2;
   if(z.x-255.+39.>=103.&&z.x-255.+39.<=113.)
     D=.025,S=.025;
   e=normalize(c.xyz);
   s=normalize(cross(e,f.xyz)*sign(c.w));
   vec3 n=v.xyz+mix(e*S,-e*S,vec3(y.x));
   n.xyz+=mix(s*S,-s*S,vec3(y.y));
   n.xyz-=f.xyz*D;
   return n;
 }struct TOuWFelenO{vec3 FjeDDzWIWi;vec3 FjeDDzWIWiOrigin;vec3 gjulCSuvVu;vec3 ihCMMEIfgL;vec3 HHiebGwFJJ;vec3 GTJIHvOSbK;};
 TOuWFelenO g(Ray v)
 {
   TOuWFelenO f;
   f.FjeDDzWIWi=floor(v.origin);
   f.FjeDDzWIWiOrigin=f.FjeDDzWIWi;
   f.gjulCSuvVu=abs(vec3(length(v.direction))/(v.direction+1e-07));
   f.ihCMMEIfgL=sign(v.direction);
   f.HHiebGwFJJ=(sign(v.direction)*(f.FjeDDzWIWi-v.origin)+sign(v.direction)*.5+.5)*f.gjulCSuvVu;
   f.GTJIHvOSbK=vec3(0.);
   return f;
 }
 void b(inout TOuWFelenO v)
 {
   v.GTJIHvOSbK=step(v.HHiebGwFJJ.xyz,v.HHiebGwFJJ.yzx)*step(v.HHiebGwFJJ.xyz,v.HHiebGwFJJ.zxy),v.HHiebGwFJJ+=v.GTJIHvOSbK*v.gjulCSuvVu,v.FjeDDzWIWi+=v.GTJIHvOSbK*v.ihCMMEIfgL;
 }
 vec3 F(const vec3 v,const vec3 z,vec3 y)
 {
   vec3 x=(z+v)*.5,m=(z-v)*.5,s=y-x,f=abs(s);
   f/=m;
   vec3 i=step(f.yzx,f.xyz)*step(f.zxy,f.xyz);
   return i*sign(s);
 }
 bool F(const vec3 v,const vec3 f,Ray m,inout float x,inout vec3 y)
 {
   vec3 i=m.inv_direction*(v-1e-05-m.origin),z=m.inv_direction*(f+1e-05-m.origin),c=min(z,i),s=max(z,i);
   vec2 r=max(c.xx,c.yz);
   float S=max(r.x,r.y);
   r=min(s.xx,s.yz);
   float t=min(r.x,r.y);
   bool e=t>max(S,0.)&&max(S,0.)<x;
   if(e)
     y=F(v,f,m.origin+m.direction*S),x=S;
   return e;
 }
 float P(vec3 v)
 {
   return 1.;
 }struct eAMCZAKEcI{float nrlJXyapkV;float vPMmNoxUfq;float QQevGhUGeB;float VSCbvpIaKi;vec3 vyHfppOAPK;};
 vec4 W(eAMCZAKEcI v)
 {
   vec4 f;
   v.vyHfppOAPK=max(vec3(0.),v.vyHfppOAPK);
   f.x=v.nrlJXyapkV;
   v.vyHfppOAPK=pow(v.vyHfppOAPK,vec3(.125));
   f.y=PackTwo16BitTo32Bit(v.vyHfppOAPK.x,v.QQevGhUGeB);
   f.z=PackTwo16BitTo32Bit(v.vyHfppOAPK.y,v.VSCbvpIaKi);
   f.w=PackTwo16BitTo32Bit(v.vyHfppOAPK.z,v.vPMmNoxUfq/255.);
   return f;
 }
 eAMCZAKEcI H(vec4 v)
 {
   eAMCZAKEcI f;
   vec2 i=UnpackTwo16BitFrom32Bit(v.y),m=UnpackTwo16BitFrom32Bit(v.z),s=UnpackTwo16BitFrom32Bit(v.w);
   f.nrlJXyapkV=v.x;
   f.QQevGhUGeB=i.y;
   f.VSCbvpIaKi=m.y;
   f.vPMmNoxUfq=s.y*255.;
   f.vyHfppOAPK=pow(vec3(i.x,m.x,s.x),vec3(8.));
   return f;
 }
 eAMCZAKEcI U(vec2 v)
 {
   return v=(floor(v*ScreenSize)+.5)*ScreenTexel,H(texture2DLod(colortex5,v,0));
 }
 vec3 F(vec3 v,vec3 y)
 {
   vec3 x=T(l(v)+y+1.+F());
   float i=P(x);
   vec2 f=p(x);
   vec3 z=U(f).vyHfppOAPK;
   return z*i;
 }
 vec3 G(vec3 v,vec3 y)
 {
   vec3 x=T(l(v)+y+1.);
   float i=P(x);
   vec2 f=p(x);
   vec3 z=U(f).vyHfppOAPK;
   return z*i;
 }
 float H(float v,float y)
 {
   float x=1.;
   #ifdef FULL_RT_REFLECTIONS
   x=clamp(pow(v,.125)+y,0.,1.);
   #else
   x=clamp(v*10.-7.,0.,1.);
   #endif
   return x;
 }
 bool F(vec3 v,float x,Ray i,bool y,inout float f,inout vec3 z)
 {
   bool m=false,s=false;
   #if RAYTRACE_GEOMETRY_QUALITY==0
   if(y)
     return false;
   if(x>=67.)
     return false;
   s=F(v,v+vec3(1.,1.,1.),i,f,z);
   m=s;
   #else
   if(x<40.)
     return s=F(v,v+vec3(1.,1.,1.),i,f,z),s;
   if(x==40.||x==41.||x>=43.&&x<=54.)
     {
       float r=.5;
       if(x==41.)
         r=.9375;
       s=F(v+vec3(0.,0.,0.),v+vec3(1.,r,1.),i,f,z);
       m=m||s;
     }
   if(x==42.||x>=55.&&x<=66.)
     s=F(v+vec3(0.,.5,0.),v+vec3(1.,1.,1.),i,f,z),m=m||s;
   if(x==43.||x==46.||x==47.||x==52.||x==53.||x==54.||x==55.||x==58.||x==59.||x==64.||x==65.||x==66.)
     {
       float r=.5;
       if(x==55.||x==58.||x==59.||x==64.||x==65.||x==66.)
         r=0.;
       s=F(v+vec3(0.,r,0.),v+vec3(.5,.5+r,.5),i,f,z);
       m=m||s;
     }
   if(x==43.||x==45.||x==48.||x==51.||x==53.||x==54.||x==55.||x==57.||x==60.||x==63.||x==65.||x==66.)
     {
       float r=.5;
       if(x==55.||x==57.||x==60.||x==63.||x==65.||x==66.)
         r=0.;
       s=F(v+vec3(.5,r,0.),v+vec3(1.,.5+r,.5),i,f,z);
       m=m||s;
     }
   if(x==44.||x==45.||x==49.||x==51.||x==52.||x==54.||x==56.||x==57.||x==61.||x==63.||x==64.||x==66.)
     {
       float r=.5;
       if(x==56.||x==57.||x==61.||x==63.||x==64.||x==66.)
         r=0.;
       s=F(v+vec3(.5,r,.5),v+vec3(1.,.5+r,1.),i,f,z);
       m=m||s;
     }
   if(x==44.||x==46.||x==50.||x==51.||x==52.||x==53.||x==56.||x==58.||x==62.||x==63.||x==64.||x==65.)
     {
       float r=.5;
       if(x==56.||x==58.||x==62.||x==63.||x==64.||x==65.)
         r=0.;
       s=F(v+vec3(0.,r,.5),v+vec3(.5,.5+r,1.),i,f,z);
       m=m||s;
     }
   if(x>=67.&&x<=82.)
     s=F(v+vec3(6.,0.,6.)/16.,v+vec3(10.,16.,10.)/16.,i,f,z),m=m||s;
   if(x==68.||x==69.||x==70.||x==72.||x==73.||x==74.||x==76.||x==77.||x==78.||x==80.||x==81.||x==82.)
     {
       float r=8.,c=8.;
       if(x==68.||x==70.||x==72.||x==74.||x==76.||x==78.||x==80.||x==82.)
         r=0.;
       if(x==69.||x==70.||x==73.||x==74.||x==77.||x==78.||x==81.||x==82.)
         c=16.;
       s=F(v+vec3(r,6.,7.)/16.,v+vec3(c,9.,9.)/16.,i,f,z);
       m=m||s;
       s=F(v+vec3(r,12.,7.)/16.,v+vec3(c,15.,9.)/16.,i,f,z);
       m=m||s;
     }
   if(x>=71.&&x<=82.)
     {
       float r=8.,D=8.;
       if(x>=71.&&x<=74.||x>=79.&&x<=82.)
         D=16.;
       if(x>=75.&&x<=82.)
         r=0.;
       s=F(v+vec3(7.,6.,r)/16.,v+vec3(9.,9.,D)/16.,i,f,z);
       m=m||s;
       s=F(v+vec3(7.,12.,r)/16.,v+vec3(9.,15.,D)/16.,i,f,z);
       m=m||s;
     }
   #if RAYTRACE_GEOMETRY_QUALITY==2
   if(x>=83.&&x<=86.)
     {
       vec3 r=vec3(0),D=vec3(0);
       if(x==83.)
         r=vec3(0,0,0),D=vec3(16,16,3);
       if(x==84.)
         r=vec3(0,0,13),D=vec3(16,16,16);
       if(x==86.)
         r=vec3(0,0,0),D=vec3(3,16,16);
       if(x==85.)
         r=vec3(13,0,0),D=vec3(16,16,16);
       s=F(v+r/16.,v+D/16.,i,f,z);
       m=m||s;
     }
   if(x>=87.&&x<=102.)
     {
       vec3 r=vec3(0.),D=vec3(1.);
       if(x>=87.&&x<=94.)
         {
           float e=0.;
           if(x>=91.&&x<=94.)
             e=13.;
           r=vec3(0.,e,0.)/16.;
           D=vec3(16.,e+3.,16.)/16.;
         }
       if(x>=95.&&x<=98.)
         {
           float e=13.;
           if(x==97.||x==98.)
             e=0.;
           r=vec3(0.,0.,e)/16.;
           D=vec3(16.,16.,e+3.)/16.;
         }
       if(x>=99.&&x<=102.)
         {
           float c=13.;
           if(x==99.||x==100.)
             c=0.;
           r=vec3(c,0.,0.)/16.;
           D=vec3(c+3.,16.,16.)/16.;
         }
       s=F(v+r,v+D,i,f,z);
       m=m||s;
     }
   if(x>=103.&&x<=113.)
     {
       vec3 r=vec3(0.),D=vec3(1.);
       if(x>=103.&&x<=110.)
         {
           float e=float(x)-float(103.)+1.;
           D.y=e*2./16.;
         }
       if(x==111.)
         D.y=.0625;
       if(x==112.)
         r=vec3(1.,0.,1.)/16.,D=vec3(15.,1.,15.)/16.;
       if(x==113.)
         r=vec3(1.,0.,1.)/16.,D=vec3(15.,.5,15.)/16.;
       s=F(v+r,v+D,i,f,z);
       m=m||s;
     }
   #endif
   #endif
   return m;
 }
 float F(vec3 v,vec3 z,int f,const int y)
 {
   Ray x=MakeRay(v,z);
   TOuWFelenO m=g(x);
   float i=1.,s=100000.;
   vec3 r=vec3(0.);
   for(int D=0;D<y;D++)
     {
       vec3 c=m.FjeDDzWIWi*S;
       vec2 e=h(c);
       vec4 t=texture2DLod(shadowcolor,e,0);
       float a=t.w*255.;
       if(abs(a-36.)<.1||abs(a-38.)<.1)
         {
           continue;
         }
       if(a<240.)
         {
           if(F(m.FjeDDzWIWi,a,x,D==0,s,r))
             {
               i=0.;
               break;
             }
         }
       b(m);
     }
   const float e=y*.33;
   i=mix(i,1.,saturate(s-e));
   return i;
 }
 vec3 V(vec3 v)
 {
   vec4 x=vec4(v,1.);
   x=shadowModelView*x;
   x=shadowProjection*x;
   x/=x.w;
   float r=sqrt(x.x*x.x+x.y*x.y),s=1.f-SHADOW_MAP_BIAS+r*SHADOW_MAP_BIAS;
   x.xy*=.95f/s;
   x.z=mix(x.z,.5,.8);
   x=x*.5f+.5f;
   x.xyz=FinalShadowProjectionTransformation(x.xyz);
   return x.xyz;
 }
 vec3 G(vec3 v,vec3 x,vec3 f,vec3 z,vec3 i,int y)
 {
   if(rainStrength>.99)
     return vec3(0.);
   v-=Fract01(cameraPosition+.5);
   float r,s;
   vec3 c=WorldPosToShadowProjPosBias(v,z,.004,r,s),m=vec3(1.)*shadow2DLod(shadowtex0,vec3(c.xy,c.z),1).x;
   m*=saturate(dot(f,z));
   m*=F(x+z*.01,f,y,3);
   {
     vec4 e=texture2DLod(shadowcolor1,c.xy-vec2(0.,.5),3);
     float D=abs(e.x*256.-(v.y+cameraPosition.y)),S=GetCausticsComposite(v,f,D),n=shadow2DLod(shadowtex0,vec3(c.xy-vec2(0.,.5),c.z+1e-06),3).x;
     m=mix(m,m*S,1.-n);
   }
   m=TintUnderwaterDepth(m);
   return m*(1.-rainStrength);
 }
 vec3 H(vec3 v,vec3 x,vec3 f,vec3 z,vec3 i,int y)
 {
   if(rainStrength>.99)
     return vec3(0.);
   vec3 r=l(v);
   r+=1.;
   r-=Fract01(cameraPosition+.5);
   float D,s;
   vec3 c=WorldPosToShadowProjPosBias(r+z*.99,z,.004,D,s),m=vec3(1.)*shadow2DLod(shadowtex0,vec3(c.xy,c.z),1).x;
   m*=saturate(dot(f,z));
   m*=F(x+z*.99,f,y,3);
   m=TintUnderwaterDepth(m);
   #ifdef GI_SUNLIGHT_STAINED_GLASS_TINT
   float e=shadow2DLod(shadowtex0,vec3(c.xy-vec2(.5,0.),c.z),3).x;
   vec3 S=texture2DLod(shadowcolor,vec2(c.xy-vec2(.5,0.)),3).xyz;
   S*=S;
   m=mix(m,m*S,vec3(1.-e));
   #endif
   return m*(1.-rainStrength);
 }
 vec3 P(vec3 v,vec3 x,vec3 f,vec3 z,vec3 i,int y)
 {
   if(rainStrength>.99)
     return vec3(0.);
   v+=1.;
   v-=Fract01(cameraPosition+.5);
   float r,s;
   vec3 c=WorldPosToShadowProjPosBias(v,z,.004,r,s);
   float m=.5;
   vec3 D=vec3(1.)*shadow2DLod(shadowtex0,vec3(c.xy,c.z-.0006*m),2).x;
   D*=saturate(dot(f,z));
   D*=F(x+z*.01,f,y,3);
   D=TintUnderwaterDepth(D);
   #ifdef GI_SUNLIGHT_STAINED_GLASS_TINT
   float e=shadow2DLod(shadowtex0,vec3(c.xy-vec2(.5,0.),c.z-.0006*m),3).x;
   vec3 S=texture2DLod(shadowcolor,vec2(c.xy-vec2(.5,0.)),3).xyz;
   S*=S;
   D=mix(D,D*S,vec3(1.-e));
   #endif
   return D*(1.-rainStrength);
 }
 vec3 Q(vec2 v)
 {
   vec2 x=vec2(v.xy*vec2(viewWidth,viewHeight));
   x*=1./64.;
   const vec2 m[16]=vec2[16](vec2(-1,-1),vec2(0,-.333333),vec2(-.5,.333333),vec2(.5,-.777778),vec2(-.75,-.111111),vec2(.25,.555556),vec2(-.25,-.555556),vec2(.75,.111111),vec2(-.875,.777778),vec2(.125,-.925926),vec2(-.375,-.259259),vec2(.625,.407407),vec2(-.625,-.703704),vec2(.375,-.037037),vec2(-.125,.62963),vec2(.875,-.481482));
   if(v.x<2./viewWidth||v.x>1.-2./viewWidth||v.y<2./viewHeight||v.y>1.-2./viewHeight)
     ;
   else
      x+=m[frameCounter/2%16]*.5;
   x=(floor(x*64.)+.5)/64.;
   vec3 i=texture2D(noisetex,x).xyz,s=vec3(sqrt(.2),sqrt(2.),1.61803);
   i=mod(i+float(frameCounter%2)*.5,vec3(1.));
   return i;
 }
 vec2 G(vec2 v,float f,float m,out float x)
 {
   vec2 s=v;
   x=f;
   vec2 r=m*ScreenTexel;
   for(int i=-1;i<=1;i+=2)
     {
       for(int z=-1;z<=1;z+=2)
         {
           vec2 D=v+vec2(i,z)*r;
           float c=texture2DLod(DEPTHTEX,D,0).x;
           if(c<x)
             x=c,s=D;
         }
     }
   return s;
 }
 vec3 o(vec3 y)
 {
   mat3 x=mat3(.2126,.7152,.0722,-.09991,-.33609,.436,.615,-.55861,-.05639);
   return y*x;
 }
 vec3 M(vec3 y)
 {
   mat3 x=mat3(1.,0.,1.28033,1.,-.21482,-.38059,1.,2.12798,0.);
   return y*x;
 }
 vec3 H(vec3 v,vec3 x,vec3 f,vec3 y)
 {
   vec3 r=.5*(x+v),i=.5*(x-v),m=y-r,z=m/i,c=abs(z);
   float s=max(c.x,max(c.y,c.z));
   if(s>1.)
     return r+m/s;
   else
      return y;
 }
 vec4 E(vec2 v)
 {
   return pow(texture2DLod(PREV_COLOR_TEX,v,0),vec4(vec3(1./2.2),1.));
 }
 vec4 J(vec2 v)
 {
   vec2 x=ScreenSize,m=ScreenTexel,s=v*x,f=floor(s-.5)+.5,i=s-f,z=i*i,D=i*z;
   float y=.4;
   vec2 c=-y*D+2.*y*z-y*i,r=(2.-y)*D-(3.-y)*z+1.,e=-(2.-y)*D+(3.-2.*y)*z+y*i,S=y*D-y*z,n=r+e,a=m*(f+e/n);
   vec4 t=E(vec2(a.x,a.y));
   vec2 d=m*(f-1.),K=m*(f+2.);
   vec4 H=vec4(E(vec2(a.x,d.y)).xyz,1.)*(n.x*c.y)+vec4(E(vec2(d.x,a.y)).xyz,1.)*(c.x*n.y)+vec4(t.xyz,1.)*(n.x*n.y)+vec4(E(vec2(K.x,a.y)).xyz,1.)*(S.x*n.y)+vec4(E(vec2(a.x,K.y)).xyz,1.)*(n.x*S.y);
   return pow(vec4(max(vec3(0.),H.xyz*(1./H.w)),t.w),vec4(vec3(2.2),1.));
 }
 void E(vec2 v,vec2 x,float f,out vec3 i,out vec4 r)
 {
   vec4 s=vec4(v.xy*2.-1.,f*2.-1.,1.),m=gbufferProjectionInverse*s;
   m.xyz/=m.w;
   r=gbufferModelViewInverse*vec4(m.xyz,1.);
   i=texture2DLod(colortex8,LockRenderPixelCoord(x),0).xyz*2.;
 }
 vec3 E(vec2 v,float z)
 {
   vec4 x=GetViewPosition(v,z);
   return(gbufferModelViewInverse*vec4(x.xyz,1.)).xyz;
 }
 vec4 C(vec2 v)
 {
   return texture2DLod(CURR_COLOR_TEX,v+HalfScreen,0);
 }
 float C(vec3 v,vec3 z)
 {
   return max(max(abs(v.x-z.x),abs(v.y-z.y)),abs(v.z-z.z));
 }
 void main()
 {
   vec3 x=vec3(0.);
   vec2 v=DownscaleTexcoord(texcoord.xy),m=JitterSampleOffset(0),s=m*ScreenTexel;
   ivec2 i=ivec2(floor(texcoord.xy*ScreenSize+floor(m)));
   float f=i%DOWNSCALE_FACTOR_MULT==ivec2(0)?1.:0.,D=f;
   vec4 c=C(LockRenderPixelCoord(v));
   vec3 r=c.xyz,z=r;
   int e=FloorToInt(c.w*255.+.1);
   float y,S=texture2DLod(DEPTHTEX,v,0).x,n=texture2DLod(depthtex1,v,0).x;
   vec2 a=G(v,S,1.,y);
   vec3 t;
   vec4 d;
   E(a*2.,a,y,t,d);
   float K=length(t.xy)*.2;
   if(S<.7)
     t*=0.;
   vec2 l=texcoord.xy-t.xy*.5,q=cos((fract(abs(texcoord.xy-l.xy)*ScreenSize)*2.-1.)*3.14159)*.5+.5,w=pow(q,vec2(.5));
   vec4 g=J(l.xy);
   float R=texture2D(PREV_COLOR_TEX,l.xy).w;
   vec3 F=texture2DLod(colortex9,l,0).xyz;
   const int T=4;
   vec3 p=vec3(0.),b=vec3(0.),L=vec3(0.);
   const float V=.7;
   for(int X=-1;X<=1;X+=2)
     {
       for(int h=-1;h<=1;h+=2)
         {
           vec3 P=texture2DLod(CURR_COLOR_TEX,v.xy+vec2(X,h)*V*ScreenTexel+HalfScreen,0).xyz;
           p+=P;
           P=o(P);
           b+=P;
           L+=P*P;
         }
     }
   b*=.25;
   L*=.25;
   p*=.25;
   eAMCZAKEcI h=U(texcoord.xy);
   h.vPMmNoxUfq+=1.;
   float P=20.,X=1.;
   P=mix(14.,3.5,saturate(K*110.));
   #ifdef GREEDY_TAA
   #endif
   float Q=0.;
   vec3 u=vec3(0.);
   {
     {
       vec2 Y=texcoord.xy;
       Y+=JitterSampleOffset(0)*ScreenTexel;
       float B=0.;
       for(int I=3;I<=3;I++)
         {
           vec2 A=ScreenTexel*exp2(float(I))*.5;
           vec4 O=(texture2DLod(colortex2,DownscaleTexcoord(Y.xy)+vec2(0.,HalfScreen.y)+A.xy*vec2(1.,1.),I)+texture2DLod(colortex2,DownscaleTexcoord(Y.xy)+vec2(0.,HalfScreen.y)+A.xy*vec2(1.,-1.),I)+texture2DLod(colortex2,DownscaleTexcoord(Y.xy)+vec2(0.,HalfScreen.y)+A.xy*vec2(-1.,1.),I)+texture2DLod(colortex2,DownscaleTexcoord(Y.xy)+vec2(0.,HalfScreen.y)+A.xy*vec2(-1.,-1.),I))*.25;
           vec3 j=O.xyz;
           float N=pow(O.w,1.);
           vec3 k=(texture2DLod(colortex2,DownscaleTexcoord(l.xy)+HalfScreen+A.xy*vec2(1.,1.),I).xyz+texture2DLod(colortex2,DownscaleTexcoord(l.xy)+HalfScreen+A.xy*vec2(1.,-1.),I).xyz+texture2DLod(colortex2,DownscaleTexcoord(l.xy)+HalfScreen+A.xy*vec2(-1.,1.),I).xyz+texture2DLod(colortex2,DownscaleTexcoord(l.xy)+HalfScreen+A.xy*vec2(-1.,-1.),I).xyz)*.25;
           float Z=1./(N+1e-09),ab=C(j,k)*Z;
           u=vec3(N);
           ab*=exp2(float(I));
           B+=pow(ab,10.);
         }
       B=pow(B,.1);
       Q=B*mix(.02,.02,saturate(K*50.))*15.;
       if(e==MAT_ID_HAND)
         Q*=3.;
       else
          if(S<n)
           Q*=1.+min(length(t.xy)*6200./(length(d)+.5),10.);
       if(ExpToLinearDepth(S)-ExpToLinearDepth(y)>.9)
         Q*=2.;
     }
     {
       vec4 Y=gbufferProjectionInverse*vec4(l.xy*2.-1.,R*2.-1.,1.);
       Y/=Y.w;
       vec3 I=(gbufferPreviousModelViewInverse*vec4(Y.xyz,1.)).xyz;
       I+=previousCameraPosition;
       I-=cameraPosition;
       float B=length(d.xyz),k=length(I.xyz),N=length(d.xyz-I)/(B+.001);
       N=max(0.,N-.05*1);
       Q*=1.+saturate(N*15.)*(length(t-F)*4000.+10./(sqrt(B*k)+.001));
     }
     float I=exp(-Q);
     f=mix(1.,f,I);
     X=mix(1.,X,I);
     if(I<.95)
       r=mix(C(v-HalfScreen+JitterSampleOffset(0)*ScreenTexel*.5).xyz,r,vec3(I));
     h.vPMmNoxUfq*=exp(-Q*.2);
   }
   h.vPMmNoxUfq=max(h.vPMmNoxUfq,1.);
   h.vPMmNoxUfq=min(h.vPMmNoxUfq,128.);
   if(l.x<0.||l.x>1.||l.y<0.||l.y>1.)
     X=1.,f=1.,h.vPMmNoxUfq=0.;
   if(ExpToLinearDepth(S)-ExpToLinearDepth(y)>.9)
     ;
   vec3 B=sqrt(max(vec3(0.),L-b*b)),I=b-P*B,N=b+P*B;
   g.xyz=M(H(I,N,r.xyz,o(g.xyz)));
   #ifdef SKIP_AA
   f=1.;
   X=1.;
   #endif
   vec3 Y=mix(g.xyz,r,vec3(X*f));
   Y=max(vec3(0.),Y);
   gl_FragData[0]=vec4(u,1.);
   gl_FragData[1]=vec4(Y,y);
   gl_FragData[2]=W(h);
   gl_FragData[3]=vec4(l.xy,0.,1.);
 };




/* DRAWBUFFERS:2357 */
