#version 330 compatibility



/*
 _______ _________ _______  _______  _ 
(  ____ \\__   __/(  ___  )(  ____ )( )
| (    \/   ) (   | (   ) || (    )|| |
| (_____    | |   | |   | || (____)|| |
(_____  )   | |   | |   | ||  _____)| |
      ) |   | |   | |   | || (      (_)
/\____) |   | |   | (___) || )       _ 
\_______)   )_(   (_______)|/       (_)

Do not modify this code until you have read the LICENSE.txt contained in the root directory of this shaderpack!

*/

/////////ADJUSTABLE VARIABLES//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////ADJUSTABLE VARIABLES//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////



//#define HALF_RES_TRACE

/////////INTERNAL VARIABLES////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////INTERNAL VARIABLES////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//Do not change the name of these variables or their type. The Shaders Mod reads these lines and determines values to send to the inner-workings
//of the shaders mod. The shaders mod only reads these lines and doesn't actually know the real value assigned to these variables in GLSL.
//Some of these variables are critical for proper operation. Change at your own risk.

//END OF INTERNAL VARIABLES//




in vec4 texcoord;

in float timeMidnight;

in vec3 colorSunlight;
in vec3 colorSkylight;
in vec3 colorSkyUp;
in vec3 colorTorchlight;

in vec4 skySHR;
in vec4 skySHG;
in vec4 skySHB;


in vec3 worldLightVector;
in vec3 worldSunVector;


in mat4 gbufferPreviousModelViewInverse;
in mat4 gbufferPreviousProjectionInverse;


#include "lib/Uniforms.inc"
#include "lib/Common.inc"

#include "lib/Materials.inc"


/////////////////////////FUNCTIONS/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////FUNCTIONS/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////






// vec4 GetViewPosition(in vec2 coord, in float depth) 
// {	
// 	vec2 tcoord = coord;
// 	TemporalJitterProjPosInv01(tcoord);

// 	vec4 fragposition = gbufferProjectionInverse * vec4(tcoord.s * 2.0f - 1.0f, tcoord.t * 2.0f - 1.0f, 2.0f * depth - 1.0f, 1.0f);
// 		 fragposition /= fragposition.w;

	
// 	return fragposition;
// }













#include "lib/GBufferData.inc"
 const float x=1./float(8192);
 ivec2 v=ivec2(viewWidth,viewHeight),s=ivec2(6144,6144);
 int z=v.x*v.y,y=37748736;
 int f(int v)
 {
   return v-FloorToInt(mod(float(v),2.))-0;
 }
 int t(int v)
 {
   return v-FloorToInt(mod(float(v),2.))-1;
 }
 int f()
 {
   return f(FloorToInt(floor(pow(float(z),.333333))));
 }
 int t()
 {
   return t(FloorToInt(floor(pow(float(y),.333333))));
 }
 int i=f();
 float m=1./i;
 int n=t();
 float c=1./n;
 vec3 d(vec2 n)
 {
   ivec2 s=ivec2(n.x*v.x,n.y*v.y);
   float x=float(s.y/i),f=float(int(s.x+mod(v.x*x,i))/i);
   f+=floor(v.x*x/i);
   vec3 c=vec3(0.,0.,f);
   c.x=mod(s.x+mod(v.x*x,i),i);
   c.y=mod(s.y,i);
   c.xyz=floor(c.xyz);
   c/=i;
   c.xyz=c.xzy;
   return c;
 }
 vec2 e(vec3 n)
 {
   vec3 f=n.xzy*i;
   f=floor(f+1e-05);
   float x=f.z;
   vec2 r;
   r.x=mod(f.x+x*i,v.x);
   float s=f.x+x*i;
   r.y=f.y+floor(s/v.x)*i;
   r+=.5;
   r/=v;
   return r;
 }
 vec3 r(vec2 v)
 {
   vec2 i=v;
   i.xy/=.75;
   int x=s.x*s.y;
   ivec2 f=ivec2(i.x*s.x,i.y*s.y);
   float z=float(f.y/n),y=float(int(f.x+mod(s.x*z,n))/n);
   y+=floor(s.x*z/n);
   vec3 c=vec3(0.,0.,y);
   c.x=mod(f.x+mod(s.x*z,n),n);
   c.y=mod(f.y,n);
   c.xyz=floor(c.xyz);
   c/=n;
   c.xyz=c.xzy;
   return c;
 }
 vec2 p(vec3 v)
 {
   v=clamp(v,vec3(0.),vec3(1.));
   vec3 f=v.xzy*n;
   f=floor(f+1e-05);
   float x=f.z;
   vec2 i;
   i.x=mod(f.x+x*n,s.x);
   float c=f.x+x*n;
   i.y=f.y+floor(c/s.x)*n;
   i+=.5;
   i/=s;
   i.xy*=.75;
   return i;
 }
 const int a=384,w=a/2-64;
 int h=(a-n)/2;
 float F=floor(cameraPosition.y+.5),K=clamp(F,w-h,w-h),l=F-K;
 vec3 G(vec3 v)
 {
   return v.y+=l,v*=c,v=v+vec3(.5),v;
 }
 vec3 g(vec3 v)
 {
   return v=G(v),v=clamp(v,vec3(0.),vec3(1.)),v;
 }
 vec3 T(vec3 v)
 {
   return v=v-vec3(.5),v*=n,v.y-=l,v;
 }
 vec3 P(vec3 v)
 {
   return v*=m,v=v+vec3(.5),v=clamp(v,vec3(0.),vec3(1.)),v;
 }
 vec3 R(vec3 v)
 {
   return v=v-vec3(.5),v*=i,v;
 }
 vec3 G()
 {
   vec3 v=cameraPosition.xyz+.5,f=previousCameraPosition.xyz+.5,x=floor(v-.0001),i=floor(f-.0001);
   return x-i;
 }
 vec3 G(vec3 v,vec3 f,vec2 s,vec2 i,vec4 c,vec4 x,inout float z,out vec2 n)
 {
   bool r=fract(v.x*2.)>.01&&fract(v.x*2.)<.99||fract(v.y*2.)>.01&&fract(v.y*2.)<.99||fract(v.z*2.)>.01&&fract(v.z*2.)<.99;
   r=!r;
   if(x.x==8||x.x==9||x.x==79||x.x<1.||!r||x.x==20.||x.x==171.||min(abs(f.x),abs(f.z))>.2)
     z=1.;
   if(x.x==50.||x.x==48.||x.x>=44&&x.x<48||x.x==49.||x.x==52.||x.x==76.)
     {
       z=0.;
       if(f.y<.5)
         z=1.;
     }
   if(x.x==54)
     z=0.;
   if(x.x==51||x.x==53||x.x==55)
     z=0.;
   if(x.x>255)
     z=0.;
   vec3 y,e;
   if(f.x>.5)
     y=vec3(0.,0.,-1.),e=vec3(0.,-1.,0.);
   else
      if(f.x<-.5)
       y=vec3(0.,0.,1.),e=vec3(0.,-1.,0.);
     else
        if(f.y>.5)
         y=vec3(1.,0.,0.),e=vec3(0.,0.,1.);
       else
          if(f.y<-.5)
           y=vec3(1.,0.,0.),e=vec3(0.,0.,-1.);
         else
            if(f.z>.5)
             y=vec3(1.,0.,0.),e=vec3(0.,-1.,0.);
           else
              if(f.z<-.5)
               y=vec3(-1.,0.,0.),e=vec3(0.,-1.,0.);
   n=clamp((s.xy-i.xy)*100000.,vec2(0.),vec2(1.));
   float t=.15,K=.15;
   if(x.x==10.||x.x==11.)
     t=.1,K=.1,z=0.;
   if(x.x==51||x.x==55||x.x==53)
     t=.5,K=.1;
   if(x.x==76)
     t=.2,K=.2;
   if(x.x-255.+39.>=103.&&x.x-255.+39.<=113.)
     K=.025,t=.025;
   y=normalize(c.xyz);
   e=normalize(cross(y,f.xyz)*sign(c.w));
   vec3 J=v.xyz+mix(y*t,-y*t,vec3(n.x));
   J.xyz+=mix(e*t,-e*t,vec3(n.y));
   J.xyz-=f.xyz*K;
   return J;
 }struct TOuWFelenO{vec3 FjeDDzWIWi;vec3 FjeDDzWIWiOrigin;vec3 gjulCSuvVu;vec3 ihCMMEIfgL;vec3 HHiebGwFJJ;vec3 GTJIHvOSbK;};
 TOuWFelenO D(Ray v)
 {
   TOuWFelenO f;
   f.FjeDDzWIWi=floor(v.origin);
   f.FjeDDzWIWiOrigin=f.FjeDDzWIWi;
   f.gjulCSuvVu=abs(vec3(length(v.direction))/(v.direction+1e-07));
   f.ihCMMEIfgL=sign(v.direction);
   f.HHiebGwFJJ=(sign(v.direction)*(f.FjeDDzWIWi-v.origin)+sign(v.direction)*.5+.5)*f.gjulCSuvVu;
   f.GTJIHvOSbK=vec3(0.);
   return f;
 }
 void b(inout TOuWFelenO v)
 {
   v.GTJIHvOSbK=step(v.HHiebGwFJJ.xyz,v.HHiebGwFJJ.yzx)*step(v.HHiebGwFJJ.xyz,v.HHiebGwFJJ.zxy),v.HHiebGwFJJ+=v.GTJIHvOSbK*v.gjulCSuvVu,v.FjeDDzWIWi+=v.GTJIHvOSbK*v.ihCMMEIfgL;
 }
 vec3 D(const vec3 v,const vec3 f,vec3 n)
 {
   vec3 x=(f+v)*.5,i=(f-v)*.5,y=n-x,c=abs(y);
   c/=i;
   vec3 z=step(c.yzx,c.xyz)*step(c.zxy,c.xyz);
   return z*sign(y);
 }
 bool D(const vec3 v,const vec3 f,Ray x,inout float z,inout vec3 y)
 {
   vec3 i=x.inv_direction*(v-1e-05-x.origin),c=x.inv_direction*(f+1e-05-x.origin),s=min(c,i),n=max(c,i);
   vec2 r=max(s.xx,s.yz);
   float t=max(r.x,r.y);
   r=min(n.xx,n.yz);
   float m=min(r.x,r.y);
   bool e=m>max(t,0.)&&max(t,0.)<z;
   if(e)
     y=D(v,f,x.origin+x.direction*t),z=t;
   return e;
 }
 float W(vec3 v)
 {
   return 1.;
 }struct eAMCZAKEcI{float nrlJXyapkV;float vPMmNoxUfq;float QQevGhUGeB;float VSCbvpIaKi;vec3 vyHfppOAPK;};
 vec4 H(eAMCZAKEcI v)
 {
   vec4 f;
   v.vyHfppOAPK=max(vec3(0.),v.vyHfppOAPK);
   f.x=v.nrlJXyapkV;
   v.vyHfppOAPK=pow(v.vyHfppOAPK,vec3(.125));
   f.y=PackTwo16BitTo32Bit(v.vyHfppOAPK.x,v.QQevGhUGeB);
   f.z=PackTwo16BitTo32Bit(v.vyHfppOAPK.y,v.VSCbvpIaKi);
   f.w=PackTwo16BitTo32Bit(v.vyHfppOAPK.z,v.vPMmNoxUfq/255.);
   return f;
 }
 eAMCZAKEcI o(vec4 v)
 {
   eAMCZAKEcI f;
   vec2 x=UnpackTwo16BitFrom32Bit(v.y),c=UnpackTwo16BitFrom32Bit(v.z),s=UnpackTwo16BitFrom32Bit(v.w);
   f.nrlJXyapkV=v.x;
   f.QQevGhUGeB=x.y;
   f.VSCbvpIaKi=c.y;
   f.vPMmNoxUfq=s.y*255.;
   f.vyHfppOAPK=pow(vec3(x.x,c.x,s.x),vec3(8.));
   return f;
 }
 eAMCZAKEcI U(vec2 v)
 {
   return v=(floor(v*ScreenSize)+.5)*ScreenTexel,o(texture2DLod(colortex5,v,0));
 }
 vec3 D(vec3 v,vec3 z)
 {
   vec3 f=P(T(v)+z+1.+G());
   float x=W(f);
   vec2 y=e(f);
   vec3 i=U(y).vyHfppOAPK;
   return i*x;
 }
 vec3 G(vec3 v,vec3 z)
 {
   vec3 f=P(T(v)+z+1.);
   float x=W(f);
   vec2 y=e(f);
   vec3 i=U(y).vyHfppOAPK;
   return i*x;
 }
 float H(float v,float z)
 {
   float x=1.;
   #ifdef FULL_RT_REFLECTIONS
   x=clamp(pow(v,.125)+z,0.,1.);
   #else
   x=clamp(v*10.-7.,0.,1.);
   #endif
   return x;
 }
 bool D(vec3 v,float x,Ray i,bool f,inout float z,inout vec3 y)
 {
   bool t=false,c=false;
   #if RAYTRACE_GEOMETRY_QUALITY==0
   if(f)
     return false;
   if(x>=67.)
     return false;
   c=D(v,v+vec3(1.,1.,1.),i,z,y);
   t=c;
   #else
   if(x<40.)
     return c=D(v,v+vec3(1.,1.,1.),i,z,y),c;
   if(x==40.||x==41.||x>=43.&&x<=54.)
     {
       float r=.5;
       if(x==41.)
         r=.9375;
       c=D(v+vec3(0.,0.,0.),v+vec3(1.,r,1.),i,z,y);
       t=t||c;
     }
   if(x==42.||x>=55.&&x<=66.)
     c=D(v+vec3(0.,.5,0.),v+vec3(1.,1.,1.),i,z,y),t=t||c;
   if(x==43.||x==46.||x==47.||x==52.||x==53.||x==54.||x==55.||x==58.||x==59.||x==64.||x==65.||x==66.)
     {
       float r=.5;
       if(x==55.||x==58.||x==59.||x==64.||x==65.||x==66.)
         r=0.;
       c=D(v+vec3(0.,r,0.),v+vec3(.5,.5+r,.5),i,z,y);
       t=t||c;
     }
   if(x==43.||x==45.||x==48.||x==51.||x==53.||x==54.||x==55.||x==57.||x==60.||x==63.||x==65.||x==66.)
     {
       float r=.5;
       if(x==55.||x==57.||x==60.||x==63.||x==65.||x==66.)
         r=0.;
       c=D(v+vec3(.5,r,0.),v+vec3(1.,.5+r,.5),i,z,y);
       t=t||c;
     }
   if(x==44.||x==45.||x==49.||x==51.||x==52.||x==54.||x==56.||x==57.||x==61.||x==63.||x==64.||x==66.)
     {
       float r=.5;
       if(x==56.||x==57.||x==61.||x==63.||x==64.||x==66.)
         r=0.;
       c=D(v+vec3(.5,r,.5),v+vec3(1.,.5+r,1.),i,z,y);
       t=t||c;
     }
   if(x==44.||x==46.||x==50.||x==51.||x==52.||x==53.||x==56.||x==58.||x==62.||x==63.||x==64.||x==65.)
     {
       float r=.5;
       if(x==56.||x==58.||x==62.||x==63.||x==64.||x==65.)
         r=0.;
       c=D(v+vec3(0.,r,.5),v+vec3(.5,.5+r,1.),i,z,y);
       t=t||c;
     }
   if(x>=67.&&x<=82.)
     c=D(v+vec3(6.,0.,6.)/16.,v+vec3(10.,16.,10.)/16.,i,z,y),t=t||c;
   if(x==68.||x==69.||x==70.||x==72.||x==73.||x==74.||x==76.||x==77.||x==78.||x==80.||x==81.||x==82.)
     {
       float r=8.,s=8.;
       if(x==68.||x==70.||x==72.||x==74.||x==76.||x==78.||x==80.||x==82.)
         r=0.;
       if(x==69.||x==70.||x==73.||x==74.||x==77.||x==78.||x==81.||x==82.)
         s=16.;
       c=D(v+vec3(r,6.,7.)/16.,v+vec3(s,9.,9.)/16.,i,z,y);
       t=t||c;
       c=D(v+vec3(r,12.,7.)/16.,v+vec3(s,15.,9.)/16.,i,z,y);
       t=t||c;
     }
   if(x>=71.&&x<=82.)
     {
       float r=8.,n=8.;
       if(x>=71.&&x<=74.||x>=79.&&x<=82.)
         n=16.;
       if(x>=75.&&x<=82.)
         r=0.;
       c=D(v+vec3(7.,6.,r)/16.,v+vec3(9.,9.,n)/16.,i,z,y);
       t=t||c;
       c=D(v+vec3(7.,12.,r)/16.,v+vec3(9.,15.,n)/16.,i,z,y);
       t=t||c;
     }
   #if RAYTRACE_GEOMETRY_QUALITY==2
   if(x>=83.&&x<=86.)
     {
       vec3 r=vec3(0),s=vec3(0);
       if(x==83.)
         r=vec3(0,0,0),s=vec3(16,16,3);
       if(x==84.)
         r=vec3(0,0,13),s=vec3(16,16,16);
       if(x==86.)
         r=vec3(0,0,0),s=vec3(3,16,16);
       if(x==85.)
         r=vec3(13,0,0),s=vec3(16,16,16);
       c=D(v+r/16.,v+s/16.,i,z,y);
       t=t||c;
     }
   if(x>=87.&&x<=102.)
     {
       vec3 r=vec3(0.),s=vec3(1.);
       if(x>=87.&&x<=94.)
         {
           float n=0.;
           if(x>=91.&&x<=94.)
             n=13.;
           r=vec3(0.,n,0.)/16.;
           s=vec3(16.,n+3.,16.)/16.;
         }
       if(x>=95.&&x<=98.)
         {
           float n=13.;
           if(x==97.||x==98.)
             n=0.;
           r=vec3(0.,0.,n)/16.;
           s=vec3(16.,16.,n+3.)/16.;
         }
       if(x>=99.&&x<=102.)
         {
           float n=13.;
           if(x==99.||x==100.)
             n=0.;
           r=vec3(n,0.,0.)/16.;
           s=vec3(n+3.,16.,16.)/16.;
         }
       c=D(v+r,v+s,i,z,y);
       t=t||c;
     }
   if(x>=103.&&x<=113.)
     {
       vec3 r=vec3(0.),s=vec3(1.);
       if(x>=103.&&x<=110.)
         {
           float n=float(x)-float(103.)+1.;
           s.y=n*2./16.;
         }
       if(x==111.)
         s.y=.0625;
       if(x==112.)
         r=vec3(1.,0.,1.)/16.,s=vec3(15.,1.,15.)/16.;
       if(x==113.)
         r=vec3(1.,0.,1.)/16.,s=vec3(15.,.5,15.)/16.;
       c=D(v+r,v+s,i,z,y);
       t=t||c;
     }
   #endif
   #endif
   return t;
 }
 float D(vec3 v,vec3 z,int i,const int y)
 {
   Ray x=MakeRay(v,z);
   TOuWFelenO f=D(x);
   float r=1.,s=100000.;
   vec3 n=vec3(0.);
   for(int t=0;t<y;t++)
     {
       vec3 e=f.FjeDDzWIWi*c;
       vec2 K=p(e);
       vec4 m=texture2DLod(shadowcolor,K,0);
       float J=m.w*255.;
       if(abs(J-36.)<.1||abs(J-38.)<.1)
         {
           continue;
         }
       if(J<240.)
         {
           if(D(f.FjeDDzWIWi,J,x,t==0,s,n))
             {
               r=0.;
               break;
             }
         }
       b(f);
     }
   const float t=y*.33;
   r=mix(r,1.,saturate(s-t));
   return r;
 }
 vec3 L(vec3 v)
 {
   vec4 x=vec4(v,1.);
   x=shadowModelView*x;
   x=shadowProjection*x;
   x/=x.w;
   float r=sqrt(x.x*x.x+x.y*x.y),c=1.f-SHADOW_MAP_BIAS+r*SHADOW_MAP_BIAS;
   x.xy*=.95f/c;
   x.z=mix(x.z,.5,.8);
   x=x*.5f+.5f;
   x.xyz=FinalShadowProjectionTransformation(x.xyz);
   return x.xyz;
 }
 vec3 G(vec3 v,vec3 x,vec3 i,vec3 z,vec3 r,int y)
 {
   if(rainStrength>.99)
     return vec3(0.);
   v-=Fract01(cameraPosition+.5);
   float f,n;
   vec3 c=WorldPosToShadowProjPosBias(v,z,.004,f,n),s=vec3(1.)*shadow2DLod(shadowtex0,vec3(c.xy,c.z),1).x;
   s*=saturate(dot(i,z));
   s*=D(x+z*.01,i,y,3);
   {
     vec4 t=texture2DLod(shadowcolor1,c.xy-vec2(0.,.5),3);
     float e=abs(t.x*256.-(v.y+cameraPosition.y)),K=GetCausticsComposite(v,i,e),w=shadow2DLod(shadowtex0,vec3(c.xy-vec2(0.,.5),c.z+1e-06),3).x;
     s=mix(s,s*K,1.-w);
   }
   s=TintUnderwaterDepth(s);
   return s*(1.-rainStrength);
 }
 vec3 H(vec3 v,vec3 x,vec3 i,vec3 z,vec3 r,int y)
 {
   if(rainStrength>.99)
     return vec3(0.);
   vec3 f=T(v);
   f+=1.;
   f-=Fract01(cameraPosition+.5);
   float s,n;
   vec3 c=WorldPosToShadowProjPosBias(f+z*.99,z,.004,s,n),t=vec3(1.)*shadow2DLod(shadowtex0,vec3(c.xy,c.z),1).x;
   t*=saturate(dot(i,z));
   t*=D(x+z*.99,i,y,3);
   t=TintUnderwaterDepth(t);
   #ifdef GI_SUNLIGHT_STAINED_GLASS_TINT
   float e=shadow2DLod(shadowtex0,vec3(c.xy-vec2(.5,0.),c.z),3).x;
   vec3 m=texture2DLod(shadowcolor,vec2(c.xy-vec2(.5,0.)),3).xyz;
   m*=m;
   t=mix(t,t*m,vec3(1.-e));
   #endif
   return t*(1.-rainStrength);
 }
 vec3 L(vec3 v,vec3 x,vec3 i,vec3 z,vec3 r,int y)
 {
   if(rainStrength>.99)
     return vec3(0.);
   v+=1.;
   v-=Fract01(cameraPosition+.5);
   float f,n;
   vec3 c=WorldPosToShadowProjPosBias(v,z,.004,f,n);
   float t=.5;
   vec3 s=vec3(1.)*shadow2DLod(shadowtex0,vec3(c.xy,c.z-.0006*t),2).x;
   s*=saturate(dot(i,z));
   s*=D(x+z*.01,i,y,3);
   s=TintUnderwaterDepth(s);
   #ifdef GI_SUNLIGHT_STAINED_GLASS_TINT
   float e=shadow2DLod(shadowtex0,vec3(c.xy-vec2(.5,0.),c.z-.0006*t),3).x;
   vec3 m=texture2DLod(shadowcolor,vec2(c.xy-vec2(.5,0.)),3).xyz;
   m*=m;
   s=mix(s,s*m,vec3(1.-e));
   #endif
   return s*(1.-rainStrength);
 }
 vec3 S(vec2 x)
 {
   vec2 v=vec2(x.xy*vec2(viewWidth,viewHeight));
   v*=1./64.;
   const vec2 f[16]=vec2[16](vec2(-1,-1),vec2(0,-.333333),vec2(-.5,.333333),vec2(.5,-.777778),vec2(-.75,-.111111),vec2(.25,.555556),vec2(-.25,-.555556),vec2(.75,.111111),vec2(-.875,.777778),vec2(.125,-.925926),vec2(-.375,-.259259),vec2(.625,.407407),vec2(-.625,-.703704),vec2(.375,-.037037),vec2(-.125,.62963),vec2(.875,-.481482));
   if(x.x<2./viewWidth||x.x>1.-2./viewWidth||x.y<2./viewHeight||x.y>1.-2./viewHeight)
     ;
   else
      v+=f[frameCounter/2%16]*.5;
   v=(floor(v*64.)+.5)/64.;
   vec3 i=texture2D(noisetex,v).xyz,c=vec3(sqrt(.2),sqrt(2.),1.61803);
   i=mod(i+float(frameCounter%2)*.5,vec3(1.));
   return i;
 }
 vec2 J;
 vec3 L(vec3 v,vec2 x)
 {
   x=x*.999+.001;
   float f=6.28319*x.x,s=sqrt(x.y);
   vec3 y=normalize(cross(v,vec3(0.,1.,1.))),z=cross(v,y),i=y*cos(f)*s+z*sin(f)*s+v.xyz*sqrt(1.-x.y);
   return i;
 }
 vec3 M(vec2 v)
 {
   float x=2*3.14159*v.x,y=acos(1.-2.*v.y);
   return vec3(sin(x)*sin(y),cos(x)*sin(y),cos(y));
 }
 vec3 M(vec3 v,vec2 x)
 {
   vec3 f=M(x);
   return f*sign(dot(f,v));
 }
 vec3 D()
 {
   vec2 x=e(d(J.xy)+G()*m);
   vec3 v=U(x).vyHfppOAPK;
   return v;
 }
 vec3 D(vec3 v,vec3 f,vec3 x,vec3 i,vec3 z,MaterialMask r,float y,vec2 s,vec3 t,out float e,out vec3 m,float a)
 {
   float K=fract(frameCounter*.0123456),w=1.;
   #ifdef LIGHT_LEAK_FIX
   if(isEyeInWater<1)
     w=saturate(y*100.);
   #endif
   vec3 d=S(J.xy+vec2(0.,0.)).xyz;
   m=M(i,d.xy);
   e=10000.;
   vec3 h=m;
   #ifdef GI_SCREEN_SPACE_TRACING
   bool F=false;
   {
     const int T=5;
     float l=.25*-f.z;
     l=mix(l,.8,.5)*.5;
     float R=.07*-f.z;
     R=mix(R,1.,.5);
     R=.6;
     vec2 o=J.xy;
     vec3 H=f.xyz,Y=normalize((gbufferModelView*vec4(m.xyz,0.)).xyz);
     for(int U=0;U<T;U++)
       {
         float V=float(U),u=(V+.5+d.z)/float(T),B=l*u*u;
         vec3 P=f.xyz+Y*B,W=ProjectBack(P),C=GetViewPositionNoJitter(W.xy,GetDepth(DownscaleTexcoord(W.xy))).xyz;
         float N=length(P)-length(C)-.02;
         if(N>0.&&N<R)
           {
             F=true;
             o=W.xy;
             H=C.xyz;
             break;
           }
       }
     vec3 U=(gbufferModelViewInverse*vec4(H,1.)).xyz;
     U+=Fract01(cameraPosition.xyz+.5)+.5;
     if(F)
       {
         vec3 V=pow(texture2DLod(colortex6,o.xy-s*.5,0).xyz,vec3(2.2))*100.;
         if(length(v.xyz-t.xyz)>.5)
           V=vec3(0.);
         return V;
       }
   }
   #endif
   const float l=2.4,u=l;
   vec3 R=v+x*(.0002*length(v))-z*(a*.2/(saturate(dot(i,-z))+1e-06)+.005);
   R+=Fract01(cameraPosition.xyz+.5);
   Ray T=MakeRay(g(R)*n-vec3(1.,1.,1.),m);
   TOuWFelenO U=D(T);
   vec3 V=vec3(1.),H=vec3(0.);
   float o=0.,B=1.;
   {
     vec4 W=vec4(0.);
     vec3 P=vec3(0.);
     float Y=.5;
     for(int N=0;N<DIFFUSE_TRACE_LENGTH;N++)
       {
         P=U.FjeDDzWIWi*c;
         vec2 C=p(P);
         W=texture2DLod(shadowcolor,C,0);
         o=W.w*255.;
         float Q=1.-step(.5,abs(o-241.));
         vec3 q=W.xyz*GI_LIGHT_TORCH_INTENSITY;
         H+=q*Q*Y*.25;
         #ifdef GI_LEAF_TRANSPARENCY
         if(abs(o-36.)<.1)
           {
             if(d.z<pow(.5,B))
               {
                 b(U);
                 Y=1.;
                 B+=10.;
                 V*=pow(W.xyz,vec3(.25));
                 continue;
               }
           }
         #endif
         if(o<240.)
           {
             if(D(U.FjeDDzWIWi,o,T,N==0,e,h))
               {
                 break;
               }
           }
         b(U);
         Y=1.;
       }
     float N=0.;
     if(o<1.f||o>254.f)
       {
         vec3 C=T.direction;
         if(isEyeInWater>0)
           C=refract(C,vec3(0.,-1.,0.),1.3333);
         vec3 q=SkyShading(C,worldSunVector,rainStrength);
         q*=saturate(C.y*10.+1.);
         q=DoNightEyeAtNight(q*12.,timeMidnight)*.083333;
         if(length(C)<.1)
           N=300.;
         vec3 Q=q*V,I=Q;
         #ifdef CLOUDS_IN_GI
         CloudPlane(I,-T.direction,worldLightVector,worldSunVector,colorSunlight,colorSkyUp,Q,timeMidnight,false);
         #endif
         Q+=StarFlux*timeMidnight;
         Q=TintUnderwaterDepth(Q);
         Q*=saturate(C.y*5.);
         H+=Q*.1*w;
       }
     else
       {
         if(abs(o-31.)<.1||abs(o-38.)<.1)
           H+=.09*V*W.xyz*GI_LIGHT_BLOCK_INTENSITY;
         if(o>=32.&&o<=35.)
           {
             float Q=0.;
             if(abs(o-32.)<.1)
               Q=max(-h.z,0.);
             if(abs(o-33.)<.1)
               Q=max(h.x,0.);
             if(abs(o-34.)<.1)
               Q=max(h.z,0.);
             if(abs(o-35.)<.1)
               Q=max(-h.x,0.);
             H+=.02*V*Q*vec3(1.,.175,.0125)*GI_LIGHT_BLOCK_INTENSITY;
           }
         if(o<240.)
           {
             vec3 Q=saturate(W.xyz);
             V*=Q;
             H+=G(P,h)*V*u;
             vec3 C=L(R+T.direction*e-1.,T.origin+T.direction*e,worldLightVector,h,m,n),q=DoNightEyeAtNight(C*V*l*colorSunlight*w*12.,timeMidnight)/12.;
             H+=q;
             N=e;
           }
       }
     if(isEyeInWater>0)
       UnderwaterFog(H,N,m,colorSkyUp,colorSunlight);
     #ifdef NETHER
     NetherFog(H,N);
     #endif
   }
   H*=saturate(dot(x,m));
   H*=1.57;
   return H;
 }
 void main()
 {
   vec4 x=texture2DLod(colortex2,texcoord.xy,0),v=texture2DLod(colortex7,texcoord.xy,0);
   J=texcoord.xy;
   if(J.x<HalfScreen.x&&J.y>HalfScreen.y)
     {
       J-=vec2(0.,HalfScreen.y);
       GBufferData f=GetGBufferData(J.xy);
       MaterialMask i=CalculateMasks(f.materialID,J.xy);
       vec4 c=GetViewPosition(J.xy,f.depth),s=gbufferModelViewInverse*vec4(c.xyz,1.),n=gbufferModelViewInverse*vec4(c.xyz,0.);
       vec3 r=normalize(c.xyz),y=normalize(n.xyz),z=normalize((gbufferModelViewInverse*vec4(f.normal,0.)).xyz),t=normalize((gbufferModelViewInverse*vec4(f.geoNormal,0.)).xyz);
       float e=length(c.xyz),K=dot(f.mcLightmap.xy,vec2(.5));
       if(i.grass>.5)
         ;
       vec3 m;
       {
         vec2 o=LockRenderPixelCoord(J-f.motion.xy*.5);
         float w=texture2DLod(colortex4,o,0).w;
         vec4 W=gbufferPreviousProjectionInverse*vec4(UndownscaleTexcoord(o)*2.-1.,w*2.-1.,1.);
         W/=W.w;
         m=(gbufferPreviousModelViewInverse*vec4(W.xyz,1.)).xyz;
         m+=previousCameraPosition;
         m-=cameraPosition;
       }
       float o;
       vec3 w,C=D(s.xyz,c.xyz,z.xyz,t,y.xyz,i,f.mcLightmap.y,f.motion.xy,m,o,w,f.parallaxOffset);
       x=vec4(w*.5+.5,1.);
       v=vec4(C,saturate(o*.1));
     }
   gl_FragData[0]=texture2DLod(colortex1,texcoord.xy,0);
   gl_FragData[1]=vec4(x);
   gl_FragData[2]=vec4(v);
 };




/* DRAWBUFFERS:127 */
