#version 330 compatibility




/*
 _______ _________ _______  _______  _ 
(  ____ \\__   __/(  ___  )(  ____ )( )
| (    \/   ) (   | (   ) || (    )|| |
| (_____    | |   | |   | || (____)|| |
(_____  )   | |   | |   | ||  _____)| |
      ) |   | |   | |   | || (      (_)
/\____) |   | |   | (___) || )       _ 
\_______)   )_(   (_______)|/       (_)

Do not modify this code until you have read the LICENSE.txt contained in the root directory of this shaderpack!

*/




in vec4 texcoord;


#include "lib/Uniforms.inc"
#include "lib/Common.inc"
#include "lib/GBufferData.inc"




 const float x=1./float(8192);
 ivec2 v=ivec2(viewWidth,viewHeight),s=ivec2(6144,6144);
 int y=v.x*v.y,i=37748736;
 int f(int v)
 {
   return v-FloorToInt(mod(float(v),2.))-0;
 }
 int t(int v)
 {
   return v-FloorToInt(mod(float(v),2.))-1;
 }
 int f()
 {
   return f(FloorToInt(floor(pow(float(y),.333333))));
 }
 int t()
 {
   return t(FloorToInt(floor(pow(float(i),.333333))));
 }
 int z=f();
 float m=1./z;
 int n=t();
 float K=1./n;
 vec3 d(vec2 n)
 {
   ivec2 x=ivec2(n.x*v.x,n.y*v.y);
   float y=float(x.y/z),i=float(int(x.x+mod(v.x*y,z))/z);
   i+=floor(v.x*y/z);
   vec3 f=vec3(0.,0.,i);
   f.x=mod(x.x+mod(v.x*y,z),z);
   f.y=mod(x.y,z);
   f.xyz=floor(f.xyz);
   f/=z;
   f.xyz=f.xzy;
   return f;
 }
 vec2 r(vec3 f)
 {
   vec3 i=f.xzy*z;
   i=floor(i+1e-05);
   float x=i.z;
   vec2 n;
   n.x=mod(i.x+x*z,v.x);
   float s=i.x+x*z;
   n.y=i.y+floor(s/v.x)*z;
   n+=.5;
   n/=v;
   return n;
 }
 vec3 p(vec2 v)
 {
   vec2 i=v;
   i.xy/=.75;
   int x=s.x*s.y;
   ivec2 f=ivec2(i.x*s.x,i.y*s.y);
   float y=float(f.y/n),z=float(int(f.x+mod(s.x*y,n))/n);
   z+=floor(s.x*y/n);
   vec3 m=vec3(0.,0.,z);
   m.x=mod(f.x+mod(s.x*y,n),n);
   m.y=mod(f.y,n);
   m.xyz=floor(m.xyz);
   m/=n;
   m.xyz=m.xzy;
   return m;
 }
 vec2 e(vec3 v)
 {
   v=clamp(v,vec3(0.),vec3(1.));
   vec3 f=v.xzy*n;
   f=floor(f+1e-05);
   float x=f.z;
   vec2 i;
   i.x=mod(f.x+x*n,s.x);
   float y=f.x+x*n;
   i.y=f.y+floor(y/s.x)*n;
   i+=.5;
   i/=s;
   i.xy*=.75;
   return i;
 }
 const int c=384,H=c/2-64;
 int h=(c-n)/2;
 float F=floor(cameraPosition.y+.5),u=clamp(F,H-h,H-h),a=F-u;
 vec3 w(vec3 v)
 {
   return v.y+=a,v*=K,v=v+vec3(.5),v;
 }
 vec3 G(vec3 v)
 {
   return v=w(v),v=clamp(v,vec3(0.),vec3(1.)),v;
 }
 vec3 T(vec3 v)
 {
   return v=v-vec3(.5),v*=n,v.y-=a,v;
 }
 vec3 P(vec3 v)
 {
   return v*=m,v=v+vec3(.5),v=clamp(v,vec3(0.),vec3(1.)),v;
 }
 vec3 R(vec3 v)
 {
   return v=v-vec3(.5),v*=z,v;
 }
 vec3 G()
 {
   vec3 v=cameraPosition.xyz+.5,x=previousCameraPosition.xyz+.5,i=floor(v-.0001),z=floor(x-.0001);
   return i-z;
 }
 vec3 G(vec3 v,vec3 f,vec2 i,vec2 n,vec4 s,vec4 x,inout float y,out vec2 z)
 {
   bool r=fract(v.x*2.)>.01&&fract(v.x*2.)<.99||fract(v.y*2.)>.01&&fract(v.y*2.)<.99||fract(v.z*2.)>.01&&fract(v.z*2.)<.99;
   r=!r;
   if(x.x==8||x.x==9||x.x==79||x.x<1.||!r||x.x==20.||x.x==171.||min(abs(f.x),abs(f.z))>.2)
     y=1.;
   if(x.x==50.||x.x==48.||x.x>=44&&x.x<48||x.x==49.||x.x==52.||x.x==76.)
     {
       y=0.;
       if(f.y<.5)
         y=1.;
     }
   if(x.x==54)
     y=0.;
   if(x.x==51||x.x==53||x.x==55)
     y=0.;
   if(x.x>255)
     y=0.;
   vec3 m,c;
   if(f.x>.5)
     m=vec3(0.,0.,-1.),c=vec3(0.,-1.,0.);
   else
      if(f.x<-.5)
       m=vec3(0.,0.,1.),c=vec3(0.,-1.,0.);
     else
        if(f.y>.5)
         m=vec3(1.,0.,0.),c=vec3(0.,0.,1.);
       else
          if(f.y<-.5)
           m=vec3(1.,0.,0.),c=vec3(0.,0.,-1.);
         else
            if(f.z>.5)
             m=vec3(1.,0.,0.),c=vec3(0.,-1.,0.);
           else
              if(f.z<-.5)
               m=vec3(-1.,0.,0.),c=vec3(0.,-1.,0.);
   z=clamp((i.xy-n.xy)*100000.,vec2(0.),vec2(1.));
   float K=.15,H=.15;
   if(x.x==10.||x.x==11.)
     K=.1,H=.1,y=0.;
   if(x.x==51||x.x==55||x.x==53)
     K=.5,H=.1;
   if(x.x==76)
     K=.2,H=.2;
   if(x.x-255.+39.>=103.&&x.x-255.+39.<=113.)
     H=.025,K=.025;
   m=normalize(s.xyz);
   c=normalize(cross(m,f.xyz)*sign(s.w));
   vec3 e=v.xyz+mix(m*K,-m*K,vec3(z.x));
   e.xyz+=mix(c*K,-c*K,vec3(z.y));
   e.xyz-=f.xyz*H;
   return e;
 }struct TOuWFelenO{vec3 FjeDDzWIWi;vec3 FjeDDzWIWiOrigin;vec3 gjulCSuvVu;vec3 ihCMMEIfgL;vec3 HHiebGwFJJ;vec3 GTJIHvOSbK;};
 TOuWFelenO W(Ray v)
 {
   TOuWFelenO f;
   f.FjeDDzWIWi=floor(v.origin);
   f.FjeDDzWIWiOrigin=f.FjeDDzWIWi;
   f.gjulCSuvVu=abs(vec3(length(v.direction))/(v.direction+1e-07));
   f.ihCMMEIfgL=sign(v.direction);
   f.HHiebGwFJJ=(sign(v.direction)*(f.FjeDDzWIWi-v.origin)+sign(v.direction)*.5+.5)*f.gjulCSuvVu;
   f.GTJIHvOSbK=vec3(0.);
   return f;
 }
 void g(inout TOuWFelenO v)
 {
   v.GTJIHvOSbK=step(v.HHiebGwFJJ.xyz,v.HHiebGwFJJ.yzx)*step(v.HHiebGwFJJ.xyz,v.HHiebGwFJJ.zxy),v.HHiebGwFJJ+=v.GTJIHvOSbK*v.gjulCSuvVu,v.FjeDDzWIWi+=v.GTJIHvOSbK*v.ihCMMEIfgL;
 }
 vec3 G(const vec3 v,const vec3 f,vec3 y)
 {
   vec3 x=(f+v)*.5,i=(f-v)*.5,z=y-x,s=abs(z);
   s/=i;
   vec3 m=step(s.yzx,s.xyz)*step(s.zxy,s.xyz);
   return m*sign(z);
 }
 bool G(const vec3 v,const vec3 f,Ray x,inout float i,inout vec3 y)
 {
   vec3 z=x.inv_direction*(v-1e-05-x.origin),s=x.inv_direction*(f+1e-05-x.origin),c=min(s,z),n=max(s,z);
   vec2 m=max(c.xx,c.yz);
   float K=max(m.x,m.y);
   m=min(n.xx,n.yz);
   float t=min(m.x,m.y);
   bool e=t>max(K,0.)&&max(K,0.)<i;
   if(e)
     y=G(v,f,x.origin+x.direction*K),i=K;
   return e;
 }
 float U(vec3 v)
 {
   return 1.;
 }struct eAMCZAKEcI{float nrlJXyapkV;float vPMmNoxUfq;float QQevGhUGeB;float VSCbvpIaKi;vec3 vyHfppOAPK;};
 vec4 D(eAMCZAKEcI v)
 {
   vec4 f;
   v.vyHfppOAPK=max(vec3(0.),v.vyHfppOAPK);
   f.x=v.nrlJXyapkV;
   v.vyHfppOAPK=pow(v.vyHfppOAPK,vec3(.125));
   f.y=PackTwo16BitTo32Bit(v.vyHfppOAPK.x,v.QQevGhUGeB);
   f.z=PackTwo16BitTo32Bit(v.vyHfppOAPK.y,v.VSCbvpIaKi);
   f.w=PackTwo16BitTo32Bit(v.vyHfppOAPK.z,v.vPMmNoxUfq/255.);
   return f;
 }
 eAMCZAKEcI o(vec4 v)
 {
   eAMCZAKEcI f;
   vec2 x=UnpackTwo16BitFrom32Bit(v.y),m=UnpackTwo16BitFrom32Bit(v.z),i=UnpackTwo16BitFrom32Bit(v.w);
   f.nrlJXyapkV=v.x;
   f.QQevGhUGeB=x.y;
   f.VSCbvpIaKi=m.y;
   f.vPMmNoxUfq=i.y*255.;
   f.vyHfppOAPK=pow(vec3(x.x,m.x,i.x),vec3(8.));
   return f;
 }
 eAMCZAKEcI L(vec2 v)
 {
   return v=(floor(v*ScreenSize)+.5)*ScreenTexel,o(texture2DLod(colortex5,v,0));
 }
 vec3 D(vec3 v,vec3 z)
 {
   vec3 x=P(T(v)+z+1.+G());
   float y=U(x);
   vec2 f=r(x);
   vec3 i=L(f).vyHfppOAPK;
   return i*y;
 }
 vec3 G(vec3 v,vec3 z)
 {
   vec3 x=P(T(v)+z+1.);
   float y=U(x);
   vec2 f=r(x);
   vec3 i=L(f).vyHfppOAPK;
   return i*y;
 }
 float L(float v,float z)
 {
   float x=1.;
   #ifdef FULL_RT_REFLECTIONS
   x=clamp(pow(v,.125)+z,0.,1.);
   #else
   x=clamp(v*10.-7.,0.,1.);
   #endif
   return x;
 }
 bool D(vec3 v,float x,Ray i,bool f,inout float z,inout vec3 y)
 {
   bool m=false,c=false;
   #if RAYTRACE_GEOMETRY_QUALITY==0
   if(f)
     return false;
   if(x>=67.)
     return false;
   c=G(v,v+vec3(1.,1.,1.),i,z,y);
   m=c;
   #else
   if(x<40.)
     return c=G(v,v+vec3(1.,1.,1.),i,z,y),c;
   if(x==40.||x==41.||x>=43.&&x<=54.)
     {
       float K=.5;
       if(x==41.)
         K=.9375;
       c=G(v+vec3(0.,0.,0.),v+vec3(1.,K,1.),i,z,y);
       m=m||c;
     }
   if(x==42.||x>=55.&&x<=66.)
     c=G(v+vec3(0.,.5,0.),v+vec3(1.,1.,1.),i,z,y),m=m||c;
   if(x==43.||x==46.||x==47.||x==52.||x==53.||x==54.||x==55.||x==58.||x==59.||x==64.||x==65.||x==66.)
     {
       float K=.5;
       if(x==55.||x==58.||x==59.||x==64.||x==65.||x==66.)
         K=0.;
       c=G(v+vec3(0.,K,0.),v+vec3(.5,.5+K,.5),i,z,y);
       m=m||c;
     }
   if(x==43.||x==45.||x==48.||x==51.||x==53.||x==54.||x==55.||x==57.||x==60.||x==63.||x==65.||x==66.)
     {
       float K=.5;
       if(x==55.||x==57.||x==60.||x==63.||x==65.||x==66.)
         K=0.;
       c=G(v+vec3(.5,K,0.),v+vec3(1.,.5+K,.5),i,z,y);
       m=m||c;
     }
   if(x==44.||x==45.||x==49.||x==51.||x==52.||x==54.||x==56.||x==57.||x==61.||x==63.||x==64.||x==66.)
     {
       float K=.5;
       if(x==56.||x==57.||x==61.||x==63.||x==64.||x==66.)
         K=0.;
       c=G(v+vec3(.5,K,.5),v+vec3(1.,.5+K,1.),i,z,y);
       m=m||c;
     }
   if(x==44.||x==46.||x==50.||x==51.||x==52.||x==53.||x==56.||x==58.||x==62.||x==63.||x==64.||x==65.)
     {
       float K=.5;
       if(x==56.||x==58.||x==62.||x==63.||x==64.||x==65.)
         K=0.;
       c=G(v+vec3(0.,K,.5),v+vec3(.5,.5+K,1.),i,z,y);
       m=m||c;
     }
   if(x>=67.&&x<=82.)
     c=G(v+vec3(6.,0.,6.)/16.,v+vec3(10.,16.,10.)/16.,i,z,y),m=m||c;
   if(x==68.||x==69.||x==70.||x==72.||x==73.||x==74.||x==76.||x==77.||x==78.||x==80.||x==81.||x==82.)
     {
       float K=8.,s=8.;
       if(x==68.||x==70.||x==72.||x==74.||x==76.||x==78.||x==80.||x==82.)
         K=0.;
       if(x==69.||x==70.||x==73.||x==74.||x==77.||x==78.||x==81.||x==82.)
         s=16.;
       c=G(v+vec3(K,6.,7.)/16.,v+vec3(s,9.,9.)/16.,i,z,y);
       m=m||c;
       c=G(v+vec3(K,12.,7.)/16.,v+vec3(s,15.,9.)/16.,i,z,y);
       m=m||c;
     }
   if(x>=71.&&x<=82.)
     {
       float K=8.,n=8.;
       if(x>=71.&&x<=74.||x>=79.&&x<=82.)
         n=16.;
       if(x>=75.&&x<=82.)
         K=0.;
       c=G(v+vec3(7.,6.,K)/16.,v+vec3(9.,9.,n)/16.,i,z,y);
       m=m||c;
       c=G(v+vec3(7.,12.,K)/16.,v+vec3(9.,15.,n)/16.,i,z,y);
       m=m||c;
     }
   #if RAYTRACE_GEOMETRY_QUALITY==2
   if(x>=83.&&x<=86.)
     {
       vec3 K=vec3(0),s=vec3(0);
       if(x==83.)
         K=vec3(0,0,0),s=vec3(16,16,3);
       if(x==84.)
         K=vec3(0,0,13),s=vec3(16,16,16);
       if(x==86.)
         K=vec3(0,0,0),s=vec3(3,16,16);
       if(x==85.)
         K=vec3(13,0,0),s=vec3(16,16,16);
       c=G(v+K/16.,v+s/16.,i,z,y);
       m=m||c;
     }
   if(x>=87.&&x<=102.)
     {
       vec3 K=vec3(0.),s=vec3(1.);
       if(x>=87.&&x<=94.)
         {
           float n=0.;
           if(x>=91.&&x<=94.)
             n=13.;
           K=vec3(0.,n,0.)/16.;
           s=vec3(16.,n+3.,16.)/16.;
         }
       if(x>=95.&&x<=98.)
         {
           float n=13.;
           if(x==97.||x==98.)
             n=0.;
           K=vec3(0.,0.,n)/16.;
           s=vec3(16.,16.,n+3.)/16.;
         }
       if(x>=99.&&x<=102.)
         {
           float n=13.;
           if(x==99.||x==100.)
             n=0.;
           K=vec3(n,0.,0.)/16.;
           s=vec3(n+3.,16.,16.)/16.;
         }
       c=G(v+K,v+s,i,z,y);
       m=m||c;
     }
   if(x>=103.&&x<=113.)
     {
       vec3 K=vec3(0.),s=vec3(1.);
       if(x>=103.&&x<=110.)
         {
           float n=float(x)-float(103.)+1.;
           s.y=n*2./16.;
         }
       if(x==111.)
         s.y=.0625;
       if(x==112.)
         K=vec3(1.,0.,1.)/16.,s=vec3(15.,1.,15.)/16.;
       if(x==113.)
         K=vec3(1.,0.,1.)/16.,s=vec3(15.,.5,15.)/16.;
       c=G(v+K,v+s,i,z,y);
       m=m||c;
     }
   #endif
   #endif
   return m;
 }
 float D(vec3 v,vec3 z,int i,const int y)
 {
   Ray x=MakeRay(v,z);
   TOuWFelenO f=W(x);
   float c=1.,s=100000.;
   vec3 n=vec3(0.);
   for(int m=0;m<y;m++)
     {
       vec3 t=f.FjeDDzWIWi*K;
       vec2 H=e(t);
       vec4 d=texture2DLod(shadowcolor,H,0);
       float r=d.w*255.;
       if(abs(r-36.)<.1||abs(r-38.)<.1)
         {
           continue;
         }
       if(r<240.)
         {
           if(D(f.FjeDDzWIWi,r,x,m==0,s,n))
             {
               c=0.;
               break;
             }
         }
       g(f);
     }
   const float m=y*.33;
   c=mix(c,1.,saturate(s-m));
   return c;
 }
 vec3 V(vec3 v)
 {
   vec4 x=vec4(v,1.);
   x=shadowModelView*x;
   x=shadowProjection*x;
   x/=x.w;
   float K=sqrt(x.x*x.x+x.y*x.y),c=1.f-SHADOW_MAP_BIAS+K*SHADOW_MAP_BIAS;
   x.xy*=.95f/c;
   x.z=mix(x.z,.5,.8);
   x=x*.5f+.5f;
   x.xyz=FinalShadowProjectionTransformation(x.xyz);
   return x.xyz;
 }
 vec3 G(vec3 v,vec3 x,vec3 i,vec3 z,vec3 K,int y)
 {
   if(rainStrength>.99)
     return vec3(0.);
   v-=Fract01(cameraPosition+.5);
   float f,n;
   vec3 s=WorldPosToShadowProjPosBias(v,z,.004,f,n),m=vec3(1.)*shadow2DLod(shadowtex0,vec3(s.xy,s.z),1).x;
   m*=saturate(dot(i,z));
   m*=D(x+z*.01,i,y,3);
   {
     vec4 c=texture2DLod(shadowcolor1,s.xy-vec2(0.,.5),3);
     float H=abs(c.x*256.-(v.y+cameraPosition.y)),r=GetCausticsComposite(v,i,H),t=shadow2DLod(shadowtex0,vec3(s.xy-vec2(0.,.5),s.z+1e-06),3).x;
     m=mix(m,m*r,1.-t);
   }
   m=TintUnderwaterDepth(m);
   return m*(1.-rainStrength);
 }
 vec3 L(vec3 v,vec3 x,vec3 i,vec3 z,vec3 K,int y)
 {
   if(rainStrength>.99)
     return vec3(0.);
   vec3 f=T(v);
   f+=1.;
   f-=Fract01(cameraPosition+.5);
   float s,n;
   vec3 m=WorldPosToShadowProjPosBias(f+z*.99,z,.004,s,n),c=vec3(1.)*shadow2DLod(shadowtex0,vec3(m.xy,m.z),1).x;
   c*=saturate(dot(i,z));
   c*=D(x+z*.99,i,y,3);
   c=TintUnderwaterDepth(c);
   #ifdef GI_SUNLIGHT_STAINED_GLASS_TINT
   float t=shadow2DLod(shadowtex0,vec3(m.xy-vec2(.5,0.),m.z),3).x;
   vec3 r=texture2DLod(shadowcolor,vec2(m.xy-vec2(.5,0.)),3).xyz;
   r*=r;
   c=mix(c,c*r,vec3(1.-t));
   #endif
   return c*(1.-rainStrength);
 }
 vec3 P(vec3 v,vec3 x,vec3 i,vec3 z,vec3 K,int y)
 {
   if(rainStrength>.99)
     return vec3(0.);
   v+=1.;
   v-=Fract01(cameraPosition+.5);
   float f,n;
   vec3 s=WorldPosToShadowProjPosBias(v,z,.004,f,n);
   float m=.5;
   vec3 c=vec3(1.)*shadow2DLod(shadowtex0,vec3(s.xy,s.z-.0006*m),2).x;
   c*=saturate(dot(i,z));
   c*=D(x+z*.01,i,y,3);
   c=TintUnderwaterDepth(c);
   #ifdef GI_SUNLIGHT_STAINED_GLASS_TINT
   float t=shadow2DLod(shadowtex0,vec3(s.xy-vec2(.5,0.),s.z-.0006*m),3).x;
   vec3 r=texture2DLod(shadowcolor,vec2(s.xy-vec2(.5,0.)),3).xyz;
   r*=r;
   c=mix(c,c*r,vec3(1.-t));
   #endif
   return c*(1.-rainStrength);
 }
 vec3 Q(vec2 x)
 {
   vec2 v=vec2(x.xy*vec2(viewWidth,viewHeight));
   v*=1./64.;
   const vec2 f[16]=vec2[16](vec2(-1,-1),vec2(0,-.333333),vec2(-.5,.333333),vec2(.5,-.777778),vec2(-.75,-.111111),vec2(.25,.555556),vec2(-.25,-.555556),vec2(.75,.111111),vec2(-.875,.777778),vec2(.125,-.925926),vec2(-.375,-.259259),vec2(.625,.407407),vec2(-.625,-.703704),vec2(.375,-.037037),vec2(-.125,.62963),vec2(.875,-.481482));
   if(x.x<2./viewWidth||x.x>1.-2./viewWidth||x.y<2./viewHeight||x.y>1.-2./viewHeight)
     ;
   else
      v+=f[frameCounter/2%16]*.5;
   v=(floor(v*64.)+.5)/64.;
   vec3 i=texture2D(noisetex,v).xyz,c=vec3(sqrt(.2),sqrt(2.),1.61803);
   i=mod(i+float(frameCounter%2)*.5,vec3(1.));
   return i;
 }
 float P(float v,float y)
 {
   return exp(-pow(v/(.9*y),2.));
 }
 void main()
 {
   vec4 x=texture2DLod(colortex7,texcoord.xy,0),v=texture2DLod(colortex2,texcoord.xy,0);
   if(texcoord.x<HalfScreen.x&&texcoord.y>HalfScreen.y)
     {
       eAMCZAKEcI f=L(texcoord.xy-vec2(0.,HalfScreen.y));
       float y=f.VSCbvpIaKi;
       vec2 m=texcoord.xy-vec2(0.,HalfScreen.y);
       vec4 s=texture2DLod(colortex4,m.xy,0);
       vec3 c=s.xyz;
       float K=Luminance(c.xyz);
       vec3 i=GetNormals(m.xy);
       float z=GetDepthLinear(m.xy);
       vec2 n=rand(texcoord.xy+sin(frameTimeCounter)).xy-.5;
       float r=4.;
       r=mix(1.,4.,pow(y,.5));
       float t=sin(frameTimeCounter)>0.?1.:0.;
       vec4 e=vec4(0.),H=vec4(0.);
       float F=0.;
       int T=0;
       for(int h=-1;h<=1;h++)
         {
           for(int R=-1;R<=1;R++)
             {
               vec2 d=(vec2(h,R)+n)/vec2(viewWidth,viewHeight)*r,a=m.xy+d.xy;
               a=clamp(a,4./vec2(viewWidth,viewHeight),1.-4./vec2(viewWidth,viewHeight));
               vec4 G=texture2DLod(colortex4,a,0);
               e+=G;
               H+=G*G;
               T++;
             }
         }
       e/=T+1e-06;
       H/=T+1e-06;
       vec3 G=e.xyz;
       float d=dot(e.xyz,vec3(1.));
       vec4 a=sqrt(max(vec4(0.),H-e*e));
       float R=dot(a.xyz,vec3(6.));
       R/=saturate(dot(e.xyz,vec3(400.))/(saturate(y)+.001))+1e-05;
       if(F<.0001)
         G=c;
       x=vec4(s.xyz,R);
     }
   eAMCZAKEcI f=L(texcoord.xy);
   if(texcoord.x<HalfScreen.x&&texcoord.y<HalfScreen.y)
     {
       float m=f.VSCbvpIaKi,i=m;
       for(int c=-1;c<=1;c++)
         {
           for(int y=-1;y<=1;y++)
             {
               vec2 K=vec2(c,y)/vec2(viewWidth,viewHeight),s=texcoord.xy+K.xy;
               float z=L(s.xy).VSCbvpIaKi;
               i=min(i,z);
             }
         }
       f.VSCbvpIaKi=i;
     }
   gl_FragData[0]=v;
   gl_FragData[1]=D(f);
   gl_FragData[2]=x;
 };




/* DRAWBUFFERS:257 */
