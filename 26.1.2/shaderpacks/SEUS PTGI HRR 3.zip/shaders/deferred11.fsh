#version 330 compatibility




/*
 _______ _________ _______  _______  _ 
(  ____ \\__   __/(  ___  )(  ____ )( )
| (    \/   ) (   | (   ) || (    )|| |
| (_____    | |   | |   | || (____)|| |
(_____  )   | |   | |   | ||  _____)| |
      ) |   | |   | |   | || (      (_)
/\____) |   | |   | (___) || )       _ 
\_______)   )_(   (_______)|/       (_)

Do not modify this code until you have read the LICENSE.txt contained in the root directory of this shaderpack!

*/







in vec4 texcoord;


#include "lib/Uniforms.inc"
#include "lib/Common.inc"
#include "lib/GBufferData.inc"


 const float x=1./float(8192);
 ivec2 v=ivec2(viewWidth,viewHeight),f=ivec2(6144,6144);
 int y=v.x*v.y,z=37748736;
 int t(int v)
 {
   return v-FloorToInt(mod(float(v),2.))-0;
 }
 int d(int v)
 {
   return v-FloorToInt(mod(float(v),2.))-1;
 }
 int d()
 {
   return t(FloorToInt(floor(pow(float(y),.333333))));
 }
 int t()
 {
   return d(FloorToInt(floor(pow(float(z),.333333))));
 }
 int i=d();
 float m=1./i;
 int s=t();
 float K=1./s;
 vec3 r(vec2 f)
 {
   ivec2 x=ivec2(f.x*v.x,f.y*v.y);
   float y=float(x.y/i),z=float(int(x.x+mod(v.x*y,i))/i);
   z+=floor(v.x*y/i);
   vec3 s=vec3(0.,0.,z);
   s.x=mod(x.x+mod(v.x*y,i),i);
   s.y=mod(x.y,i);
   s.xyz=floor(s.xyz);
   s/=i;
   s.xyz=s.xzy;
   return s;
 }
 vec2 n(vec3 f)
 {
   vec3 s=f.xzy*i;
   s=floor(s+1e-05);
   float x=s.z;
   vec2 r;
   r.x=mod(s.x+x*i,v.x);
   float y=s.x+x*i;
   r.y=s.y+floor(y/v.x)*i;
   r+=.5;
   r/=v;
   return r;
 }
 vec3 e(vec2 v)
 {
   vec2 i=v;
   i.xy/=.75;
   int x=f.x*f.y;
   ivec2 y=ivec2(i.x*f.x,i.y*f.y);
   float z=float(y.y/s),r=float(int(y.x+mod(f.x*z,s))/s);
   r+=floor(f.x*z/s);
   vec3 m=vec3(0.,0.,r);
   m.x=mod(y.x+mod(f.x*z,s),s);
   m.y=mod(y.y,s);
   m.xyz=floor(m.xyz);
   m/=s;
   m.xyz=m.xzy;
   return m;
 }
 vec2 p(vec3 v)
 {
   v=clamp(v,vec3(0.),vec3(1.));
   vec3 i=v.xzy*s;
   i=floor(i+1e-05);
   float x=i.z;
   vec2 r;
   r.x=mod(i.x+x*s,f.x);
   float y=i.x+x*s;
   r.y=i.y+floor(y/f.x)*s;
   r+=.5;
   r/=f;
   r.xy*=.75;
   return r;
 }
 const int c=384,o=c/2-64;
 int h=(c-s)/2;
 float F=floor(cameraPosition.y+.5),a=clamp(F,o-h,o-h),G=F-a;
 vec3 w(vec3 v)
 {
   return v.y+=G,v*=K,v=v+vec3(.5),v;
 }
 vec3 T(vec3 v)
 {
   return v=w(v),v=clamp(v,vec3(0.),vec3(1.)),v;
 }
 vec3 l(vec3 v)
 {
   return v=v-vec3(.5),v*=s,v.y-=G,v;
 }
 vec3 P(vec3 v)
 {
   return v*=m,v=v+vec3(.5),v=clamp(v,vec3(0.),vec3(1.)),v;
 }
 vec3 R(vec3 v)
 {
   return v=v-vec3(.5),v*=i,v;
 }
 vec3 P()
 {
   vec3 v=cameraPosition.xyz+.5,x=previousCameraPosition.xyz+.5,i=floor(v-.0001),z=floor(x-.0001);
   return i-z;
 }
 vec3 P(vec3 v,vec3 f,vec2 i,vec2 y,vec4 s,vec4 x,inout float r,out vec2 z)
 {
   bool m=fract(v.x*2.)>.01&&fract(v.x*2.)<.99||fract(v.y*2.)>.01&&fract(v.y*2.)<.99||fract(v.z*2.)>.01&&fract(v.z*2.)<.99;
   m=!m;
   if(x.x==8||x.x==9||x.x==79||x.x<1.||!m||x.x==20.||x.x==171.||min(abs(f.x),abs(f.z))>.2)
     r=1.;
   if(x.x==50.||x.x==48.||x.x>=44&&x.x<48||x.x==49.||x.x==52.||x.x==76.)
     {
       r=0.;
       if(f.y<.5)
         r=1.;
     }
   if(x.x==54)
     r=0.;
   if(x.x==51||x.x==53||x.x==55)
     r=0.;
   if(x.x>255)
     r=0.;
   vec3 c,K;
   if(f.x>.5)
     c=vec3(0.,0.,-1.),K=vec3(0.,-1.,0.);
   else
      if(f.x<-.5)
       c=vec3(0.,0.,1.),K=vec3(0.,-1.,0.);
     else
        if(f.y>.5)
         c=vec3(1.,0.,0.),K=vec3(0.,0.,1.);
       else
          if(f.y<-.5)
           c=vec3(1.,0.,0.),K=vec3(0.,0.,-1.);
         else
            if(f.z>.5)
             c=vec3(1.,0.,0.),K=vec3(0.,-1.,0.);
           else
              if(f.z<-.5)
               c=vec3(-1.,0.,0.),K=vec3(0.,-1.,0.);
   z=clamp((i.xy-y.xy)*100000.,vec2(0.),vec2(1.));
   float G=.15,o=.15;
   if(x.x==10.||x.x==11.)
     G=.1,o=.1,r=0.;
   if(x.x==51||x.x==55||x.x==53)
     G=.5,o=.1;
   if(x.x==76)
     G=.2,o=.2;
   if(x.x-255.+39.>=103.&&x.x-255.+39.<=113.)
     o=.025,G=.025;
   c=normalize(s.xyz);
   K=normalize(cross(c,f.xyz)*sign(s.w));
   vec3 e=v.xyz+mix(c*G,-c*G,vec3(z.x));
   e.xyz+=mix(K*G,-K*G,vec3(z.y));
   e.xyz-=f.xyz*o;
   return e;
 }struct TOuWFelenO{vec3 FjeDDzWIWi;vec3 FjeDDzWIWiOrigin;vec3 gjulCSuvVu;vec3 ihCMMEIfgL;vec3 HHiebGwFJJ;vec3 GTJIHvOSbK;};
 TOuWFelenO W(Ray v)
 {
   TOuWFelenO f;
   f.FjeDDzWIWi=floor(v.origin);
   f.FjeDDzWIWiOrigin=f.FjeDDzWIWi;
   f.gjulCSuvVu=abs(vec3(length(v.direction))/(v.direction+1e-07));
   f.ihCMMEIfgL=sign(v.direction);
   f.HHiebGwFJJ=(sign(v.direction)*(f.FjeDDzWIWi-v.origin)+sign(v.direction)*.5+.5)*f.gjulCSuvVu;
   f.GTJIHvOSbK=vec3(0.);
   return f;
 }
 void b(inout TOuWFelenO v)
 {
   v.GTJIHvOSbK=step(v.HHiebGwFJJ.xyz,v.HHiebGwFJJ.yzx)*step(v.HHiebGwFJJ.xyz,v.HHiebGwFJJ.zxy),v.HHiebGwFJJ+=v.GTJIHvOSbK*v.gjulCSuvVu,v.FjeDDzWIWi+=v.GTJIHvOSbK*v.ihCMMEIfgL;
 }
 vec3 P(const vec3 v,const vec3 x,vec3 f)
 {
   vec3 y=(x+v)*.5,i=(x-v)*.5,z=f-y,r=abs(z);
   r/=i;
   vec3 K=step(r.yzx,r.xyz)*step(r.zxy,r.xyz);
   return K*sign(z);
 }
 bool P(const vec3 v,const vec3 f,Ray x,inout float i,inout vec3 y)
 {
   vec3 z=x.inv_direction*(v-1e-05-x.origin),s=x.inv_direction*(f+1e-05-x.origin),r=min(s,z),K=max(s,z);
   vec2 c=max(r.xx,r.yz);
   float m=max(c.x,c.y);
   c=min(K.xx,K.yz);
   float G=min(c.x,c.y);
   bool n=G>max(m,0.)&&max(m,0.)<i;
   if(n)
     y=P(v,f,x.origin+x.direction*m),i=m;
   return n;
 }
 float U(vec3 v)
 {
   return 1.;
 }struct eAMCZAKEcI{float nrlJXyapkV;float vPMmNoxUfq;float QQevGhUGeB;float VSCbvpIaKi;vec3 vyHfppOAPK;};
 vec4 D(eAMCZAKEcI v)
 {
   vec4 f;
   v.vyHfppOAPK=max(vec3(0.),v.vyHfppOAPK);
   f.x=v.nrlJXyapkV;
   v.vyHfppOAPK=pow(v.vyHfppOAPK,vec3(.125));
   f.y=PackTwo16BitTo32Bit(v.vyHfppOAPK.x,v.QQevGhUGeB);
   f.z=PackTwo16BitTo32Bit(v.vyHfppOAPK.y,v.VSCbvpIaKi);
   f.w=PackTwo16BitTo32Bit(v.vyHfppOAPK.z,v.vPMmNoxUfq/255.);
   return f;
 }
 eAMCZAKEcI H(vec4 v)
 {
   eAMCZAKEcI f;
   vec2 x=UnpackTwo16BitFrom32Bit(v.y),i=UnpackTwo16BitFrom32Bit(v.z),s=UnpackTwo16BitFrom32Bit(v.w);
   f.nrlJXyapkV=v.x;
   f.QQevGhUGeB=x.y;
   f.VSCbvpIaKi=i.y;
   f.vPMmNoxUfq=s.y*255.;
   f.vyHfppOAPK=pow(vec3(x.x,i.x,s.x),vec3(8.));
   return f;
 }
 eAMCZAKEcI g(vec2 v)
 {
   return v=(floor(v*ScreenSize)+.5)*ScreenTexel,H(texture2DLod(colortex5,v,0));
 }
 vec3 D(vec3 v,vec3 x)
 {
   vec3 f=P(l(v)+x+1.+P());
   float i=U(f);
   vec2 y=n(f);
   vec3 K=g(y).vyHfppOAPK;
   return K*i;
 }
 vec3 H(vec3 v,vec3 x)
 {
   vec3 f=P(l(v)+x+1.);
   float i=U(f);
   vec2 y=n(f);
   vec3 K=g(y).vyHfppOAPK;
   return K*i;
 }
 float P(float v,float y)
 {
   float x=1.;
   #ifdef FULL_RT_REFLECTIONS
   x=clamp(pow(v,.125)+y,0.,1.);
   #else
   x=clamp(v*10.-7.,0.,1.);
   #endif
   return x;
 }
 bool D(vec3 v,float x,Ray i,bool f,inout float y,inout vec3 z)
 {
   bool r=false,s=false;
   #if RAYTRACE_GEOMETRY_QUALITY==0
   if(f)
     return false;
   if(x>=67.)
     return false;
   s=P(v,v+vec3(1.,1.,1.),i,y,z);
   r=s;
   #else
   if(x<40.)
     return s=P(v,v+vec3(1.,1.,1.),i,y,z),s;
   if(x==40.||x==41.||x>=43.&&x<=54.)
     {
       float K=.5;
       if(x==41.)
         K=.9375;
       s=P(v+vec3(0.,0.,0.),v+vec3(1.,K,1.),i,y,z);
       r=r||s;
     }
   if(x==42.||x>=55.&&x<=66.)
     s=P(v+vec3(0.,.5,0.),v+vec3(1.,1.,1.),i,y,z),r=r||s;
   if(x==43.||x==46.||x==47.||x==52.||x==53.||x==54.||x==55.||x==58.||x==59.||x==64.||x==65.||x==66.)
     {
       float K=.5;
       if(x==55.||x==58.||x==59.||x==64.||x==65.||x==66.)
         K=0.;
       s=P(v+vec3(0.,K,0.),v+vec3(.5,.5+K,.5),i,y,z);
       r=r||s;
     }
   if(x==43.||x==45.||x==48.||x==51.||x==53.||x==54.||x==55.||x==57.||x==60.||x==63.||x==65.||x==66.)
     {
       float K=.5;
       if(x==55.||x==57.||x==60.||x==63.||x==65.||x==66.)
         K=0.;
       s=P(v+vec3(.5,K,0.),v+vec3(1.,.5+K,.5),i,y,z);
       r=r||s;
     }
   if(x==44.||x==45.||x==49.||x==51.||x==52.||x==54.||x==56.||x==57.||x==61.||x==63.||x==64.||x==66.)
     {
       float K=.5;
       if(x==56.||x==57.||x==61.||x==63.||x==64.||x==66.)
         K=0.;
       s=P(v+vec3(.5,K,.5),v+vec3(1.,.5+K,1.),i,y,z);
       r=r||s;
     }
   if(x==44.||x==46.||x==50.||x==51.||x==52.||x==53.||x==56.||x==58.||x==62.||x==63.||x==64.||x==65.)
     {
       float K=.5;
       if(x==56.||x==58.||x==62.||x==63.||x==64.||x==65.)
         K=0.;
       s=P(v+vec3(0.,K,.5),v+vec3(.5,.5+K,1.),i,y,z);
       r=r||s;
     }
   if(x>=67.&&x<=82.)
     s=P(v+vec3(6.,0.,6.)/16.,v+vec3(10.,16.,10.)/16.,i,y,z),r=r||s;
   if(x==68.||x==69.||x==70.||x==72.||x==73.||x==74.||x==76.||x==77.||x==78.||x==80.||x==81.||x==82.)
     {
       float K=8.,c=8.;
       if(x==68.||x==70.||x==72.||x==74.||x==76.||x==78.||x==80.||x==82.)
         K=0.;
       if(x==69.||x==70.||x==73.||x==74.||x==77.||x==78.||x==81.||x==82.)
         c=16.;
       s=P(v+vec3(K,6.,7.)/16.,v+vec3(c,9.,9.)/16.,i,y,z);
       r=r||s;
       s=P(v+vec3(K,12.,7.)/16.,v+vec3(c,15.,9.)/16.,i,y,z);
       r=r||s;
     }
   if(x>=71.&&x<=82.)
     {
       float K=8.,c=8.;
       if(x>=71.&&x<=74.||x>=79.&&x<=82.)
         c=16.;
       if(x>=75.&&x<=82.)
         K=0.;
       s=P(v+vec3(7.,6.,K)/16.,v+vec3(9.,9.,c)/16.,i,y,z);
       r=r||s;
       s=P(v+vec3(7.,12.,K)/16.,v+vec3(9.,15.,c)/16.,i,y,z);
       r=r||s;
     }
   #if RAYTRACE_GEOMETRY_QUALITY==2
   if(x>=83.&&x<=86.)
     {
       vec3 K=vec3(0),c=vec3(0);
       if(x==83.)
         K=vec3(0,0,0),c=vec3(16,16,3);
       if(x==84.)
         K=vec3(0,0,13),c=vec3(16,16,16);
       if(x==86.)
         K=vec3(0,0,0),c=vec3(3,16,16);
       if(x==85.)
         K=vec3(13,0,0),c=vec3(16,16,16);
       s=P(v+K/16.,v+c/16.,i,y,z);
       r=r||s;
     }
   if(x>=87.&&x<=102.)
     {
       vec3 K=vec3(0.),c=vec3(1.);
       if(x>=87.&&x<=94.)
         {
           float G=0.;
           if(x>=91.&&x<=94.)
             G=13.;
           K=vec3(0.,G,0.)/16.;
           c=vec3(16.,G+3.,16.)/16.;
         }
       if(x>=95.&&x<=98.)
         {
           float G=13.;
           if(x==97.||x==98.)
             G=0.;
           K=vec3(0.,0.,G)/16.;
           c=vec3(16.,16.,G+3.)/16.;
         }
       if(x>=99.&&x<=102.)
         {
           float G=13.;
           if(x==99.||x==100.)
             G=0.;
           K=vec3(G,0.,0.)/16.;
           c=vec3(G+3.,16.,16.)/16.;
         }
       s=P(v+K,v+c,i,y,z);
       r=r||s;
     }
   if(x>=103.&&x<=113.)
     {
       vec3 K=vec3(0.),c=vec3(1.);
       if(x>=103.&&x<=110.)
         {
           float m=float(x)-float(103.)+1.;
           c.y=m*2./16.;
         }
       if(x==111.)
         c.y=.0625;
       if(x==112.)
         K=vec3(1.,0.,1.)/16.,c=vec3(15.,1.,15.)/16.;
       if(x==113.)
         K=vec3(1.,0.,1.)/16.,c=vec3(15.,.5,15.)/16.;
       s=P(v+K,v+c,i,y,z);
       r=r||s;
     }
   #endif
   #endif
   return r;
 }
 float D(vec3 v,vec3 i,int y,const int f)
 {
   Ray x=MakeRay(v,i);
   TOuWFelenO s=W(x);
   float r=1.,c=100000.;
   vec3 z=vec3(0.);
   for(int G=0;G<f;G++)
     {
       vec3 m=s.FjeDDzWIWi*K;
       vec2 o=p(m);
       vec4 n=texture2DLod(shadowcolor,o,0);
       float e=n.w*255.;
       if(abs(e-36.)<.1||abs(e-38.)<.1)
         {
           continue;
         }
       if(e<240.)
         {
           if(D(s.FjeDDzWIWi,e,x,G==0,c,z))
             {
               r=0.;
               break;
             }
         }
       b(s);
     }
   const float G=f*.33;
   r=mix(r,1.,saturate(c-G));
   return r;
 }
 vec3 V(vec3 v)
 {
   vec4 x=vec4(v,1.);
   x=shadowModelView*x;
   x=shadowProjection*x;
   x/=x.w;
   float K=sqrt(x.x*x.x+x.y*x.y),i=1.f-SHADOW_MAP_BIAS+K*SHADOW_MAP_BIAS;
   x.xy*=.95f/i;
   x.z=mix(x.z,.5,.8);
   x=x*.5f+.5f;
   x.xyz=FinalShadowProjectionTransformation(x.xyz);
   return x.xyz;
 }
 vec3 H(vec3 v,vec3 x,vec3 i,vec3 y,vec3 K,int z)
 {
   if(rainStrength>.99)
     return vec3(0.);
   v-=Fract01(cameraPosition+.5);
   float f,s;
   vec3 c=WorldPosToShadowProjPosBias(v,y,.004,f,s),r=vec3(1.)*shadow2DLod(shadowtex0,vec3(c.xy,c.z),1).x;
   r*=saturate(dot(i,y));
   r*=D(x+y*.01,i,z,3);
   {
     vec4 G=texture2DLod(shadowcolor1,c.xy-vec2(0.,.5),3);
     float o=abs(G.x*256.-(v.y+cameraPosition.y)),m=GetCausticsComposite(v,i,o),n=shadow2DLod(shadowtex0,vec3(c.xy-vec2(0.,.5),c.z+1e-06),3).x;
     r=mix(r,r*m,1.-n);
   }
   r=TintUnderwaterDepth(r);
   return r*(1.-rainStrength);
 }
 vec3 P(vec3 v,vec3 x,vec3 i,vec3 y,vec3 K,int z)
 {
   if(rainStrength>.99)
     return vec3(0.);
   vec3 f=l(v);
   f+=1.;
   f-=Fract01(cameraPosition+.5);
   float c,s;
   vec3 r=WorldPosToShadowProjPosBias(f+y*.99,y,.004,c,s),G=vec3(1.)*shadow2DLod(shadowtex0,vec3(r.xy,r.z),1).x;
   G*=saturate(dot(i,y));
   G*=D(x+y*.99,i,z,3);
   G=TintUnderwaterDepth(G);
   #ifdef GI_SUNLIGHT_STAINED_GLASS_TINT
   float n=shadow2DLod(shadowtex0,vec3(r.xy-vec2(.5,0.),r.z),3).x;
   vec3 m=texture2DLod(shadowcolor,vec2(r.xy-vec2(.5,0.)),3).xyz;
   m*=m;
   G=mix(G,G*m,vec3(1.-n));
   #endif
   return G*(1.-rainStrength);
 }
 vec3 R(vec3 v,vec3 x,vec3 i,vec3 y,vec3 K,int z)
 {
   if(rainStrength>.99)
     return vec3(0.);
   v+=1.;
   v-=Fract01(cameraPosition+.5);
   float f,s;
   vec3 c=WorldPosToShadowProjPosBias(v,y,.004,f,s);
   float r=.5;
   vec3 G=vec3(1.)*shadow2DLod(shadowtex0,vec3(c.xy,c.z-.0006*r),2).x;
   G*=saturate(dot(i,y));
   G*=D(x+y*.01,i,z,3);
   G=TintUnderwaterDepth(G);
   #ifdef GI_SUNLIGHT_STAINED_GLASS_TINT
   float n=shadow2DLod(shadowtex0,vec3(c.xy-vec2(.5,0.),c.z-.0006*r),3).x;
   vec3 m=texture2DLod(shadowcolor,vec2(c.xy-vec2(.5,0.)),3).xyz;
   m*=m;
   G=mix(G,G*m,vec3(1.-n));
   #endif
   return G*(1.-rainStrength);
 }
 vec3 Q(vec2 x)
 {
   vec2 v=vec2(x.xy*vec2(viewWidth,viewHeight));
   v*=1./64.;
   const vec2 f[16]=vec2[16](vec2(-1,-1),vec2(0,-.333333),vec2(-.5,.333333),vec2(.5,-.777778),vec2(-.75,-.111111),vec2(.25,.555556),vec2(-.25,-.555556),vec2(.75,.111111),vec2(-.875,.777778),vec2(.125,-.925926),vec2(-.375,-.259259),vec2(.625,.407407),vec2(-.625,-.703704),vec2(.375,-.037037),vec2(-.125,.62963),vec2(.875,-.481482));
   if(x.x<2./viewWidth||x.x>1.-2./viewWidth||x.y<2./viewHeight||x.y>1.-2./viewHeight)
     ;
   else
      v+=f[frameCounter/2%16]*.5;
   v=(floor(v*64.)+.5)/64.;
   vec3 i=texture2D(noisetex,v).xyz,K=vec3(sqrt(.2),sqrt(2.),1.61803);
   i=mod(i+float(frameCounter%2)*.5,vec3(1.));
   return i;
 }
 void Q(inout float v,inout float x,float y,float i,vec3 f,float z)
 {
   v*=mix(2.4,2.4,i);
   v*=2.2;
   float K=dot(f,vec3(1.)),c=1.-i;
   x/=y*.1+2e-06;
   x*=.5;
   if(z<.12)
     x=0.;
 }
 float D(vec3 v,vec3 y,float f)
 {
   float x=dot(abs(v-y),vec3(.3333));
   x*=f;
   return x;
 }
 vec4 D(sampler2D v,vec2 x,bool i,float y,float f,vec2 s,const bool z,out float r)
 {
   eAMCZAKEcI K=g(x.xy);
   r=K.VSCbvpIaKi;
   vec2 c=vec2(0.,HalfScreen.y);
   vec4 m=texture2DLod(v,x.xy+c,0);
   vec3 G=m.xyz;
   float n=m.w;
   if(r<.95&&z)
     return m;
   vec3 e,o;
   GetBothNormals(x.xy,e,o);
   float t=GetDepth(x.xy),h=ExpToLinearDepth(t);
   vec3 F=GetViewPosition(x.xy,t).xyz,a=normalize(F);
   vec2 J=vec2(0.);
   if(i||r>.95)
     J=BlueNoiseTemporal(x.xy).xy-.5;
   float d=y*1,w=f;
   Q(d,w,m.w,r,G,h);
   float R=24.*mix(1.,0.,r),S=mix(3.,1.,r)/h,H=0.;
   vec4 b=vec4(0.);
   float p=0.;
   vec4 T=vec4(vec3(.3),1.);
   int V=0;
   vec2 P=normalize(cross(o,vec3(0.,0.,1.)).xy),l=P.yx*vec2(1.,-1.);
   l*=saturate(dot(o,-a))*.8+.2;
   for(int Y=-1;Y<=1;Y++)
     {
       {
         vec2 U=vec2(Y+J.x)*s;
         U=U.x*P+U.y*l;
         U*=d*ScreenTexel;
         vec2 u=x.xy+U.xy;
         u=clamp(u,vec2(0.)+ScreenTexel*2.,HalfScreen-ScreenTexel*2.);
         vec4 W=texture2DLod(v,u+c,0);
         vec3 B,L;
         GetBothNormals(u,B,L);
         vec3 M=GetViewPosition(u,GetDepth(u)).xyz,q=M.xyz-F.xyz;
         float I=length(q);
         vec3 A=q/(I+1e-06);
         float E=dot(q,o);
         bool O=E>.05&&Luminance(W.xyz)<Luminance(G.xyz);
         float C=pow(saturate(dot(e,B)),R),k=saturate(exp(-abs(E)*20.*S));
         if(O&&I<1.&&dot(-A,L)>0.)
           C=4./y;
         float j=exp(-D(W.xyz,G,w)),N=C*j*k;
         b+=W*N;
         p+=N;
         V++;
       }
     }
   b/=p+.0001;
   if(p<.0001)
     b=m;
   return b;
 }
 void main()
 {
   float v;
   vec4 x=D(colortex7,texcoord.xy,true,2.,2.,vec2(1.,-1.),false,v);
   vec2 f=1.-abs(texcoord.xy*2.-1.);
   f=saturate(f*10.);
   float K=min(f.x,f.y);
   gl_FragData[0]=vec4(x.xyz,1.);
 };




/* DRAWBUFFERS:7 */
