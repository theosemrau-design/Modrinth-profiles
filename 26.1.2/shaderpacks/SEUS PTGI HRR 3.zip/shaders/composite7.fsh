#version 330 compatibility

/*
 _______ _________ _______  _______  _
(  ____ \\__   __/(  ___  )(  ____ )( )
| (    \/   ) (   | (   ) || (    )|| |
| (_____    | |   | |   | || (____)|| |
(_____  )   | |   | |   | ||  _____)| |
      ) |   | |   | |   | || (      (_)
/\____) |   | |   | (___) || )       _
\_______)   )_(   (_______)|/       (_)

Do not modify this code until you have read the LICENSE.txt contained in the root directory of this shaderpack!

*/


#include "lib/Uniforms.inc"
#include "lib/Common.inc"


/////////////////////////CONFIGURABLE VARIABLES////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////CONFIGURABLE VARIABLES////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

//fgdhghdf

/////////////////////////END OF CONFIGURABLE VARIABLES/////////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////END OF CONFIGURABLE VARIABLES/////////////////////////////////////////////////////////////////////////////////////////////////////////////




const bool colortex3MipmapEnabled = true;

in vec4 texcoord;
in vec3 lightVector;


in float timeSunriseSunset;
in float timeNoon;
in float timeMidnight;

in vec3 colorSunlight;
in vec3 colorSkylight;





#define COLORPOW 1.0

#define CURR_COLOR_TEX colortex3
#define PREV_COLOR_TEX colortex6
#define DEPTHTEX depthtex0


 const float x=1./float(8192);
 ivec2 v=ivec2(viewWidth,viewHeight),f=ivec2(6144,6144);
 int y=v.x*v.y,z=37748736;
 int t(int v)
 {
   return v-FloorToInt(mod(float(v),2.))-0;
 }
 int d(int v)
 {
   return v-FloorToInt(mod(float(v),2.))-1;
 }
 int d()
 {
   return t(FloorToInt(floor(pow(float(y),.333333))));
 }
 int t()
 {
   return d(FloorToInt(floor(pow(float(z),.333333))));
 }
 int m=d();
 float i=1./m;
 int s=t();
 float K=1./s;
 vec3 r(vec2 f)
 {
   ivec2 x=ivec2(f.x*v.x,f.y*v.y);
   float z=float(x.y/m),i=float(int(x.x+mod(v.x*z,m))/m);
   i+=floor(v.x*z/m);
   vec3 s=vec3(0.,0.,i);
   s.x=mod(x.x+mod(v.x*z,m),m);
   s.y=mod(x.y,m);
   s.xyz=floor(s.xyz);
   s/=m;
   s.xyz=s.xzy;
   return s;
 }
 vec2 n(vec3 f)
 {
   vec3 i=f.xzy*m;
   i=floor(i+1e-05);
   float x=i.z;
   vec2 r;
   r.x=mod(i.x+x*m,v.x);
   float s=i.x+x*m;
   r.y=i.y+floor(s/v.x)*m;
   r+=.5;
   r/=v;
   return r;
 }
 vec3 e(vec2 v)
 {
   vec2 i=v;
   i.xy/=.75;
   int x=f.x*f.y;
   ivec2 d=ivec2(i.x*f.x,i.y*f.y);
   float z=float(d.y/s),y=float(int(d.x+mod(f.x*z,s))/s);
   y+=floor(f.x*z/s);
   vec3 m=vec3(0.,0.,y);
   m.x=mod(d.x+mod(f.x*z,s),s);
   m.y=mod(d.y,s);
   m.xyz=floor(m.xyz);
   m/=s;
   m.xyz=m.xzy;
   return m;
 }
 vec2 p(vec3 v)
 {
   v=clamp(v,vec3(0.),vec3(1.));
   vec3 i=v.xzy*s;
   i=floor(i+1e-05);
   float x=i.z;
   vec2 r;
   r.x=mod(i.x+x*s,f.x);
   float z=i.x+x*s;
   r.y=i.y+floor(z/f.x)*s;
   r+=.5;
   r/=f;
   r.xy*=.75;
   return r;
 }
 const int c=384,o=c/2-64;
 int h=(c-s)/2;
 float F=floor(cameraPosition.y+.5),w=clamp(F,o-h,o-h),a=F-w;
 vec3 G(vec3 v)
 {
   return v.y+=a,v*=K,v=v+vec3(.5),v;
 }
 vec3 D(vec3 v)
 {
   return v=G(v),v=clamp(v,vec3(0.),vec3(1.)),v;
 }
 vec3 A(vec3 v)
 {
   return v=v-vec3(.5),v*=s,v.y-=a,v;
 }
 vec3 T(vec3 v)
 {
   return v*=i,v=v+vec3(.5),v=clamp(v,vec3(0.),vec3(1.)),v;
 }
 vec3 R(vec3 v)
 {
   return v=v-vec3(.5),v*=m,v;
 }
 vec3 A()
 {
   vec3 v=cameraPosition.xyz+.5,i=previousCameraPosition.xyz+.5,x=floor(v-.0001),z=floor(i-.0001);
   return x-z;
 }
 vec3 A(vec3 v,vec3 f,vec2 i,vec2 x,vec4 s,vec4 d,inout float z,out vec2 r)
 {
   bool y=fract(v.x*2.)>.01&&fract(v.x*2.)<.99||fract(v.y*2.)>.01&&fract(v.y*2.)<.99||fract(v.z*2.)>.01&&fract(v.z*2.)<.99;
   y=!y;
   if(d.x==8||d.x==9||d.x==79||d.x<1.||!y||d.x==20.||d.x==171.||min(abs(f.x),abs(f.z))>.2)
     z=1.;
   if(d.x==50.||d.x==48.||d.x>=44&&d.x<48||d.x==49.||d.x==52.||d.x==76.)
     {
       z=0.;
       if(f.y<.5)
         z=1.;
     }
   if(d.x==54)
     z=0.;
   if(d.x==51||d.x==53||d.x==55)
     z=0.;
   if(d.x>255)
     z=0.;
   vec3 m,e;
   if(f.x>.5)
     m=vec3(0.,0.,-1.),e=vec3(0.,-1.,0.);
   else
      if(f.x<-.5)
       m=vec3(0.,0.,1.),e=vec3(0.,-1.,0.);
     else
        if(f.y>.5)
         m=vec3(1.,0.,0.),e=vec3(0.,0.,1.);
       else
          if(f.y<-.5)
           m=vec3(1.,0.,0.),e=vec3(0.,0.,-1.);
         else
            if(f.z>.5)
             m=vec3(1.,0.,0.),e=vec3(0.,-1.,0.);
           else
              if(f.z<-.5)
               m=vec3(-1.,0.,0.),e=vec3(0.,-1.,0.);
   r=clamp((i.xy-x.xy)*100000.,vec2(0.),vec2(1.));
   float K=.15,o=.15;
   if(d.x==10.||d.x==11.)
     K=.1,o=.1,z=0.;
   if(d.x==51||d.x==55||d.x==53)
     K=.5,o=.1;
   if(d.x==76)
     K=.2,o=.2;
   if(d.x-255.+39.>=103.&&d.x-255.+39.<=113.)
     o=.025,K=.025;
   m=normalize(s.xyz);
   e=normalize(cross(m,f.xyz)*sign(s.w));
   vec3 n=v.xyz+mix(m*K,-m*K,vec3(r.x));
   n.xyz+=mix(e*K,-e*K,vec3(r.y));
   n.xyz-=f.xyz*o;
   return n;
 }struct TOuWFelenO{vec3 FjeDDzWIWi;vec3 FjeDDzWIWiOrigin;vec3 gjulCSuvVu;vec3 ihCMMEIfgL;vec3 HHiebGwFJJ;vec3 GTJIHvOSbK;};
 TOuWFelenO P(Ray v)
 {
   TOuWFelenO f;
   f.FjeDDzWIWi=floor(v.origin);
   f.FjeDDzWIWiOrigin=f.FjeDDzWIWi;
   f.gjulCSuvVu=abs(vec3(length(v.direction))/(v.direction+1e-07));
   f.ihCMMEIfgL=sign(v.direction);
   f.HHiebGwFJJ=(sign(v.direction)*(f.FjeDDzWIWi-v.origin)+sign(v.direction)*.5+.5)*f.gjulCSuvVu;
   f.GTJIHvOSbK=vec3(0.);
   return f;
 }
 void b(inout TOuWFelenO v)
 {
   v.GTJIHvOSbK=step(v.HHiebGwFJJ.xyz,v.HHiebGwFJJ.yzx)*step(v.HHiebGwFJJ.xyz,v.HHiebGwFJJ.zxy),v.HHiebGwFJJ+=v.GTJIHvOSbK*v.gjulCSuvVu,v.FjeDDzWIWi+=v.GTJIHvOSbK*v.ihCMMEIfgL;
 }
 vec3 A(const vec3 v,const vec3 x,vec3 m)
 {
   vec3 z=(x+v)*.5,f=(x-v)*.5,y=m-z,i=abs(y);
   i/=f;
   vec3 K=step(i.yzx,i.xyz)*step(i.zxy,i.xyz);
   return K*sign(y);
 }
 bool A(const vec3 v,const vec3 i,Ray f,inout float x,inout vec3 z)
 {
   vec3 y=f.inv_direction*(v-1e-05-f.origin),s=f.inv_direction*(i+1e-05-f.origin),d=min(s,y),m=max(s,y);
   vec2 r=max(d.xx,d.yz);
   float K=max(r.x,r.y);
   r=min(m.xx,m.yz);
   float t=min(r.x,r.y);
   bool e=t>max(K,0.)&&max(K,0.)<x;
   if(e)
     z=A(v,i,f.origin+f.direction*K),x=K;
   return e;
 }
 float g(vec3 v)
 {
   return 1.;
 }struct eAMCZAKEcI{float nrlJXyapkV;float vPMmNoxUfq;float QQevGhUGeB;float VSCbvpIaKi;vec3 vyHfppOAPK;};
 vec4 S(eAMCZAKEcI v)
 {
   vec4 f;
   v.vyHfppOAPK=max(vec3(0.),v.vyHfppOAPK);
   f.x=v.nrlJXyapkV;
   v.vyHfppOAPK=pow(v.vyHfppOAPK,vec3(.125));
   f.y=PackTwo16BitTo32Bit(v.vyHfppOAPK.x,v.QQevGhUGeB);
   f.z=PackTwo16BitTo32Bit(v.vyHfppOAPK.y,v.VSCbvpIaKi);
   f.w=PackTwo16BitTo32Bit(v.vyHfppOAPK.z,v.vPMmNoxUfq/255.);
   return f;
 }
 eAMCZAKEcI l(vec4 v)
 {
   eAMCZAKEcI f;
   vec2 i=UnpackTwo16BitFrom32Bit(v.y),m=UnpackTwo16BitFrom32Bit(v.z),d=UnpackTwo16BitFrom32Bit(v.w);
   f.nrlJXyapkV=v.x;
   f.QQevGhUGeB=i.y;
   f.VSCbvpIaKi=m.y;
   f.vPMmNoxUfq=d.y*255.;
   f.vyHfppOAPK=pow(vec3(i.x,m.x,d.x),vec3(8.));
   return f;
 }
 eAMCZAKEcI W(vec2 v)
 {
   return v=(floor(v*ScreenSize)+.5)*ScreenTexel,l(texture2DLod(colortex5,v,0));
 }
 vec3 A(vec3 v,vec3 y)
 {
   vec3 x=T(A(v)+y+1.+A());
   float z=g(x);
   vec2 i=n(x);
   vec3 K=W(i).vyHfppOAPK;
   return K*z;
 }
 vec3 D(vec3 v,vec3 y)
 {
   vec3 x=T(A(v)+y+1.);
   float z=g(x);
   vec2 i=n(x);
   vec3 K=W(i).vyHfppOAPK;
   return K*z;
 }
 float G(float v,float y)
 {
   float x=1.;
   #ifdef FULL_RT_REFLECTIONS
   x=clamp(pow(v,.125)+y,0.,1.);
   #else
   x=clamp(v*10.-7.,0.,1.);
   #endif
   return x;
 }
 bool A(vec3 v,float x,Ray i,bool y,inout float f,inout vec3 z)
 {
   bool m=false,t=false;
   #if RAYTRACE_GEOMETRY_QUALITY==0
   if(y)
     return false;
   if(x>=67.)
     return false;
   t=A(v,v+vec3(1.,1.,1.),i,f,z);
   m=t;
   #else
   if(x<40.)
     return t=A(v,v+vec3(1.,1.,1.),i,f,z),t;
   if(x==40.||x==41.||x>=43.&&x<=54.)
     {
       float K=.5;
       if(x==41.)
         K=.9375;
       t=A(v+vec3(0.,0.,0.),v+vec3(1.,K,1.),i,f,z);
       m=m||t;
     }
   if(x==42.||x>=55.&&x<=66.)
     t=A(v+vec3(0.,.5,0.),v+vec3(1.,1.,1.),i,f,z),m=m||t;
   if(x==43.||x==46.||x==47.||x==52.||x==53.||x==54.||x==55.||x==58.||x==59.||x==64.||x==65.||x==66.)
     {
       float K=.5;
       if(x==55.||x==58.||x==59.||x==64.||x==65.||x==66.)
         K=0.;
       t=A(v+vec3(0.,K,0.),v+vec3(.5,.5+K,.5),i,f,z);
       m=m||t;
     }
   if(x==43.||x==45.||x==48.||x==51.||x==53.||x==54.||x==55.||x==57.||x==60.||x==63.||x==65.||x==66.)
     {
       float K=.5;
       if(x==55.||x==57.||x==60.||x==63.||x==65.||x==66.)
         K=0.;
       t=A(v+vec3(.5,K,0.),v+vec3(1.,.5+K,.5),i,f,z);
       m=m||t;
     }
   if(x==44.||x==45.||x==49.||x==51.||x==52.||x==54.||x==56.||x==57.||x==61.||x==63.||x==64.||x==66.)
     {
       float K=.5;
       if(x==56.||x==57.||x==61.||x==63.||x==64.||x==66.)
         K=0.;
       t=A(v+vec3(.5,K,.5),v+vec3(1.,.5+K,1.),i,f,z);
       m=m||t;
     }
   if(x==44.||x==46.||x==50.||x==51.||x==52.||x==53.||x==56.||x==58.||x==62.||x==63.||x==64.||x==65.)
     {
       float K=.5;
       if(x==56.||x==58.||x==62.||x==63.||x==64.||x==65.)
         K=0.;
       t=A(v+vec3(0.,K,.5),v+vec3(.5,.5+K,1.),i,f,z);
       m=m||t;
     }
   if(x>=67.&&x<=82.)
     t=A(v+vec3(6.,0.,6.)/16.,v+vec3(10.,16.,10.)/16.,i,f,z),m=m||t;
   if(x==68.||x==69.||x==70.||x==72.||x==73.||x==74.||x==76.||x==77.||x==78.||x==80.||x==81.||x==82.)
     {
       float K=8.,s=8.;
       if(x==68.||x==70.||x==72.||x==74.||x==76.||x==78.||x==80.||x==82.)
         K=0.;
       if(x==69.||x==70.||x==73.||x==74.||x==77.||x==78.||x==81.||x==82.)
         s=16.;
       t=A(v+vec3(K,6.,7.)/16.,v+vec3(s,9.,9.)/16.,i,f,z);
       m=m||t;
       t=A(v+vec3(K,12.,7.)/16.,v+vec3(s,15.,9.)/16.,i,f,z);
       m=m||t;
     }
   if(x>=71.&&x<=82.)
     {
       float K=8.,s=8.;
       if(x>=71.&&x<=74.||x>=79.&&x<=82.)
         s=16.;
       if(x>=75.&&x<=82.)
         K=0.;
       t=A(v+vec3(7.,6.,K)/16.,v+vec3(9.,9.,s)/16.,i,f,z);
       m=m||t;
       t=A(v+vec3(7.,12.,K)/16.,v+vec3(9.,15.,s)/16.,i,f,z);
       m=m||t;
     }
   #if RAYTRACE_GEOMETRY_QUALITY==2
   if(x>=83.&&x<=86.)
     {
       vec3 K=vec3(0),s=vec3(0);
       if(x==83.)
         K=vec3(0,0,0),s=vec3(16,16,3);
       if(x==84.)
         K=vec3(0,0,13),s=vec3(16,16,16);
       if(x==86.)
         K=vec3(0,0,0),s=vec3(3,16,16);
       if(x==85.)
         K=vec3(13,0,0),s=vec3(16,16,16);
       t=A(v+K/16.,v+s/16.,i,f,z);
       m=m||t;
     }
   if(x>=87.&&x<=102.)
     {
       vec3 K=vec3(0.),s=vec3(1.);
       if(x>=87.&&x<=94.)
         {
           float r=0.;
           if(x>=91.&&x<=94.)
             r=13.;
           K=vec3(0.,r,0.)/16.;
           s=vec3(16.,r+3.,16.)/16.;
         }
       if(x>=95.&&x<=98.)
         {
           float r=13.;
           if(x==97.||x==98.)
             r=0.;
           K=vec3(0.,0.,r)/16.;
           s=vec3(16.,16.,r+3.)/16.;
         }
       if(x>=99.&&x<=102.)
         {
           float r=13.;
           if(x==99.||x==100.)
             r=0.;
           K=vec3(r,0.,0.)/16.;
           s=vec3(r+3.,16.,16.)/16.;
         }
       t=A(v+K,v+s,i,f,z);
       m=m||t;
     }
   if(x>=103.&&x<=113.)
     {
       vec3 K=vec3(0.),r=vec3(1.);
       if(x>=103.&&x<=110.)
         {
           float s=float(x)-float(103.)+1.;
           r.y=s*2./16.;
         }
       if(x==111.)
         r.y=.0625;
       if(x==112.)
         K=vec3(1.,0.,1.)/16.,r=vec3(15.,1.,15.)/16.;
       if(x==113.)
         K=vec3(1.,0.,1.)/16.,r=vec3(15.,.5,15.)/16.;
       t=A(v+K,v+r,i,f,z);
       m=m||t;
     }
   #endif
   #endif
   return m;
 }
 float A(vec3 v,vec3 z,int i,const int m)
 {
   Ray x=MakeRay(v,z);
   TOuWFelenO f=P(x);
   float r=1.,s=100000.;
   vec3 y=vec3(0.);
   for(int t=0;t<m;t++)
     {
       vec3 d=f.FjeDDzWIWi*K;
       vec2 e=p(d);
       vec4 n=texture2DLod(shadowcolor,e,0);
       float o=n.w*255.;
       if(abs(o-36.)<.1||abs(o-38.)<.1)
         {
           continue;
         }
       if(o<240.)
         {
           if(A(f.FjeDDzWIWi,o,x,t==0,s,y))
             {
               r=0.;
               break;
             }
         }
       b(f);
     }
   const float t=m*.33;
   r=mix(r,1.,saturate(s-t));
   return r;
 }
 vec3 H(vec3 v)
 {
   vec4 x=vec4(v,1.);
   x=shadowModelView*x;
   x=shadowProjection*x;
   x/=x.w;
   float K=sqrt(x.x*x.x+x.y*x.y),z=1.f-SHADOW_MAP_BIAS+K*SHADOW_MAP_BIAS;
   x.xy*=.95f/z;
   x.z=mix(x.z,.5,.8);
   x=x*.5f+.5f;
   x.xyz=FinalShadowProjectionTransformation(x.xyz);
   return x.xyz;
 }
 vec3 D(vec3 v,vec3 x,vec3 i,vec3 z,vec3 K,int f)
 {
   if(rainStrength>.99)
     return vec3(0.);
   v-=Fract01(cameraPosition+.5);
   float s,y;
   vec3 d=WorldPosToShadowProjPosBias(v,z,.004,s,y),r=vec3(1.)*shadow2DLod(shadowtex0,vec3(d.xy,d.z),1).x;
   r*=saturate(dot(i,z));
   r*=A(x+z*.01,i,f,3);
   {
     vec4 m=texture2DLod(shadowcolor1,d.xy-vec2(0.,.5),3);
     float t=abs(m.x*256.-(v.y+cameraPosition.y)),o=GetCausticsComposite(v,i,t),e=shadow2DLod(shadowtex0,vec3(d.xy-vec2(0.,.5),d.z+1e-06),3).x;
     r=mix(r,r*o,1.-e);
   }
   r=TintUnderwaterDepth(r);
   return r*(1.-rainStrength);
 }
 vec3 G(vec3 v,vec3 x,vec3 i,vec3 z,vec3 K,int f)
 {
   if(rainStrength>.99)
     return vec3(0.);
   vec3 r=A(v);
   r+=1.;
   r-=Fract01(cameraPosition+.5);
   float s,y;
   vec3 d=WorldPosToShadowProjPosBias(r+z*.99,z,.004,s,y),m=vec3(1.)*shadow2DLod(shadowtex0,vec3(d.xy,d.z),1).x;
   m*=saturate(dot(i,z));
   m*=A(x+z*.99,i,f,3);
   m=TintUnderwaterDepth(m);
   #ifdef GI_SUNLIGHT_STAINED_GLASS_TINT
   float t=shadow2DLod(shadowtex0,vec3(d.xy-vec2(.5,0.),d.z),3).x;
   vec3 e=texture2DLod(shadowcolor,vec2(d.xy-vec2(.5,0.)),3).xyz;
   e*=e;
   m=mix(m,m*e,vec3(1.-t));
   #endif
   return m*(1.-rainStrength);
 }
 vec3 H(vec3 v,vec3 x,vec3 i,vec3 z,vec3 K,int f)
 {
   if(rainStrength>.99)
     return vec3(0.);
   v+=1.;
   v-=Fract01(cameraPosition+.5);
   float s,y;
   vec3 d=WorldPosToShadowProjPosBias(v,z,.004,s,y);
   float m=.5;
   vec3 r=vec3(1.)*shadow2DLod(shadowtex0,vec3(d.xy,d.z-.0006*m),2).x;
   r*=saturate(dot(i,z));
   r*=A(x+z*.01,i,f,3);
   r=TintUnderwaterDepth(r);
   #ifdef GI_SUNLIGHT_STAINED_GLASS_TINT
   float t=shadow2DLod(shadowtex0,vec3(d.xy-vec2(.5,0.),d.z-.0006*m),3).x;
   vec3 e=texture2DLod(shadowcolor,vec2(d.xy-vec2(.5,0.)),3).xyz;
   e*=e;
   r=mix(r,r*e,vec3(1.-t));
   #endif
   return r*(1.-rainStrength);
 }
 vec3 V(vec2 v)
 {
   vec2 x=vec2(v.xy*vec2(viewWidth,viewHeight));
   x*=1./64.;
   const vec2 m[16]=vec2[16](vec2(-1,-1),vec2(0,-.333333),vec2(-.5,.333333),vec2(.5,-.777778),vec2(-.75,-.111111),vec2(.25,.555556),vec2(-.25,-.555556),vec2(.75,.111111),vec2(-.875,.777778),vec2(.125,-.925926),vec2(-.375,-.259259),vec2(.625,.407407),vec2(-.625,-.703704),vec2(.375,-.037037),vec2(-.125,.62963),vec2(.875,-.481482));
   if(v.x<2./viewWidth||v.x>1.-2./viewWidth||v.y<2./viewHeight||v.y>1.-2./viewHeight)
     ;
   else
      x+=m[frameCounter/2%16]*.5;
   x=(floor(x*64.)+.5)/64.;
   vec3 i=texture2D(noisetex,x).xyz,z=vec3(sqrt(.2),sqrt(2.),1.61803);
   i=mod(i+float(frameCounter%2)*.5,vec3(1.));
   return i;
 }
 vec2 D(vec2 v,float f,float x,out float i)
 {
   vec2 K=v;
   i=f;
   vec2 m=x*ScreenTexel;
   for(int r=-1;r<=1;r+=2)
     {
       for(int z=-1;z<=1;z+=2)
         {
           vec2 s=v+vec2(r,z)*m;
           float t=texture2DLod(DEPTHTEX,s,0).x;
           if(t<i)
             i=t,K=s;
         }
     }
   return K;
 }
 vec3 U(vec3 v)
 {
   mat3 x=mat3(.2126,.7152,.0722,-.09991,-.33609,.436,.615,-.55861,-.05639);
   return v*x;
 }
 vec3 M(vec3 v)
 {
   mat3 x=mat3(1.,0.,1.28033,1.,-.21482,-.38059,1.,2.12798,0.);
   return v*x;
 }
 vec3 G(vec3 v,vec3 x,vec3 i,vec3 m)
 {
   vec3 K=.5*(x+v),z=.5*(x-v),f=m-K,s=f/z,d=abs(s);
   float r=max(d.x,max(d.y,d.z));
   if(r>1.)
     return K+f/r;
   else
      return m;
 }
 vec4 H(sampler2D v,vec2 z)
 {
   return pow(texture2DLod(v,z,0),vec4(vec3(1./2.2),1.));
 }
 vec4 M(sampler2D v,vec2 m)
 {
   vec2 x=vec2(viewWidth,viewHeight),i=1./x,f=m*x,z=floor(f-.5)+.5,s=f-z,K=s*s,y=s*K;
   float t=.4;
   vec2 d=-t*y+2.*t*K-t*s,r=(2.-t)*y-(3.-t)*K+1.,e=-(2.-t)*y+(3.-2.*t)*K+t*s,o=t*y-t*K,n=r+e,c=i*(z+e/n);
   vec4 C=H(v,vec2(c.x,c.y));
   vec2 p=i*(z-1.),a=i*(z+2.);
   vec4 F=vec4(H(v,vec2(c.x,p.y)).xyz,1.)*(n.x*d.y)+vec4(H(v,vec2(p.x,c.y)).xyz,1.)*(d.x*n.y)+vec4(C.xyz,1.)*(n.x*n.y)+vec4(H(v,vec2(a.x,c.y)).xyz,1.)*(o.x*n.y)+vec4(H(v,vec2(c.x,a.y)).xyz,1.)*(n.x*o.y);
   return pow(vec4(max(vec3(0.),F.xyz*(1./F.w)),C.w),vec4(vec3(2.2),1.));
 }
 float D()
 {
   float v=int(log2(min(viewWidth,viewHeight)));
   return min(1.095,pow(dot(texture2DLod(CURR_COLOR_TEX,vec2(.65,.65),v+1).xyz,vec3(.33333)),1.1))*.3;
 }
 void D(vec2 v,vec2 x,float i,out vec3 f,out vec4 r)
 {
   vec4 K=vec4(v.xy*2.-1.,i*2.-1.,1.),m=gbufferProjectionInverse*K;
   m.xyz/=m.w;
   r=gbufferModelViewInverse*vec4(m.xyz,1.);
   f=texture2DLod(colortex8,LockRenderPixelCoord(x),0).xyz*2.;
 }
 vec3 P(vec2 v,float z)
 {
   vec4 x=GetViewPosition(v,z);
   return(gbufferModelViewInverse*vec4(x.xyz,1.)).xyz;
 }
 vec3 C(vec3 v)
 {
   return 2./(1.+exp(-v))-1.;
 }
 void main()
 {
   float v=texture2D(depthtex0,texcoord.xy).x;
   vec2 x=texcoord.xy;
   if(v>.7)
     ;
   vec4 d=texture2DLod(CURR_COLOR_TEX,x,0);
   vec3 f=pow(d.xyz,vec3(COLORPOW)),z=f;
   float i;
   vec2 K=D(texcoord.xy,v,1.,i);
   float m=i,s=texture2D(DEPTHTEX,DownscaleTexcoord(texcoord.xy)).x,y;
   vec2 r=D(DownscaleTexcoord(texcoord.xy),s,1.,y);
   float t=y;
   vec3 e;
   vec4 n;
   D(K,r,t,e,n);
   float o=length(e.xy)*.25;
   if(s<.7)
     e*=0.;
   vec2 c=texcoord.xy-e.xy*.5,a=cos((fract(abs(texcoord.xy-c.xy)*ScreenSize)*2.-1.)*3.14159)*.5+.5,S=pow(a,vec2(.5));
   vec4 p=M(PREV_COLOR_TEX,c.xy);
   float F=0.;
   vec3 h=vec3(0.);
   eAMCZAKEcI A=W(texcoord.xy);
   F=1.4;
   h=vec3(1.)/(pow(A.vPMmNoxUfq,1.4)+1.);
   h=max(h,vec3(.01));
   #if AA_STYLE==1
   #else
   h=vec3(.01);
   #endif
   h=saturate(h*max(.05,frameTime)*30.);
   if(ExpToLinearDepth(s)-ExpToLinearDepth(y)>.9)
     ;
   if(s<.7)
     F=.8;
   if(c.x<0.||c.x>1.||c.y<0.||c.y>1.)
     h=vec3(1.);
   vec3 X=vec3(1e+06,1e+06,1e+06),l=vec3(0.,0.,0.),b=vec3(0.,0.,0.),w=vec3(0.),g=vec3(0.);
   int T=0;
   vec3 P=vec3(0.),R=vec3(0.);
   for(int V=-1;V<=1;V++)
     {
       for(int E=-1;E<=1;E++)
         {
           vec2 H=vec2(float(V),float(E))/vec2(viewWidth,viewHeight);
           vec3 L=pow(texture2D(CURR_COLOR_TEX,x.xy+H).xyz,vec3(COLORPOW));
           X=min(X,L);
           l=max(l,L);
           b+=L;
           if(E==0)
             w+=L;
           if(V==0)
             g+=L;
           L=U(L);
           P+=L;
           R+=L*L;
           T++;
         }
     }
   b/=T;
   w/=3.;
   g/=3.;
   vec3 L=P/T,V=sqrt(max(vec3(0.),R/T-L*L)),E=L-F*V,u=L+F*V;
   #ifdef SKIP_AA
   h=vec3(1.);
   #endif
   float H=GetAvgLum(),B=.5,q=1./B;
   vec3 Y=ApplyAutoExposureInverse(C(ApplyAutoExposure(f-b,H)*B),H)*q,J=ApplyAutoExposureInverse(C(ApplyAutoExposure(f-w,H)*B),H)*q,O=ApplyAutoExposureInverse(C(ApplyAutoExposure(f-g,H)*B),H)*q;
   f+=J*(.3/h)*S.x;
   f+=O*(.3/h)*S.y;
   f+=J*(5./h)*min(.05,abs(e.x));
   f+=O*(5./h)*min(.05,abs(e.y));
   #if AA_STYLE==1
   #endif
   p.xyz=M(G(E,u,f.xyz,U(p.xyz)));
   vec3 Q=mix(p.xyz,f,h);
   Q=pow(Q,vec3(1./COLORPOW));
   vec2 I=texcoord.xy*ScreenSize;
   if(distance(I,vec2(0.,0.))<1.)
     {
       float k=D()*1000.,j=texture2DLod(PREV_COLOR_TEX,texcoord.xy,0).w;
       k=mix(j,k,saturate(k>j?1.5*frameTime:6.*frameTime));
       v=k;
     }
   Q=max(vec3(0.),Q);
   vec2 k=normalize(e.xy+1e-07)*min(1.,length(e.xy));
   if(s<.7)
     k=vec2(0.);
   gl_FragData[0]=vec4(k.xy*.5+.5,0.,1.);
   gl_FragData[1]=vec4(Q,v);
   gl_FragData[2]=vec4(e,1.);
 };




/* DRAWBUFFERS:269 */
