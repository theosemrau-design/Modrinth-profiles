#version 330 compatibility

#include "lib/Uniforms.inc"
#include "lib/Common.inc"

out vec4 color;
out vec4 preDownscaleProjPos;
out vec3 viewPos;

void main() {
	gl_Position = ftransform();



	viewPos = (gl_ModelViewMatrix * gl_Vertex).xyz * 1000.0;




	FinalVertexTransformTAA(gl_Position, preDownscaleProjPos);

	
	color = gl_Color;

	gl_FogFragCoord = gl_Position.z;

}
